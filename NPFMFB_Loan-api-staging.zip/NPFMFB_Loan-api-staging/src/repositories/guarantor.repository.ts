import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const Guarantor = require('../models').Guarantor;

export interface IGuarantorRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    saveOrUpdateAll(guarantors: any[]): Promise<any>;
  }

  @injectable()
export class GuarantorRepository extends BaseRepository implements IGuarantorRepository {
      saveAll(t: any[]): Promise<any> {
        logger.info("saving bulk Guarantor");
        return Guarantor.bulkCreate(t)
        .catch(err => {
            logger.error(`Error bulkCreating Guarantor in repository!`+ err);
          });
      }

      saveOrUpdateAll(guarantors: any[]): Promise<any> {
        return Guarantor.bulkCreate(guarantors, 
          {
              fields:["id", "name", "accountNumber", "guarantorForm"] ,
              updateOnDuplicate: ["name", "accountNumber", "guarantorForm"] 
          } ).catch(err => {
          logger.error(`Error bulkCreateUpdate Guarantors in repository!`+ err);
        });
    }

      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." + t);
      }
      save(t: any): Promise<any> {
          throw new Error("Method not implemented." + t);
      }
      findAll(): Promise<any> {
          throw new Error("Method not implemented.");
      }
      findById(t: number): Promise<any> {
          throw new Error("Method not implemented." + t);
      }

}