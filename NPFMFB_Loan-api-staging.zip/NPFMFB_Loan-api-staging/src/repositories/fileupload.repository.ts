import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const FileUpload = require('../models').FileUpload;

export interface IFileUploadRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    findByLoanAppId(loanAppId: number): Promise<any>;
  }

  @injectable()
export class FileUploadRepository extends BaseRepository implements IFileUploadRepository {

      update(data: any, id: number): Promise<any> {
        return FileUpload.update({data},{
          where: { id: id },
          returning: true
        });
      }
      findByLoanAppId(loanAppId: number): Promise<any> {
        return FileUpload.findAll({ where: {loan_app_id: loanAppId} })
        .then(fileUploads => {
            return fileUploads;
           })
           .catch((err: Error) => {throw err});
      }
      saveAll(t: any[]): Promise<any> {
        return FileUpload.bulkCreate(t)
        .catch(err => {
          logger.error(`Error bulkCreating FileUpload in repository!`+ err);
        });
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented."+t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      save(t: any): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      findAll(): Promise<any> {
          throw new Error("Method not implemented.");
      }
      findById(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }

}