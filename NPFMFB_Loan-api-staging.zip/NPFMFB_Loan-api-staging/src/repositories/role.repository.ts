
import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const Role = require('../../src/models').Role;

export interface IRoleRepository extends IBaseRepository{
    save(data: any): Promise<any>;
    update(data: any, id: number): Promise<any>;
    saveAll(data: any[]): Promise<any>;
    getRoleByName(name: string): Promise<any>;
    getRoleByCode(code: string): Promise<any>;
 }


 @injectable()
export class RoleRepository extends BaseRepository implements IRoleRepository {
    update(data: any, id: number): Promise<any> {
        return Role.update({
            name: data.name, 
            code: data.code, 
            maxLimit: data.maxLimit, 
            minLimit: data.minLimit,
            workFlowLevel: data.workFlowLevel
        },{
            where: { id: id },
            returning: true
          });
    }
    exists(id: number): Promise<boolean> {
        throw new Error("Method not implemented."+id);
    }
    delete(id: number): Promise<any> {
        throw new Error("Method not implemented."+id);
    }
    findAll(): Promise<any> {
        return Role.findAll();
    }
    findById(id: number): Promise<any> {
        return Role.findByPk(id);
    }
    saveAll(data: any[]): Promise<any> {
        return Role.bulkCreate(data, 
            {
                fields:["id", "name", "code", "maxLimit", "minLimit"] ,
                updateOnDuplicate: ["name", "code", "maxLimit", "minLimit", "updatedAt"] 
            })
          .catch(err => {
            logger.error(`Error bulkCreateUpdate Roles in repository!`+ err);
          });
    }
    getRoleByName(name: string): Promise<any> {
        return Role.findOne({ where: {name: name} })
        .then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
    }
    getRoleByCode(code: string): Promise<any> {
        return Role.findOne({ where: {code: code} })
        .then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
    }
    save(data: any): Promise<any> {
        return Role.create({ name: data.name, code: data.code, maxLimit: data.maxLimit, minLimit: data.minLimit })
        .then(role => {
            //return role.get({ plain: true });
            return role;
           }).catch((err: Error) => {logger.error("error saving in role repositiory====="+err)}); 
     }

}