import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const Criteria = require('../models').Criteria;

export interface ICriteriaRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    saveOrUpdateAll(criterias: any[]): Promise<any>;
    getByRequiredApplicantInput(): Promise<any>;
  }

  @injectable()
export class CriteriaRepository extends BaseRepository implements ICriteriaRepository {

      update(data: any, id: number): Promise<any> {
        return Criteria.update({
          scoreType: data.scoreType, 
            code: data.code, 
            requirements: data.requirements, 
            maxScore: data.maxScore,
            inputType: data.inputType,
            optionValues: data.optionValues
        },{
          where: { id: id },
          returning: true
        });
      }
      findById(id: number): Promise<any> {
        return Criteria.findByPk(id);
      }

      saveOrUpdateAll(criterias: any[]): Promise<any> {
        return Criteria.bulkCreate(criterias, 
          {
              fields:["id", "code", "scoreType", "requirements", "maxScore", "inputType", "optionValues"] ,
              updateOnDuplicate: ["code", "scoreType", "requirements", "maxScore", "inputType", "optionValues"] 
          } ).catch(err => {
          logger.error(`Error bulkCreateUpdate Criteria in repository!`+ err);
        });
    }
      saveAll(t: any[]): Promise<any> {
          return Criteria.bulkCreate(t).catch(err => {
            logger.error(`Error saveAll Criteria in repository!`+ err);
          });
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." +t);
      }
      save(t: any): Promise<any> {
        return Criteria.create(t)
        .catch(err => {
          logger.error(`Error saving Criteria in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }
      findAll(): Promise<any> {
        return Criteria.findAll().catch(err => {
          logger.error(`Error fetching Criterias in repository!`+ err);
        });
      }
      getByRequiredApplicantInput(): Promise<any> {
        return Criteria.findAll({
             where: { applicantInputNeeded: true }
        });
      }
}