import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
import {Op} from "sequelize";
const LoanApp = require('../models').LoanApp;
const CriteriaValue = require('../models').CriteriaValue;
const Criteria = require('../models').Criteria;
const BaseInfoValue = require('../models').BaseInfoValue;
const BaseInfo = require('../models').BaseInfo;
const LoanProduct = require('../models').LoanProduct;
const Guarantor = require('../models').Guarantor;
const LoanProductCategory = require('../models').LoanProductCategory;

export interface ILoanAppRepository extends IBaseRepository{
    loadByIdWithCriteriaValuesAndBaseInfoValues(id: number): Promise<any>;
    saveOrUpdate (t: any): Promise<any>;
    loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(customerInfoId: number, status: string): Promise<any>;
    getCountByStatus(status: string): Promise<any>;
    getTotalLoanValue(): Promise<any>;
    getTotalLoanAmountRepayments(): Promise<any>;
    loadByCustomerIdAndLoanProductIdAndStatus(customerInfoId: number, loanProductId: number, status: string): Promise<any>;
  }

  @injectable()
export class LoanAppRepository extends BaseRepository implements ILoanAppRepository {

  loadByCustomerIdAndLoanProductIdAndStatus(customerInfoId: number, loanProductId: number, status: string): Promise<any> {
    return LoanApp.findOne({
      //logging: console.log,
      where: {
        [Op.and]: [
          { customer_id: customerInfoId },
          {loan_product_id: loanProductId},
          { status: status }
        ]
      }
    })
  }

  loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(customerInfoId: number, status: string): Promise<any> {
    return LoanApp.findOne({
      //logging: console.log,
      where: {
        [Op.and]: [
          { customer_id: customerInfoId },
          { status: status }
        ]
      }
    })
  }
    
    loadByIdWithCriteriaValuesAndBaseInfoValues(id: number): Promise<any> {
        return LoanApp.findOne({
          //logging: console.log,
            where: {
                id: id
            },
            include: [
                {
                model: CriteriaValue,
                 as: "criteriaValues",
                 include: [
                  {
                  model: Criteria,
                   as: "criteria",
                   where: { applicantInputNeeded: true }
                  }]
                },
                {
                model: LoanProduct,
                   as: "loanProduct",
                   include: [
                    {
                    model: LoanProductCategory,
                     as: "loanProductCategory",
                     include: [
                      {
                      model: Criteria,
                       as: "criterias",
                       where: { applicantInputNeeded: true }
                      },
                  ]
                    }
                ]
                },
                {
                model: Guarantor,
                    as: "guarantors"
                },
                {
                model: BaseInfoValue,
                    as: "baseInfoValues",
                    include: [
                      {
                      model: BaseInfo,
                       as: "baseInfo",
                       where: { applicantInputNeeded: true }
                      }]
                }
            ]
        })
      }
      findById(id: number): Promise<any> {
        return LoanApp.findByPk(id);
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." +t);
      }
      save(t: any): Promise<any> {
        //const loanApp = LoanApp.build({ name: t.name, loan_product_id: t.loan_product_id, amount: t.amount , user_id: t.user_id });
        return LoanApp.create(t)
        .catch(err => {
          logger.error(`Error saving LoanApp in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }
      async saveOrUpdate (t: any): Promise<any> {
        if(t.id && !isNaN(Number(t.id)) ){
          const foundItem = await LoanApp.findByPk(t.id);
          if(foundItem) {
            foundItem.update(t, { where: { id: t.id } });
          return foundItem;
          }
        }
        return LoanApp.create(t);
        
    }
      findAll(): Promise<any> {
          throw new Error("Method not implemented.");
      }

      getCountByStatus(status: string): Promise<any> {
        return LoanApp.count({ where: { status: status }});
      }

      getTotalLoanValue(): Promise<any> {

        return LoanApp.sum('amount').then(sum => {
          return sum;
        });
      }

      getTotalLoanAmountRepayments(): Promise<any> {

        return LoanApp.sum('amount', {where: {
          status: 'PAID'
          }}).then(sum => {
          return sum;
        })
      }
}