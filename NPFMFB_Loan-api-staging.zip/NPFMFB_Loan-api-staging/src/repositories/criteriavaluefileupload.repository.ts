import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const CriteriaValueFileUpload = require('../models').CriteriaValueFileUpload;
const Criteria = require('../models').Criteria;

export interface ICriteriaFileUploadRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    findByLoanAppId(loanAppId: number): Promise<any>;
  }

  @injectable()
export class CriteriaFileUploadRepository extends BaseRepository implements ICriteriaFileUploadRepository {

      update(data: any, id: number): Promise<any> {
        return CriteriaValueFileUpload.update({data},{
          where: { id: id },
          returning: true
        });
      }
      findByLoanAppId(loanAppId: number): Promise<any> {
        return CriteriaValueFileUpload.findAll({ where: {loan_app_id: loanAppId},
            include: [
                {
                model: Criteria,
                 as: "criteria"
                }]
        })
        .then(fileUploads => {
            return fileUploads;
           })
           .catch((err: Error) => {throw err});
      }
      saveAll(t: any[]): Promise<any> {
        return CriteriaValueFileUpload.bulkCreate(t)
        .catch(err => {
          logger.error(`Error bulkCreating Criteria FileUpload in repository!`+ err);
        });
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented."+t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      save(t: any): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      findAll(): Promise<any> {
          throw new Error("Method not implemented.");
      }
      findById(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }

}