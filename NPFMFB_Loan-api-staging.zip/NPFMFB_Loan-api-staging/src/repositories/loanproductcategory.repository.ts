import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const LoanProductCategory = require('../models').LoanProductCategory;
const Criteria = require('../models').Criteria;

export interface ILoanProductCategoryRepository extends IBaseRepository{
    loadWithCriteria(t: number): Promise<any>;
    loadManyWithCriteriaByCategoryType(categoryType: string): Promise<any>;
  }

  @injectable()
export class LoanProductCategoryRepository extends BaseRepository implements ILoanProductCategoryRepository {
    loadWithCriteria(t: number): Promise<any> {
        return LoanProductCategory.findOne({
            where: {
                id: t
            },
            include: [
                {
                model: Criteria,
                 as: "criterias"
                },
            ]
        })
      }

      loadManyWithCriteriaByCategoryType(categoryType: string): Promise<any> {
        return LoanProductCategory.findAll({
            where: {
              categoryType: categoryType
            },
            include: [
                {
                model: Criteria,
                 as: "criterias"
                },
            ]
            
        }).catch(err => {
          logger.error(`Error fetching loanProduct category by category type in repository!`+ err + "****"+ categoryType+ "*****categoryType");
        })
      }

      findById(id: number): Promise<any> {
        return LoanProductCategory.findByPk(id);
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." +t);
      }

      update(data: any, id: number): Promise<any> {
        return LoanProductCategory.update({
          name: data.name,
          description: data.description,
          categoryType: data.categoryType
          
        },{
          where: { id: id },
          returning: true
        });
      }
      save(t: any): Promise<any> {
        return LoanProductCategory.create({ name: t.name, description: t.description, categoryType: t.categoryType})
        .catch(err => {
          logger.error(`Error saving loanProduct category in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }

      saveAll(t: any[]): Promise<any> {
        return LoanProductCategory.bulkCreate(t);
      }
      findAll(): Promise<any> {
        return LoanProductCategory.findAll({
          include: [
              {
              model: Criteria,
               as: "criterias"
              },
          ],
      })
      }
}