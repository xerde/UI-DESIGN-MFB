import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const CriteriaValue = require('../models').CriteriaValue;

export interface ICriteriaValueRepository extends IBaseRepository{
    saveAll(criteriaValues: any[]): Promise<any>;
  }

  @injectable()
export class CriteriaValueRepository extends BaseRepository implements ICriteriaValueRepository {

      update(data: any, id: number): Promise<any> {
        return CriteriaValue.update({data},{
          where: { id: id },
          returning: true
        });
      }
      saveAll(criteriaValues: any[]): Promise<any> {
          return CriteriaValue.bulkCreate(criteriaValues)
          .catch(err => {
            logger.error(`Error bulkCreating CriteriaValue in repository!`+ err);
          });
      }

      saveOrUpdateAll(criteriaValues: any[]): Promise<any> {
        return CriteriaValue.bulkCreate(criteriaValues, 
          {
              fields:["id", "value", "criteria_id"] ,
              updateOnDuplicate: ["value", "criteria_id", "updatedAt"] 
          } ).catch(err => {
          logger.error(`Error bulkCreateUpdate CriteriaValue in repository!`+ err);
        });
    }
      findById(id: number): Promise<any> {
        return CriteriaValue.findByPk(id);
      }
      exists(id: number): Promise<boolean> {
          throw new Error("Method not implemented." + id);
      }
      delete(id: number): Promise<any> {
          throw new Error("Method not implemented." +id);
      }
      save(criteriaValue: any): Promise<any> {
        return CriteriaValue.create({ name: criteriaValue.name, value: criteriaValue.value})
        // .then(u => {
        //   return u.get({ plain: true });
        // })
        .catch(err => {
          logger.error(`Error saving CriteriaValue in repository!`+ err + "****"+ criteriaValue.name+ "*****t.name");
        })
      }
      findAll(): Promise<any> {
        return CriteriaValue.findAll();
      }
}