import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
import {Op} from "sequelize";
const LoanProduct = require('../models').LoanProduct;
const LoanProductCategory = require('../models').LoanProductCategory;
const Criteria = require('../models').Criteria;

//[Op.startsWith]: 'hat',
/*
return LoanApp.findOne({
      //logging: console.log,
      where: {
        [Op.and]: [
          { customer_id: customerInfoId },
          { status: status }
        ]
      }
    })
*/
export interface ILoanProductRepository extends IBaseRepository{
  loadWithCategory(t: number): Promise<any>;
  likeSearchByName(name: string): Promise<any>;
  }

  @injectable()
export class LoanProductRepository extends BaseRepository implements ILoanProductRepository {
    loadWithCategory(t: number): Promise<any> {
        return LoanProduct.findOne({
            where: {
                id: t
            },
            include: [
                {
                model: LoanProductCategory,
                 as: "loanProductCategory",
                 include: [
                  {
                  model: Criteria,
                   as: "criterias",
                   where: { applicantInputNeeded: true }
                  },
              ]
                },
                
            ]
        })
      }

      likeSearchByName(name: string): Promise<any> {
        return LoanProduct.findAll({
          attributes: ['name', 'id'],
            where: {
              name: {
                [Op.startsWith]: name
              }
            }
        })
      }

      findById(id: number): Promise<any> {
        return LoanProduct.findByPk(id);
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." +t);
      }

      update(data: any, id: number): Promise<any> {
        return LoanProduct.update({
          name: data.name, 
          interestRate: data.interestRate, 
          maxTerm: data.maxTerm, 
            maxTermUnit: data.maxTermUnit, 
            limit: data.limit, 
            repaymentReqmt: data.repaymentReqmt,
            guarantorsCnt: data.guarantorsCnt,
            loanProductCategory_id: data.loanProductCategory_id
        },{
          where: { id: id },
          returning: true
        });
      }
      save(t: any): Promise<any> {
        return LoanProduct.create({ name: t.name, interestRate: t.interestRate, maxTerm: t.maxTerm, 
            maxTermUnit: t.maxTermUnit, limit: t.limit, repaymentReqmt: t.repaymentReqmt, guarantorsCnt: t.guarantorsCnt, loanProductCategory_id: t.loanProductCategory_id})
        .catch(err => {
          logger.error(`Error saving loanProduct in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }

      saveAll(t: any[]): Promise<any> {
        return LoanProduct.bulkCreate(t).catch(err => {
          logger.error(`Error saveAll loanProduct in repository!`+ err);
        });
    }

      findAll(): Promise<any> {
        return LoanProduct.findAll({
          include: [
              {
              model: LoanProductCategory,
               as: "loanProductCategory",
               include: [
                {
                model: Criteria,
                 as: "criterias",
                 where: { applicantInputNeeded: true }
                },
            ]
              }
          ]
      })
      }
}