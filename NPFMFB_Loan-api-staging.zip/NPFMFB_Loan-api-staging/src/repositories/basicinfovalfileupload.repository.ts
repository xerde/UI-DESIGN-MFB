import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const BasicInfoValueFileUpload = require('../models').BasicInfoValueFileUpload;
const BaseInfo = require('../models').BaseInfo;

export interface IBasicInfoFileUploadRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    findByLoanAppId(loanAppId: number): Promise<any>;
  }

  @injectable()
export class BasicInfoFileUploadRepository extends BaseRepository implements IBasicInfoFileUploadRepository {

      update(data: any, id: number): Promise<any> {
        return BasicInfoValueFileUpload.update({data},{
          where: { id: id },
          returning: true
        });
      }
      findByLoanAppId(loanAppId: number): Promise<any> {
        return BasicInfoValueFileUpload.findAll({ where: {loan_app_id: loanAppId},
            include: [
                {
                model: BaseInfo,
                 as: "baseInfo"
                }]
        })
        .then(fileUploads => {
            return fileUploads;
           })
           .catch((err: Error) => {throw err});
      }
      saveAll(t: any[]): Promise<any> {
        return BasicInfoValueFileUpload.bulkCreate(t)
        .catch(err => {
          logger.error(`Error bulkCreating Basic Info FileUpload in repository!`+ err);
        });
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented."+t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      save(t: any): Promise<any> {
          throw new Error("Method not implemented."+t);
      }
      findAll(): Promise<any> {
          throw new Error("Method not implemented.");
      }
      findById(t: number): Promise<any> {
          throw new Error("Method not implemented."+t);
      }

}