import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const BaseInfo = require('../models').BaseInfo;

export interface IBaseInfoRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    getByRequiredApplicantInput(): Promise<any>;
  }

  @injectable()
export class BaseInfoRepository extends BaseRepository implements IBaseInfoRepository {
      saveOrUpdateAll(baseInfos: any[]): Promise<any> {
        return BaseInfo.bulkCreate(baseInfos, 
          {
              fields:["id", "name", "code", "description", "required", "inputType"] ,
              updateOnDuplicate: ["name", "code", "description", "required", "inputType", "updatedAt"] 
          })
        .catch(err => {
          logger.error(`Error bulkCreateUpdate baseInfoValues in repository!`+ err);
        });
      }
      update(data: any, id: number): Promise<any> {
        return BaseInfo.update({
          name: data.name, 
            code: data.code, 
            description: data.description, 
            required: data.required,
            inputType: data.inputType
        },{
          where: { id: id },
          returning: true
        });
      }

      findById(id: number): Promise<any> {
        return BaseInfo.findByPk(id);
      }
      saveAll(t: any[]): Promise<any> {
          return BaseInfo.bulkCreate(t);
      }
      exists(t: number): Promise<boolean> {
          throw new Error("Method not implemented." + t);
      }
      delete(t: number): Promise<any> {
          throw new Error("Method not implemented." +t);
      }
      save(t: any): Promise<any> {
        return BaseInfo.create(t)
        .catch(err => {
          logger.error(`Error saving BaseInfo in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }
      findAll(): Promise<any> {
          return BaseInfo.findAll();
      }
      getByRequiredApplicantInput(): Promise<any> {
        return BaseInfo.findAll({
             where: { applicantInputNeeded: true }
        });
    }
}