import { injectable } from "inversify";

export interface IBaseRepository {
    exists(id: number): Promise<boolean>;
    delete(id: number): Promise<any>;
    save(data: any): Promise<any>;
    findAll(): Promise<any>;
    findById(id: number): Promise<any>;
    saveAll(data: any[]): Promise<any>;
    saveOrUpdateAll(data: any[]): Promise<any>;
    update(data: any, id: number): Promise<any>;
  }

  @injectable()
export class BaseRepository implements IBaseRepository {
    saveAll(data: any[]): Promise<any> {
      throw new Error("Method not implemented."+data);
    }
    exists(id: number): Promise<boolean> {
      throw new Error("Method not implemented."+id);
    }
    delete(id: number): Promise<any> {
      throw new Error("Method not implemented."+id);
    }
    save(data: any): Promise<any> {
      throw new Error("Method not implemented."+data);
    }
    findAll(): Promise<any> {
      throw new Error("Method not implemented.");
    }
    findById(id: number): Promise<any> {
      throw new Error("Method not implemented."+id);
    }
    saveOrUpdateAll(data: any[]): Promise<any> {
      throw new Error("Method not implemented."+data);
    }
    update(data: any, id: number): Promise<any> {
      throw new Error("Method not implemented."+ data +" "+ id);
    }

}