import { injectable } from "inversify";
import { Op } from "sequelize";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const LoanCustomer = require('../models').LoanCustomer;
const LoanApp = require('../models').LoanApp;
const LoanProduct = require('../models').LoanProduct;
const LoanProductCategory = require('../models').LoanProductCategory;

export interface ILoanCustomerRepository extends IBaseRepository {
    saveOrUpdate (t: any): Promise<any>;
    updateLoanCustomerLoanAppId(t: any ): Promise<any>;
    findAllPending(): Promise<any>;
    findAllByStatus(status: string): Promise<any>;
    findAll(): Promise<any>;
}

@injectable()
export class LoanCustomerRepository extends BaseRepository implements ILoanCustomerRepository {

  private loadLoanCustomerWithoutLoan(customerInfoId: number): Promise<any> {
    return LoanCustomer.findOne({
      //logging: console.log,
      where: {
        [Op.and]: [
          { customer_id: customerInfoId },
          { loan_app_id: null }
        ]
      }
    })
  }
    async saveOrUpdate(t: any): Promise<any> {
      if(t.customer_id && !isNaN(Number(t.customer_id)) ){
        const foundItem = await this.loadLoanCustomerWithoutLoan(t.customer_id);
        if(foundItem) {
          foundItem.update(t, { where: { customer_id: t.customer_id } });
        return foundItem;
        }
      }
      return LoanCustomer.create(t);
    }

    updateLoanCustomerLoanAppId(t: any ): Promise<any> {
      return LoanCustomer.update({loan_app_id: t.id, dti: t.dti}, { where: {[Op.and]: [
        { customer_id: t.customer_id },
        { loan_app_id: null }
      ] } }).catch(err => {
        logger.error(`Error saving attaching loan to customer in repository!`+ err + "****"+ t.name+ "*****t.name");
      })
    }

    save(t: any): Promise<any> {
        return LoanCustomer.create(t)
        .catch(err => {
          logger.error(`Error saving LoanCustomer in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }

      findAllPending(): Promise<any> {
        return LoanCustomer.findAll({
          //logging: console.log,
          where: {
            loan_app_id: {[Op.ne]: null}
            //[Op.and]: [
              //{ customer_id: customerInfoId },
              //{ loan_app_id: {[Op.ne]: null}}
            //]
          },
          include: [
            {
            model: LoanApp,
             as: "loanApp",
             where: { status: 'PENDING' },
             include: [
               {
              model: LoanProduct,
              as: "loanProduct",
              include: [
               {
               model: LoanProductCategory,
                as: "loanProductCategory"
               }
              ]
            }
             ]
            }
          ]
        })
      }

      findAllByStatus(status: string): Promise<any> {
        return LoanCustomer.findAll({
          //logging: console.log,
          order: [[LoanApp, 'createdAt', 'DESC']],
          where: {
            loan_app_id: {[Op.ne]: null}
            //[Op.and]: [
              //{ customer_id: customerInfoId },
              //{ loan_app_id: {[Op.ne]: null}}
            //]
          },
          include: [
            {
            model: LoanApp,
            separate: true,
             as: "loanApp",
             where: { status: status },
             include: [
               {
              model: LoanProduct,
              as: "loanProduct",
              include: [
               {
               model: LoanProductCategory,
                as: "loanProductCategory"
               }
              ]
            }
             ]
            }
          ]
        })
      }

      findAll(): Promise<any> {
        return LoanCustomer.findAll({
          where: {
            loan_app_id: {[Op.ne]: null}
          },
          include: [
            {
            model: LoanApp,
             as: "loanApp",
             include: [
               {
              model: LoanProduct,
              as: "loanProduct",
              include: [
               {
               model: LoanProductCategory,
                as: "loanProductCategory"
               }
              ]
            }
             ]
            }
          ]
        })
      }

}