import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const BaseInfoValue = require('../models').BaseInfoValue;

export interface IBaseInfoValueRepository extends IBaseRepository{
    saveAll(baseInfoValues: any[]): Promise<any>;
  }

  @injectable()
export class BaseInfoValueRepository extends BaseRepository implements IBaseInfoValueRepository {
      update(data: any, id: number): Promise<any> {
        return BaseInfoValue.update({data},{
          where: { id: id },
          returning: true
        });
      }
      saveAll(baseInfoValues: any[]): Promise<any> {
          return BaseInfoValue.bulkCreate(baseInfoValues)
          .catch(err => {
            logger.error(`Error bulkCreating BaseInfoValue in repository!`+ err);
          });
      }
      saveOrUpdateAll(baseInfoValues: any[]): Promise<any> {
        return BaseInfoValue.bulkCreate(baseInfoValues, 
          {
              fields:["id", "value", "base_info_id"] ,
              updateOnDuplicate: [ "value", "base_info_id", "updatedAt"] 
          } ).catch(err => {
          logger.error(`Error bulkCreateUpdate BaseInfoValue in repository!`+ err);
        });
    }
      findById(id: number): Promise<any> {
        return BaseInfoValue.findByPk(id);
      }
      exists(id: number): Promise<boolean> {
          throw new Error("Method not implemented." + id);
      }
      delete(id: number): Promise<any> {
          throw new Error("Method not implemented." +id);
      }
      save(baseInfoValue: any): Promise<any> {
        return BaseInfoValue.create(baseInfoValue)
        .catch(err => {
          logger.error(`Error saving BaseInfoValue in repository!`+ err + "****"+ baseInfoValue.name+ "*****baseInfoValue.name");
        })
      }
      findAll(): Promise<any> {
        return BaseInfoValue.findAll();
      }
}