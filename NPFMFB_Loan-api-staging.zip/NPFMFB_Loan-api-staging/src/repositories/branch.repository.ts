import { injectable } from "inversify";
import logger from "../utils/logger";
import { BaseRepository, IBaseRepository } from "./base.repository";
const Branch = require('../models').Branch;

export interface IBranchRepository extends IBaseRepository{
    saveAll(t: any[]): Promise<any>;
    saveOrUpdateAll(branches: any[]): Promise<any>;
    update(data: any, id: number): Promise<any>;
  }

  @injectable()
export class BranchRepository extends BaseRepository implements IBranchRepository {

    findById(id: number): Promise<any> {
        return Branch.findByPk(id);
      }

      update(data: any, id: number): Promise<any> {
        return Branch.update({data},{
          where: { id: id },
          returning: true
        });
      }

      saveOrUpdateAll(branches: any[]): Promise<any> {
        return Branch.bulkCreate(branches, 
          {
              fields:["id", "code", "name"] ,
              updateOnDuplicate: ["code", "name"] 
          } ).catch(err => {
          logger.error(`Error bulkCreateUpdate Branch in repository!`+ err);
        });
    }
      saveAll(t: any[]): Promise<any> {
          return Branch.bulkCreate(t);
      }
      save(t: any): Promise<any> {
        return Branch.create(t)
        .catch(err => {
          logger.error(`Error saving Branch in repository!`+ err + "****"+ t.name+ "*****t.name");
        })
      }
      findAll(): Promise<any> {
        return Branch.findAll();
      }

}