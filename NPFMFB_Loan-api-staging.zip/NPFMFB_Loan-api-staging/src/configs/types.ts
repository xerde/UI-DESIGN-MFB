/**
 * InversifyJS need to use the type as identifiers at runtime.
 * We use symbols as identifiers but you can also use classes and or string literals.
 */
export const TYPES = {
  UserRepository: Symbol('UserRepository'),
  LoanProductRepository: Symbol('LoanProductRepository'),
  RoleRepository: Symbol('RoleRepository'),
  CriteriaRepository: Symbol('CriteriaRepository'),
  CriteriaValueRepository: Symbol('CriteriaValueRepository'),
  LoanAppRepository: Symbol('LoanAppRepository'),
  BaseInfoRepository: Symbol('BaseInfoRepository'),
  BaseInfoValueRepository: Symbol('BaseInfoValueRepository'),
  FileUploadRepository: Symbol('FileUploadRepository'),
  GuarantorRepository: Symbol('GuarantorRepository'),
  BaseRepository: Symbol('BaseRepository'),
  BranchRepository: Symbol('BranchRepository'),
  LoanProductCategoryRepository: Symbol('LoanProductCategoryRepository'),
  LoanCustomerRepository: Symbol('LoanCustomerRepository'),
  BasicInfoFileUploadRepository: Symbol('BasicInfoFileUploadRepository'),
  CriteriaFileUploadRepository: Symbol('CriteriaFileUploadRepository'),


  UserService: Symbol('UserService'),
  DiAuthService: Symbol('DiAuthService'),
  FileUploadService: Symbol('FileUploadService'),
  S3FileUploadService: Symbol('S3FileUploadService'),
  RoleService: Symbol('RoleService'),
  LoanProductService: Symbol('LoanProductService'),
  LoanAppService: Symbol('LoanAppService'),
  BaseInfoService: Symbol('BaseInfoService'),
  CriteriaService: Symbol('CriteriaService'),
  GuarantorService: Symbol('GuarantorService'),
  BranchService: Symbol('BranchService'),
  ExternalService: Symbol('ExternalService'),
  LoanProductCategoryService: Symbol('LoanProductCategoryService'),
  LoanCustomerService: Symbol('LoanCustomerService'),
  DashboardService: Symbol("DashboardService"),
  
  AuthController: Symbol('AuthController'),
  UserController: Symbol('UserController'),
  FileUploadController: Symbol('FileUploadController'),
  LoanProductController: Symbol('LoanProductController'),
  BaseInfoController: Symbol('BaseInfoController'),
  RoleController: Symbol('RoleController'),
  CriteriaController: Symbol('CriteriaController'),
  BranchController: Symbol('BranchController'),
  ExternalController: Symbol('BranchController'),
  LoanProductCategoryController: Symbol('LoanProductCategoryController'),
  
  
};
