import { Application } from 'express';
import { AuthRoutes } from './routes/auth.routes';
import { BaseInfoRoutes } from './routes/baseinfo.routes';
import { BranchRoutes } from './routes/branch.routes';
import { CriteriaRoutes } from './routes/criteria.routes';
import { ExternalRoutes } from './routes/external.route';
import { LoanRoutes } from './routes/loan.routes';
import { LoanProductCategoryRoutes } from './routes/loancategory.routes';
import { RoleRoutes } from './routes/role.routes';
import { UserRoutes } from './routes/user.routes';

export default function (app: Application) {

  new UserRoutes(app);
  new AuthRoutes(app);
  new LoanRoutes(app);
  new BaseInfoRoutes(app);
  new RoleRoutes(app);
  new CriteriaRoutes(app);
  new BranchRoutes(app);
  new ExternalRoutes(app);
  new LoanProductCategoryRoutes(app);

}
