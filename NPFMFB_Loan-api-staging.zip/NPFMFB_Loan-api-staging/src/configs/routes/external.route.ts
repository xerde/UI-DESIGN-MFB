import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import { ExternalController } from "../../controllers/external.controller";

export class ExternalRoutes {

    private externalControllerInstance: ExternalController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.externalControllerInstance = container.get<ExternalController>(ExternalController);
        this.routes();
    }
    routes() {
        this.router.post('/debt-to-income', asyncWrap(this.externalControllerInstance.getDebtToIncome.bind(this.externalControllerInstance)));
        this.router.get('/credit-lookup', asyncWrap(this.externalControllerInstance.getCreditLookup.bind(this.externalControllerInstance)));
        this.router.get('/customer-details/:id', asyncWrap(this.externalControllerInstance.getCustomerDetails.bind(this.externalControllerInstance)));
        this.router.get('/validate-customer-token', asyncWrap(this.externalControllerInstance.getCustomerTokenStatus.bind(this.externalControllerInstance)));
    }
}