import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import BaseInfoController from "../../controllers/baseinfo.controller";

export class BaseInfoRoutes {

    private baseInfoControllerInstance: BaseInfoController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.baseInfoControllerInstance = container.get<BaseInfoController>(BaseInfoController);
        this.routes();
    }
    routes() {
        this.router.post('/baseinfo', asyncWrap(this.baseInfoControllerInstance.saveBaseInfo.bind(this.baseInfoControllerInstance)));
        this.router.post('/baseinfos', asyncWrap(this.baseInfoControllerInstance.saveMultipleBaseInfos.bind(this.baseInfoControllerInstance)));
        this.router.get('/baseinfos', asyncWrap(this.baseInfoControllerInstance.get.bind(this.baseInfoControllerInstance)));
        this.router.get('/baseinfo/:id', asyncWrap(this.baseInfoControllerInstance.getById.bind(this.baseInfoControllerInstance)));
        this.router.put('/baseinfo/:id', asyncWrap(this.baseInfoControllerInstance.updateById.bind(this.baseInfoControllerInstance)));
    
    }
}