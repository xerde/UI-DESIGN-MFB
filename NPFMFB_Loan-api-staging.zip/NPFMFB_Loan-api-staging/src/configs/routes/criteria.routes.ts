import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import CriteriaController from "../../controllers/criteria.controller";

export class CriteriaRoutes {

    private criteriaControllerInstance: CriteriaController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.criteriaControllerInstance = container.get<CriteriaController>(CriteriaController);
        this.routes();
    }
    routes() {
        this.router.get('/criterias', asyncWrap(this.criteriaControllerInstance.get.bind(this.criteriaControllerInstance)));
        this.router.get('/criteria/:id', asyncWrap(this.criteriaControllerInstance.getById.bind(this.criteriaControllerInstance)));
        this.router.put('/criteria/:id', asyncWrap(this.criteriaControllerInstance.updateById.bind(this.criteriaControllerInstance)));
    
    }
}