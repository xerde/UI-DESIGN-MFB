import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import RoleController from "../../controllers/role.controller";

export class RoleRoutes {

    private roleControllerInstance: RoleController;
    private router: Router;


    constructor(router: Router) {
        this.router = router;
        this.roleControllerInstance = container.get<RoleController>(RoleController);
        this.routes();
    }
    routes() {
        this.router.post('/roles', asyncWrap(this.roleControllerInstance.saveMultipleRoles.bind(this.roleControllerInstance)));
        this.router.post('/role', asyncWrap(this.roleControllerInstance.saveRole.bind(this.roleControllerInstance)));
        this.router.get('/roles', asyncWrap(this.roleControllerInstance.getRoles.bind(this.roleControllerInstance)));
        this.router.get('/role/:id', asyncWrap(this.roleControllerInstance.getRoleById.bind(this.roleControllerInstance)));
        this.router.put('/role/:id', asyncWrap(this.roleControllerInstance.updateRole.bind(this.roleControllerInstance)));
    }

}