import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import { AuthController } from "../../controllers/auth.controller";

export class AuthRoutes {

    private authControllerInstance: AuthController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.authControllerInstance = container.get<AuthController>(AuthController);
        this.routes();
    }
    routes() {
        //this.router.post('/register', asyncWrap(this.authControllerInstance.registerUser.bind(this.authControllerInstance)));
        this.router.post('/register', asyncWrap(this.authControllerInstance.registerUserWithRoles.bind(this.authControllerInstance)));
        this.router.post('/login', asyncWrap(this.authControllerInstance.login.bind(this.authControllerInstance)));
    }
}