import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import LoanProductController from "../../controllers/loanproduct.controller";
import LoanAppController from "../../controllers/loanapp.controller";

export class LoanRoutes {

    private loanProductControllerInstance: LoanProductController;
    private loanAppControllerInstance: LoanAppController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.loanProductControllerInstance = container.get<LoanProductController>(LoanProductController);
        this.loanAppControllerInstance = container.get<LoanAppController>(LoanAppController);
        this.routes();
    }
    routes() {
        this.router.post('/loanproduct', asyncWrap(this.loanProductControllerInstance.saveLoanProduct.bind(this.loanProductControllerInstance)));
        this.router.get('/loanproduct/:id', asyncWrap(this.loanProductControllerInstance.getById.bind(this.loanProductControllerInstance)));
        this.router.put('/loanproduct/:id', asyncWrap(this.loanProductControllerInstance.updateById.bind(this.loanProductControllerInstance)));
        this.router.post('/loanapplication', asyncWrap(this.loanAppControllerInstance.saveLoanAppWithAttachments.bind(this.loanAppControllerInstance)));
        this.router.get('/loanapplication/:id', asyncWrap(this.loanAppControllerInstance.get.bind(this.loanAppControllerInstance)));
        this.router.get('/start-loanapplication', asyncWrap(this.loanAppControllerInstance.startApplication.bind(this.loanAppControllerInstance)));
        this.router.get('/loanapplication-pending/:userid', asyncWrap(this.loanAppControllerInstance.getPending.bind(this.loanAppControllerInstance)));
        this.router.post('/loanproducts', asyncWrap(this.loanProductControllerInstance.saveLoanProducts.bind(this.loanProductControllerInstance)));
        this.router.get('/loanproducts', asyncWrap(this.loanProductControllerInstance.get.bind(this.loanProductControllerInstance)));
        this.router.get('/pending-loanapplications', asyncWrap(this.loanAppControllerInstance.adminViewApplications.bind(this.loanAppControllerInstance)));
        this.router.get('/loanproduct-search/:name', asyncWrap(this.loanProductControllerInstance.likeSearchByName.bind(this.loanProductControllerInstance)));
    
    }
}