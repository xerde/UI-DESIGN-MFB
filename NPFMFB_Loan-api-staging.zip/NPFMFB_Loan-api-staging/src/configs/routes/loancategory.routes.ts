import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import LoanProductCategoryController from "../../controllers/loanproductcategory.controller";

export class LoanProductCategoryRoutes {

    private loanProductCategoryControllerInstance: LoanProductCategoryController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.loanProductCategoryControllerInstance = container.get<LoanProductCategoryController>(LoanProductCategoryController);
        this.routes();
    }
    routes() {
        this.router.post('/loanproductcategory', asyncWrap(this.loanProductCategoryControllerInstance.saveLoanProductCategoryWithCriteria.bind(this.loanProductCategoryControllerInstance)));
        this.router.get('/loanproductcategory/:id', asyncWrap(this.loanProductCategoryControllerInstance.getById.bind(this.loanProductCategoryControllerInstance)));
        this.router.put('/loanproductcategory/:id', asyncWrap(this.loanProductCategoryControllerInstance.updateById.bind(this.loanProductCategoryControllerInstance)));
        this.router.post('/loanproductcategories', asyncWrap(this.loanProductCategoryControllerInstance.saveLoanProductCategoriesWithCriteria.bind(this.loanProductCategoryControllerInstance)));
        this.router.get('/loanproductcategories', asyncWrap(this.loanProductCategoryControllerInstance.get.bind(this.loanProductCategoryControllerInstance)));
        this.router.get('/loanproductcategories/:categoryType', asyncWrap(this.loanProductCategoryControllerInstance.getLoanProductCategoriesByCategoryType.bind(this.loanProductCategoryControllerInstance)));
    
    }
}