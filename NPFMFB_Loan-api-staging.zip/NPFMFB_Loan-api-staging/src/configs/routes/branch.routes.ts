import { Router } from "express";
import container from '../inversify';
import asyncWrap from '../../utils/asyncWrapper';
import BranchController from "../../controllers/branch.controller";

export class BranchRoutes {

    private branchControllerInstance: BranchController;
    private router: Router;
   
    constructor(router: Router) {
        this.router = router;
        this.branchControllerInstance = container.get<BranchController>(BranchController);
        this.routes();
    }
    routes() {
        this.router.post('/branch', asyncWrap(this.branchControllerInstance.saveBranch.bind(this.branchControllerInstance)));
        this.router.post('/branches', asyncWrap(this.branchControllerInstance.saveMultipleBranches.bind(this.branchControllerInstance)));
        this.router.get('/branch/:id', asyncWrap(this.branchControllerInstance.getById.bind(this.branchControllerInstance)));
        this.router.get('/branches', asyncWrap(this.branchControllerInstance.get.bind(this.branchControllerInstance)));
        this.router.put('/branch/:id', asyncWrap(this.branchControllerInstance.updateById.bind(this.branchControllerInstance)));
    }
}