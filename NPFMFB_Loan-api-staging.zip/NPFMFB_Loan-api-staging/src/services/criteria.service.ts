 import { inject, injectable } from "inversify";
import { CriteriaValueCreateDTO } from "../dto/criteriavalue.dto";
import { Request } from 'express';
import { TYPES } from "../configs/types";
import { ICriteriaRepository } from "../repositories/criteria.repository";

export interface ICriteriaService {
    createCriteriaValuesModels (criteriaValues: CriteriaValueCreateDTO[]) : any[];
    createCriteriaValuesDtos (req: Request) : any[];
    createCriteriaValuesModelsFromRequest (req: Request) : any[];
    createCriteria(data: any): Promise<any>;
    loadAll(): Promise<any>;
    getById(id: number): Promise<any>;
    updateById(data: any, id: number): Promise<any>;
}

@injectable()
export default class CriteriaService implements ICriteriaService {

    @inject(TYPES.CriteriaRepository) private criteriaRepository: ICriteriaRepository;

    createCriteriaValuesModelsFromRequest (req: Request) : any[] {

        var criteriaValues: CriteriaValueCreateDTO[] = this.createCriteriaValuesDtos (req);
       
        return this.createCriteriaValuesModels(criteriaValues);
    }

    loadAll(): Promise<any> {
        return this.criteriaRepository.findAll();
    }

    getById(id: number): Promise<any> {
        return this.criteriaRepository.findById(id);
    }

    updateById(data: any, id: number): Promise<any> {
        return this.criteriaRepository.update(data, id);
    }

    createCriteria(data: any): Promise<any> {
        return this.criteriaRepository.save(data).then(u => {
            return u;
           })
           .catch((err: Error) => {throw err});
    }

    attachCriteriaToProduct(data: any): Promise<any> {
        return this.criteriaRepository.save(data).then(u => {
            return u;
           })
           .catch((err: Error) => {throw err});
    }

  
    createCriteriaValuesModels (criteriaValues: CriteriaValueCreateDTO[]) : any[] {

        var criteriaValueModels: any[] = new Array();
        criteriaValues.forEach( cv => {
            var cvModel = {};
            cvModel["value"] = cv.value;
            cvModel["criteria_id"] = cv.criteriaId;
            if(cv.id) {
                cvModel["id"] = cv.id;
            }
            criteriaValueModels.push(cvModel);
        } );
        return criteriaValueModels;
    }

    createCriteriaValuesDtos (req: Request) : any[] {

        var criteriaValueDtos: any[] = new Array();
        if(req.body.criteriaValues_criteriaId && req.body.criteriaValues_value) {
            var requestArrayCnt: number = req.body.criteriaValues_criteriaId.length;
            for(var counter: number = 0; counter < requestArrayCnt; counter++){
                var criteriaValue: CriteriaValueCreateDTO = {} as CriteriaValueCreateDTO;
                if(req.body.criteriaValues_id && !isNaN(Number(req.body.criteriaValues_id[counter]))){
                    criteriaValue.id = req.body.criteriaValues_id[counter];
                }
                criteriaValue.criteriaId = req.body.criteriaValues_criteriaId[counter];
                criteriaValue.value = req.body.criteriaValues_value[counter];
                criteriaValueDtos.push(criteriaValue);
            }
        }
        
        return criteriaValueDtos;
    }
}