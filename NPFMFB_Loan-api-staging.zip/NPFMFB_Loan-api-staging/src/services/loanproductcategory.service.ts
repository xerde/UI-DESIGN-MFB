import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { ICriteriaRepository } from "../repositories/criteria.repository";
import { Request } from 'express';
import { ILoanProductCategoryRepository } from "../repositories/loanproductcategory.repository";

export interface ILoanProductCategoryService {
    saveLoanProductCategory(t: any): Promise<any>;
    saveLoanProductCategoryWithCriteria(t: any, u: any[]): Promise<any>;
    saveLoanProductCategoriesWithCriteria(t: Request);
    loadWithCriteria(t: number): Promise<any>;
    loadAllWithCriteria(): Promise<any>;
    attachNewCriteriaToExistingLoanProductCategory(criteriaData: any, categoryId: number): Promise<any>;
    updateById(data: any, id: number): Promise<any>;
    loadManyWithCriteriaByCategoryType(categoryType: string): Promise<any>;
}

@injectable()
export default class LoanProductCategoryService implements ILoanProductCategoryService {

    @inject(TYPES.LoanProductCategoryRepository) private loanProductCategoryRepository: ILoanProductCategoryRepository;

    @inject(TYPES.CriteriaRepository) private criteriaRepository: ICriteriaRepository;

    updateById(data: any, id: number): Promise<any> {
        return this.loanProductCategoryRepository.update(data, id);
    }
    

    saveLoanProductCategoriesWithCriteria(t: Request) {
        var products: any[] = t.body;
        for(var counter: number = 0; counter < products.length; counter++){
            this.saveLoanProductCategoryWithCriteria(products[counter].loanProductCategory, products[counter].criterias);
        }
        return products;
    }

  
    saveLoanProductCategory(t: any): Promise<any> {
        return this.loanProductCategoryRepository.save(t).then(category => {
            return category;
           })
           .catch((err: Error) => {throw err});
    }

    async saveLoanProductCategoryWithCriteria(t: any, u: any[]): Promise<any> {

        return Promise.all([this.criteriaRepository.saveAll(u), this.loanProductCategoryRepository.save(t)])
        .then(([criteria, loanProductCategory]) => {
            return new Promise((resolve, reject) => {
                loanProductCategory.addCriterias(criteria);
                if (loanProductCategory.id !== null) {
                    //console.log("Id is not empty");
                    resolve(loanProductCategory);
                  }
                  else {
                    //console.log("Id is empty");
                      reject(loanProductCategory);
                  }
            })
        })
    }

    async attachNewCriteriaToExistingLoanProductCategory(criteriaData: any, categoryId: number): Promise<any> {

        return Promise.all([this.criteriaRepository.save(criteriaData), this.loanProductCategoryRepository.findById(categoryId)])
        .then(([criteria, loanProductCategory]) => {
            return new Promise((resolve, reject) => {
                loanProductCategory.addCriterias([criteria]);
                if (loanProductCategory.id !== null) {
                    console.log("Idxxxxxx is not empty");
                    resolve(loanProductCategory);
                  }
                  else {
                    console.log("Id is empty");
                      reject(loanProductCategory);
                  }
            })
        })
    }

    loadAllWithCriteria(): Promise<any> {
        return this.loanProductCategoryRepository.findAll();
      }

    loadWithCriteria(t: number): Promise<any> {
        return this.loanProductCategoryRepository.loadWithCriteria(t);
      }
    
      loadManyWithCriteriaByCategoryType(categoryType: string): Promise<any> {
        return this.loanProductCategoryRepository.loadManyWithCriteriaByCategoryType(categoryType);
      }

}