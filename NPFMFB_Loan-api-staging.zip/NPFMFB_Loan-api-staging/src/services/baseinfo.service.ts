import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { BaseInfoValueCreateDTO } from "../dto/baseinfovalue.dto";
import { IBaseInfoRepository } from "../repositories/baseinfo.repository";
import { Request } from 'express';

export interface IBaseInfoService {
    loadAll(): Promise<any>;
    create(t: any): Promise<any>;
    createMany(t: any[]): Promise<any>;
    createBaseInfoValuesModels (baseInfoValues: BaseInfoValueCreateDTO[]) : any[];
    createBaseInfoValuesDtos (req: Request) : any[];
    createBaseInfoValuesModelsFromRequest (req: Request) : any[];
    getById(id: number): Promise<any>;
    updateById(data: any, id: number): Promise<any>;
    loadByRequiredApplicantInput(): Promise<any>;
}

@injectable()
export default class BaseInfoService implements IBaseInfoService {
    
    @inject(TYPES.BaseInfoRepository) private baseInfoRepository: IBaseInfoRepository;

    create(data: any): Promise<any> {
        return this.baseInfoRepository.save(data);
    }
    createMany(data: any[]): Promise<any> {
        return this.baseInfoRepository.saveAll(data);
    }
    
    loadAll(): Promise<any> {
        return this.baseInfoRepository.findAll();
    }

    loadByRequiredApplicantInput(): Promise<any> {
        return this.baseInfoRepository.getByRequiredApplicantInput();
    }

    getById(id: number): Promise<any> {
        return this.baseInfoRepository.findById(id);
    }

    updateById(data: any, id: number): Promise<any> {
        return this.baseInfoRepository.update(data, id);
    }

    createBaseInfoValuesModelsFromRequest (req: Request) : any[] {

        var baseInfoValues: BaseInfoValueCreateDTO[] = this.createBaseInfoValuesDtos (req);
       
        return this.createBaseInfoValuesModels(baseInfoValues);
    }

    createBaseInfoValuesModels (baseInfoValues: BaseInfoValueCreateDTO[]) : any[] {

        var baseInfoValuesModels: any[] = new Array();

        baseInfoValues.forEach( baseInfoValue => {
            var baseInfoValModel = {};
            baseInfoValModel["value"] = baseInfoValue.value;
            baseInfoValModel["base_info_id"] = baseInfoValue.basicInfoId;
            if(baseInfoValue.id) {
                baseInfoValModel["id"] = baseInfoValue.id;
            }
            baseInfoValuesModels.push(baseInfoValModel);
        } );
        return baseInfoValuesModels;
    }

    createBaseInfoValuesDtos (req: Request) : any[] {

        var baseInfoValuesDtos: any[] = new Array();
        if(req.body.baseInfoValues_basicInfoId && req.body.baseInfoValues_value) {
            var requestArrayCnt: number = req.body.baseInfoValues_basicInfoId.length;
            for(var counter: number = 0; counter < requestArrayCnt; counter++){
                var baseInfoValue: BaseInfoValueCreateDTO = {} as BaseInfoValueCreateDTO;
                if(req.body.baseInfoValues_id && !isNaN(Number(req.body.baseInfoValues_id[counter]))){
                    baseInfoValue.id = req.body.baseInfoValues_id[counter];
                }
                baseInfoValue.basicInfoId = req.body.baseInfoValues_basicInfoId[counter];
                baseInfoValue.value = req.body.baseInfoValues_value[counter];
                baseInfoValuesDtos.push(baseInfoValue);
            }
        }
        
        return baseInfoValuesDtos;
    }
}