import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { IRoleRepository } from "../repositories/role.repository";

export interface IRoleService {
    createRole(data: any): Promise<any>;
    createManyRoles(data: any[]): Promise<any>;
    updateRole(data: any, id: number): Promise<any>;
    findById(id: number): Promise<any>;
    getRoles(): Promise<any>;
 }


 @injectable()
export default class RoleService implements IRoleService {

    @inject(TYPES.RoleRepository) private roleRepository: IRoleRepository;

     createRole(data: any): Promise<any> {
        return this.roleRepository.save(data).then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
     }

     createManyRoles(data: any[]): Promise<any> {
        return this.roleRepository.saveAll(data).then(() => {
            return data;
           })
           .catch((err: Error) => {throw err});
     }

     findById(id: number): Promise<any> {
        return this.roleRepository.findById(id).then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
    }

     updateRole(data: any, id: number): Promise<any> {
        return this.roleRepository.update(data, id).then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
     }

     getRoles(): Promise<any> {
        return this.roleRepository.findAll().then(role => {
            return role;
           })
           .catch((err: Error) => {throw err});
    }

}