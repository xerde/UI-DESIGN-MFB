import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { LoanCustomerCreateDTO } from "../dto/loancustomer.dto";
import { ILoanCustomerRepository } from "../repositories/loancustomer.repository";

import {PendingLoanMapper} from "../mapper/pendingloan.mapper";


export interface ILoanCustomerService {
    saveLoanCustomer(loanCustomer: LoanCustomerCreateDTO): Promise<any>;
    createLoanCustomerDTO(t: any): LoanCustomerCreateDTO;
    attachLoanToCustomer(t: any): Promise<any>;
    getPendingLoanCustomers(): Promise<any>;
    getPendingLoanCustomersByStatus(status: string): Promise<any>;
    getLoanCustomersDto(): Promise<Map<string, object>>;
}

@injectable()
export default class LoanCustomerService implements ILoanCustomerService {

    @inject(TYPES.LoanCustomerRepository) private loanCustomerRepository: ILoanCustomerRepository;


    getPendingLoanCustomers(): Promise<any> {
        return this.loanCustomerRepository.findAllPending();
    }

    async getAllLoanCustomers(): Promise<any> {
        var modelArray = new Array<any>();
        modelArray = await this.loanCustomerRepository.findAll();

        var pendingLoanDtos = [];
  
        modelArray.forEach(function (model) {
            pendingLoanDtos.push(PendingLoanMapper.toDTO(model));    
        });
        
        // Sort in descending order of application date
        pendingLoanDtos.sort((x, y) => +new Date(y.application_date) - +new Date(x.application_date));

        return pendingLoanDtos;
    }

    async getLoanCustomersDto(): Promise<Map<string, object>> {
        var customerLoanDtos = await this.getAllLoanCustomers();

        let loans = new Map();

        loans['inProcess'] = this.getPendingLoans(customerLoanDtos);

        loans['approved'] = this.getApprovedLoans(customerLoanDtos);

        loans['declined']  = this.getRejectedLoans(customerLoanDtos);

        loans['running'] = this.getRunningLoans(customerLoanDtos);

        loans['paid'] = this.getPaidLoans(customerLoanDtos);

        return new  Promise<Map<string, object>>((res, _rej) => {
            res(loans);
          });
    }

    private getPaidLoans(customerLoanDtos: any) {

        var paidCustomerLoanDtos = this.filterByStatus(customerLoanDtos, {
            status: 'PAID'
        });
        return paidCustomerLoanDtos;
    }

    private getRunningLoans(customerLoanDtos: any) {
        
        var runningCustomerLoanDtos = this.filterByStatus(customerLoanDtos, {
            status: 'RUNNING'
        });
        return runningCustomerLoanDtos;
    }

    private getRejectedLoans(customerLoanDtos: any) {
        
        var rejectedCustomerLoanDtos = this.filterByStatus(customerLoanDtos, {
            status: 'REJECT'
        });
        return rejectedCustomerLoanDtos;
    }

    private getApprovedLoans(customerLoanDtos: any) {
        
        var approvedCustomerLoanDtos = this.filterByStatus(customerLoanDtos, {
            status: 'APPROVE'
        });
        return approvedCustomerLoanDtos;
    }

    private getPendingLoans(customerLoanDtos: any) {
        
        var pendingCustomerLoanDtos = this.filterByStatus(customerLoanDtos, {
            status: 'PENDING'
        });
        return pendingCustomerLoanDtos;
    }

    getPendingLoanCustomersByStatus(status: string): Promise<any> {
        return this.loanCustomerRepository.findAllByStatus(status);
    }

    attachLoanToCustomer(t: any): Promise<any> {
        return this.loanCustomerRepository.updateLoanCustomerLoanAppId(t);
    }

    saveLoanCustomer(loanCustomer: LoanCustomerCreateDTO): Promise<any> {
        var loanCust = {};
        loanCust["customer_id"] = loanCustomer.customerId;
        loanCust["name"] = loanCustomer.name;
        loanCust["email"] = loanCustomer.email;
        loanCust["photo_location"] = loanCustomer.photoLocation;
        loanCust["bvn"] = loanCustomer.bvn;
        loanCust["phone"] = loanCustomer.phone;
        loanCust["profilecomplete"] = loanCustomer.profileComplete;
        loanCust["livelinesschecked"] = loanCustomer.livelinessChecked
        loanCust["dti"] = loanCustomer.dti;
        loanCust["createdBy"] = loanCustomer.createdBy;

        return this.loanCustomerRepository.saveOrUpdate(loanCust).then(u => {
            return u;
           })
           .catch((err: Error) => {throw err});
    }

    createLoanCustomerDTO(t: any): LoanCustomerCreateDTO {
        console.log("customer details")

        var createdBy: number = t.id;

        if(t.adminId){
            createdBy = t.adminId;
        }

        return <LoanCustomerCreateDTO>{
            customerId: t.id,
            name: t.firstname + " " + t.lastname,
            email: t.email,
            photoLocation: t.photo_location,
            bvn: t.bvn,
            phone: t.phone,
            profileComplete: t.profilecomplete,
            livelinessChecked: t.livelinesschecked,
            dti: t.dti,
            createdBy: createdBy
        };


    }

    private filterByStatus(pendingLoanDtos, filters) { 
        return pendingLoanDtos.filter(pendingLoanDto => {
            return Object.keys(filters).every(filter => {
                return filters[filter] === pendingLoanDto[filter]
            });
        })
     } 

}