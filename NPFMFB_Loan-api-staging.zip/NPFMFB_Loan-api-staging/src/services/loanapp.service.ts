import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { BaseInfoValueCreateDTO } from "../dto/baseinfovalue.dto";
import { CriteriaValueCreateDTO } from "../dto/criteriavalue.dto";
import { IBaseInfoValueRepository } from "../repositories/baseinfovalue.repository";
import { ICriteriaValueRepository } from "../repositories/criteriavalue.repository";
import { ILoanAppRepository } from "../repositories/loanapp.repository";
import { IBaseInfoService } from "./baseinfo.service";
import { ICriteriaService } from "./criteria.service";
import { Request } from 'express';
import { LoanAppCreateDTO } from "../dto/loanApp.dto";
import { IGuarantorService } from "./guarantor.service";
import { IGuarantorRepository } from "../repositories/guarantor.repository";
import logger from "../utils/logger";
import { BadRequestError, MissingFieldError } from "../errors/app.errors";
import { IUploadService } from "./i-upload.service";
import { ILoanCustomerService } from "./loancustomer.service";
import { IExternalService } from "./external.service";
import { ILoanProductService } from "./loanproduct.service";

export interface ILoanAppService {
    saveLoanApp(loanApp: LoanAppCreateDTO): Promise<any>;
    saveLoanAppDetails(loanApp: LoanAppCreateDTO, criteriaValues: CriteriaValueCreateDTO[], baseInfoValues: BaseInfoValueCreateDTO[]): Promise<any>;
    saveLoanAppDetailsV2(req: Request): Promise<any>;
    loadByIdWithCriteriaValuesAndBaseInfoValues(id: number): Promise<any>;
    saveLoanAppDetailsModels(criteriaValuesModels: any[], baseInfoValuesModels: any[], guarantorModels: any[], loanApp: LoanAppCreateDTO): Promise<any>;
    loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(userId: number, status: string): Promise<any>;
    validateRequest(req: Request);
    getLoanProductAmtRange(productId: number): Promise<Map<string, number>>;
    getLoanProductObjectAmtRange(product: any): Map<string, number>;
    loadLoanAppDetailsById(loanAppId: number): Promise<any>;
    getRunningLoanByCustomerIdAndLoanProductId(customerInfoId: number, loanProductId: number, status: string): Promise<any>;
}

@injectable()
export default class LoanAppService implements ILoanAppService {
    
    @inject(TYPES.LoanAppRepository) private loanAppRepository: ILoanAppRepository;

    @inject(TYPES.CriteriaValueRepository) private criteriaValueRepository: ICriteriaValueRepository;

    @inject(TYPES.BaseInfoValueRepository) private baseInfoValueRepository: IBaseInfoValueRepository;

    @inject(TYPES.BaseInfoService) private baseInfoService: IBaseInfoService;

    @inject(TYPES.CriteriaService) private criteriaService: ICriteriaService;

    @inject(TYPES.GuarantorService) private guarantorService: IGuarantorService;

    @inject(TYPES.GuarantorRepository) private guarantorRepository: IGuarantorRepository;

    @inject(TYPES.FileUploadService) private fileUploadService: IUploadService;

    @inject(TYPES.LoanCustomerService) private loanCustomerService: ILoanCustomerService;

    @inject(TYPES.ExternalService) private externalService: IExternalService;

    @inject(TYPES.LoanProductService) private loanProductService: ILoanProductService;

    getRunningLoanByCustomerIdAndLoanProductId(customerInfoId: number, loanProductId: number, status: string): Promise<any> {
        return this.loanAppRepository.loadByCustomerIdAndLoanProductIdAndStatus(customerInfoId, loanProductId, status);
      }

    saveLoanApp(loanApp: LoanAppCreateDTO): Promise<any> {
        return this.loanAppRepository.save(loanApp).then(u => {
            return u;
           })
           .catch((err: Error) => {throw err});
    }

    async validateRequest(req: Request) {

        
        if (!req.body.loanApp_loanPurpose) {
            throw new MissingFieldError('loan purpose');
        }

        if (!req.body.loanApp_amount) {
            throw new MissingFieldError('loan amount');
        }

        if (!req.body.loanApp_approvalBranch_id) {
            throw new MissingFieldError('loan approval branch');
        }

        if (!req.body.loanApp_monthlyIncome) {
            throw new MissingFieldError('Your monthly income');
        }

        let productAmtLimit = this.getLoanProductAmtRange(req.body.loan_product_id);

        if(req.body.loanApp_amount > productAmtLimit["maximum"]) {
            throw new BadRequestError("The maximum amount for the selected loan product is "+ productAmtLimit["maximum"]);
        }

        if(req.body.loanApp_amount < productAmtLimit["minimum"]) {
            throw new BadRequestError("The minimum amount for the selected loan product is "+ productAmtLimit["minimum"]);
        }


        // if(!req.body.criteriaValues_criteriaId || req.body.criteriaValues_criteriaId.length == 0) {
        //     throw new MissingFieldError('Criterias');
        // }

        
        // if(!req.body.criteriaValues_value || req.body.criteriaValues_value.length == 0) {
        //     throw new MissingFieldError('Criteria values');
        // }

        
        // if((req.body.criteriaValues_value.length != req.body.criteriaValues_criteriaId.length)) {
            
        //     throw new BadRequestError('Provided criteria details do not match');
        // }

        // if(!req.body.baseInfoValues_basicInfoId || req.body.baseInfoValues_basicInfoId.length == 0) {
        //     throw new MissingFieldError('Basic Infos');
        // }


        // if(!req.body.baseInfoValues_value || req.body.baseInfoValues_value.length == 0) {
        //     throw new MissingFieldError('Basic Info values');
        // }

        // if((req.body.baseInfoValues_basicInfoId.length != req.body.baseInfoValues_value.length)) {
        //     throw new BadRequestError('Provided Basic Info details do not match');
        // }
    }

    saveLoanAppDetailsV2(req: Request): Promise<any> {

        this.validateRequest(req);
        var criteriaValuesModels: any[] = this.criteriaService.createCriteriaValuesModelsFromRequest(req);
        var baseInfoValuesModels: any[] = this.baseInfoService.createBaseInfoValuesModelsFromRequest(req);
        var guarantorModels: any[] = this.guarantorService.createGuarantorModelsFromRequest(req);
        var loanApp = <LoanAppCreateDTO>{
            id: req.body.loanApp_id,
            name: req.body.loanApp_name,
            loan_product_id: req.body.loan_product_id,
            amount: req.body.loanApp_amount,
            user_id: req.body.loanApp_user_id,
            customer_id: req.body.loanApp_user_id,
            approvalBranch_id: req.body.loanApp_approvalBranch_id,
            monthlyIncome: req.body.loanApp_monthlyIncome,
            creditRptRequested: req.body.loanApp_creditRptRequested,
            loan_purpose: req.body.loanApp_loanPurpose,
            requested_loan_tenure: req.body.loanApp_tenure
        };

        return this.saveLoanAppDetailsModels(criteriaValuesModels, baseInfoValuesModels, guarantorModels, loanApp);
    }

    async getLoanProductAmtRange(productId: number): Promise<Map<string, number>> {

        let product = await this.loanProductService.findById(productId);
        let productAmtLimit = this.getLoanProductObjectAmtRange(product);
        return productAmtLimit;
    }

    getLoanProductObjectAmtRange(product: any): Map<string, number> {
        
        let productAmtLimit = new Map();

        productAmtLimit["maximum"] = product.limit;

        //const percent = Number(String(process.env.MIN_LOAN_AMT_PERCENTAGE_VAL)) || 10;

        //productAmtLimit["minimum"] = ((percent/100) * product.limit);
        productAmtLimit["minimum"] = Number(String(process.env.MIN_LOAN_AMT_VAL)) || 2000;

        return productAmtLimit;
    }

    saveLoanAppDetailsModels(criteriaValuesModels: any[], baseInfoValuesModels: any[], guarantorModels: any[], loanApp: LoanAppCreateDTO): Promise<any> {
        return  Promise.all([this.baseInfoValueRepository.saveOrUpdateAll(baseInfoValuesModels), 
            this.criteriaValueRepository.saveOrUpdateAll(criteriaValuesModels), this.guarantorRepository.saveOrUpdateAll(guarantorModels), this.loanAppRepository.saveOrUpdate(loanApp)])
        .then(([baseInfoVals, criteriaVals, guarantors, loanApp]) => {
            return new Promise(async (resolve, reject) => {
              
                loanApp.addBaseInfoValues(baseInfoVals);
                loanApp.addCriteriaValues(criteriaVals);
                loanApp.addGuarantors(guarantors);
                if (loanApp.id !== null) {
                    var product = await this.loanProductService.findById(loanApp.loan_product_id);
                    var dti = await this.externalService.getDebtToIncome({
                        amount: loanApp.amount,
                        monthlyIncome: loanApp.monthlyIncome,
                        tenure: product.maxTerm,
                        productId: loanApp.loan_product_id
                      });
                    await this.loanCustomerService.attachLoanToCustomer({id: loanApp.id, customer_id: loanApp.user_id, dti: parseInt(dti)});
                    console.log("Id is not empty");
                    resolve(loanApp);
                  }
                  else {
                    console.log("Id is empty");
                      reject(loanApp);
                  }
            }).catch(err => {
                logger.info(`Error in saveLoanAppDetailsModels method !`+ err);
              });
        });
    }

    saveLoanAppDetails(loanApp: LoanAppCreateDTO, criteriaValues: CriteriaValueCreateDTO[], baseInfoValues: BaseInfoValueCreateDTO[]): Promise<any> {

        var criteriaValuesModels: any[] = this.criteriaService.createCriteriaValuesModels(criteriaValues);
        var baseInfoValuesModels: any[] = this.baseInfoService.createBaseInfoValuesModels(baseInfoValues);

        return  Promise.all([this.baseInfoValueRepository.saveAll(baseInfoValuesModels), 
            this.criteriaValueRepository.saveAll(criteriaValuesModels), this.loanAppRepository.save(loanApp)])
        .then(([baseInfoVals, criteriaVals, loanApp]) => {
            return new Promise((resolve, reject) => {
              
                loanApp.addBaseInfoValues(baseInfoVals);
                loanApp.addCriteriaValues(criteriaVals);
                if (loanApp.id !== null) {
                    console.log("Id is not empty");
                    resolve(loanApp);
                  }
                  else {
                    console.log("Id is empty");
                      reject(loanApp);
                  }
            })
        });
    }

    loadByIdWithCriteriaValuesAndBaseInfoValues(id: number): Promise<any> {
        return this.loanAppRepository.loadByIdWithCriteriaValuesAndBaseInfoValues(id);
      }

    async loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(customerInfoId: number, status: string): Promise<any> {
        
        let loanAppWithAttachedFileNames = new Map();
    
        loanAppWithAttachedFileNames['loanApp'] = {};
        loanAppWithAttachedFileNames['fileNames'] = [];

        const loanApp = await this.loanAppRepository.loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(customerInfoId, status);
        if(loanApp) {
            const loanAppDetails =  await this.loanAppRepository.loadByIdWithCriteriaValuesAndBaseInfoValues(loanApp.id);
            loanAppWithAttachedFileNames['loanApp'] = loanAppDetails;
            const fileNames = await this.fileUploadService.getFileUploadByLoanAppId(parseInt(loanAppDetails.id));
            if(fileNames) {
                loanAppWithAttachedFileNames['fileNames'] = fileNames;
            }
        }
        return loanAppWithAttachedFileNames;
    }

    async loadLoanAppDetailsById(loanAppId: number): Promise<any> {
        const loanApp = await this.loadByIdWithCriteriaValuesAndBaseInfoValues(loanAppId);
        const fileNames = await this.fileUploadService.getFileUploadByLoanAppId(loanAppId);
        const basicInfoFiles = await this.fileUploadService.getBasicInfoValFileUploadByLoanAppId(loanAppId);
        const criteriaValFiles = await this.fileUploadService.getCriteriaValFileUploadByLoanAppId(loanAppId);

        let loanAppDetails = new Map();

        loanAppDetails['loanApp'] = loanApp;
        loanAppDetails['fileNames'] = fileNames;
        loanAppDetails['basicInfoFiles'] = basicInfoFiles;
        loanAppDetails['criteriaValFiles'] = criteriaValFiles;
        return loanAppDetails;
    }
}