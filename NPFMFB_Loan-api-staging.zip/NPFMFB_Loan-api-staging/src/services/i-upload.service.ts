import { Request, Response } from 'express';
export interface IUploadService {
    doFileUpload(req: any, res: any): Promise<any>;
    doFileUploadWithIdentifier(req: Request, res: Response, id: number): Promise<any>;
    getFileUploadByLoanAppId(loanAppId: number): Promise<any>;
    saveFileUploads(resp: any, id: number): void;
    getBasicInfoValFileUploadByLoanAppId(loanAppId: number): Promise<any>;
    getCriteriaValFileUploadByLoanAppId(loanAppId: number): Promise<any>;
    
}