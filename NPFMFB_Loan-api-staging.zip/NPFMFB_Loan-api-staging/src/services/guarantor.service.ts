import { injectable } from "inversify";
import { GuarantorCreateDTO } from "../dto/guarantor.dto";
import { Request } from 'express';

export interface IGuarantorService {
    createGuarantorModels (guarantors: GuarantorCreateDTO[]) : any[];
    createGuarantorDtos (req: Request) : any[];
    createGuarantorModelsFromRequest (req: Request) : any[];
}

@injectable()
export default class GuarantorService implements IGuarantorService {

    createGuarantorModelsFromRequest(req: Request): any[] {
        var guarantors: GuarantorCreateDTO[] = this.createGuarantorDtos (req);
       
        return this.createGuarantorModels(guarantors);
    }

    createGuarantorModels(guarantors: GuarantorCreateDTO[]): any[] {
        var guarantorModels: any[] = new Array();
        guarantors.forEach( g => {
            var guarantorModel = {};
            guarantorModel["name"] = g.name;
            guarantorModel["accountNumber"] = g.accountNo;
            if(g.id) {
                guarantorModel["id"] = g.id;
            }

            guarantorModels.push(guarantorModel);
        } );
        return guarantorModels;
    }
    createGuarantorDtos(req: Request): any[] {
        var guarantorDtos: any[] = new Array();
        if(req.body.guarantor_name && req.body.guarantor_acctNo) {
            var requestArrayCnt: number = req.body.guarantor_name.length;
            for(var counter: number = 0; counter < requestArrayCnt; counter++){
            var guarantor: GuarantorCreateDTO = {} as GuarantorCreateDTO;
            if(req.body.guarantors_id && !isNaN(Number(req.body.guarantors_id[counter]))){
                    guarantor.id = req.body.guarantors_id[counter];
            }
            guarantor.name = req.body.guarantor_name[counter];
            guarantor.accountNo = req.body.guarantor_acctNo[counter];
            guarantorDtos.push(guarantor);
            }
        }
        
        return guarantorDtos;
    }
    
}