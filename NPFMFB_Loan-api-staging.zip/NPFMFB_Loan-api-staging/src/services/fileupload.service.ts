
import { inject, injectable } from "inversify";
import * as multer from 'multer';
import { BadRequestError } from "../errors/app.errors";
import { IUploadService } from "./i-upload.service";
import * as util from 'util';
import { TYPES } from "../configs/types";
import { IFileUploadRepository } from "../repositories/fileupload.repository";
import { Request, Response } from 'express';
import { IBasicInfoFileUploadRepository } from "../repositories/basicinfovalfileupload.repository";
import { ICriteriaFileUploadRepository } from "../repositories/criteriavaluefileupload.repository";


const storage = multer.diskStorage({    destination: function (_req, _file, cb) {
        cb(null, process.env.UPLOAD_DIR)
    },

    filename: function (_req: any, file: any, cb: any) {
        cb(null, file.originalname)
    }
});

const fileFilter = (_req: any,file: any,cb: any) => {
if(file.mimetype === "image/jpg"  || 
   file.mimetype ==="image/jpeg"  || 
   file.mimetype ===  "image/png"){
 
cb(null, true);
}else{
  cb(new Error("Image uploaded is not of type jpg/jpeg  or png"),false);
}}

const upload = multer({storage: storage, fileFilter : fileFilter});

@injectable()
export default class FileUploadService implements IUploadService {

  @inject(TYPES.FileUploadRepository) private fileUploadRepository: IFileUploadRepository;

  @inject(TYPES.BasicInfoFileUploadRepository) private basicInfoFileUploadRepository: IBasicInfoFileUploadRepository;

  @inject(TYPES.CriteriaFileUploadRepository) private criteriaFileUploadRepository: ICriteriaFileUploadRepository;

    public uploadConfig: any;
    private uploadConfig2: any;

    constructor() {
        this.uploadConfig = multer({
          storage: multer.diskStorage({
              destination: function (_req, _file, cb) {
                cb(null, process.env.UPLOAD_DIR)
              },
              filename: function (_req, file, cb) {
                cb(null, file.fieldname + '-' + Date.now())
              }
            }),
        });

          this.uploadConfig2 = upload;
      }

  getFileUploadByLoanAppId(loanAppId: number): Promise<any> {
    return this.fileUploadRepository.findByLoanAppId(loanAppId);
  }

  getBasicInfoValFileUploadByLoanAppId(loanAppId: number): Promise<any> {
    return this.basicInfoFileUploadRepository.findByLoanAppId(loanAppId);
  }

  getCriteriaValFileUploadByLoanAppId(loanAppId: number): Promise<any> {
    return this.criteriaFileUploadRepository.findByLoanAppId(loanAppId);
  }
  async doFileUploadWithIdentifier(req: Request, res: Response, id: number): Promise<any> {
    console.log("doFileUploadWithIdentifier");
    const resp = await this.doFileUpload(req, res);
    this.saveFileUploads2(resp, id);
  }

  saveFileUploads(resp: any, id: number) {
    var fileUploadModels: any[] = new Array();
    resp.data.forEach(d => {
      console.log("d======"+d);
      fileUploadModels.push({
        "fileName": d,
        "loan_app_id": id
      });
    });
    this.fileUploadRepository.saveAll(fileUploadModels);
  }

  saveFileUploads2(resp: any, id: number) {
    console.log("saveFileUploads2=====d");
    var fileUploadModels: any[] = new Array();
    var basicInfoValueFileUploadModels: any[] = new Array();
    var criteriaValueFileUploadModels: any[] = new Array();

    resp.data.forEach(d => {
      if (d. indexOf('_BI_') !== -1) {
        basicInfoValueFileUploadModels.push({
          "fileName": d,
          "base_info_id": d.split('_')[0],
          "loan_app_id": id
        });
      }else if (d. indexOf('_CV_') !== -1) {
        criteriaValueFileUploadModels.push({
          "fileName": d,
          "criteria_id": d.split('_')[0],
          "loan_app_id": id
        });
      }else {
        fileUploadModels.push({
          "fileName": d,
          "loan_app_id": id
        });
      }
      
    });
    
    if(fileUploadModels.length > 0) {
      this.fileUploadRepository.saveAll(fileUploadModels);
    }
    if(basicInfoValueFileUploadModels.length > 0){
      this.basicInfoFileUploadRepository.saveAll(basicInfoValueFileUploadModels);
    }
    
    if(criteriaValueFileUploadModels.length > 0) {
      this.criteriaFileUploadRepository.saveAll(criteriaValueFileUploadModels);
    }
    
  }

      public getUploadConfig () {
        return this.uploadConfig;
    }

    public getUploadConfig2 () {
        return this.uploadConfig2;
    }

    async doFileUpload(req: Request, res: Response): Promise<any> {
      try {
            let files = req.files;
            const upload = util.promisify(this.uploadConfig.any());
            await upload(req, res);

            let filenames: string[] = [];
            for(var index in files) { 
              filenames.push(files[index].filename);
            }
            return {status: "success", data:filenames};
        } catch (error) {
          console.log(error);
          throw new BadRequestError(`Failed to upload image file: ${error}`);
    }
  }

    async upload4(req: any, res: any): Promise<any> {
        try {
            this.doupload(req, res, function(error) {
              throw new BadRequestError(`Failed to upload image file: ${error}`);
              
            });
            return {status: "success", data:"File uploaded"};
          } catch (error) {
            console.log(error);
            throw new BadRequestError(`Failed to upload image file: ${error}`);
      }
    }



    async upload3(req: any, res: any): Promise<any> {
        var resp: any;
        try {
            this.doupload(req, res, function(error) {
              if (error) {
                console.log(error);
                resp = new Promise((resolve, _reject) => {
                    resolve({status: "error", message:`Failed to upload image file: ${error}`});
                });
                return {status: "error", message:`Failed to upload image file: ${error}`};
              }
              resp =  new Promise((resolve, _reject) => {
                resolve({status: "success", message:`${req.files[0].filename}`});
            });
              return {status: "success", message:`${req.files[0].filename}`};
              
            }
            );
          } catch (error) {
            console.log(error);
            resp =  new Promise((resolve, _reject) => {
                resolve({status: "error", message:`Failed to upload image file: ${error}`});
            });
      }
      
      return resp;
    }

   async upload2(req: any, res: any): Promise<any> {
        try {
            this.doupload(req, res, function(error) {
              if (error) {
                console.log(error);
                return res.status(404).json({status: "error", message:`Failed to upload image file: ${error}`});
                
              }
              return res.status(201).json({status: "success", message:`${req.files[0].filename}`});
              
            });
          } catch (error) {
            console.log(error);
            return res.status(500).json({status: "error", message:`Failed to upload image file: ${error}`});
      }
    }

    doupload = multer({
        storage: multer.diskStorage({
            destination: function (_req, _file, cb) {
              cb(null, process.env.UPLOAD_DIR)
            },
            filename: function (_req, file, cb) {
              cb(null, file.fieldname + '-' + Date.now())
            }
          }),
      }).array('upload', 1);

}