import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { IBranchRepository } from "../repositories/branch.repository";

export interface IBranchService {
    createBranch(data: any): Promise<any>;
    loadAll(): Promise<any>;
    getById(id: number): Promise<any>;
    updateById(data: any, id: number): Promise<any>;
    createMany(data: any[]): Promise<any>;
}

@injectable()
export default class BranchService implements IBranchService {

    @inject(TYPES.BranchRepository) private branchRepository: IBranchRepository;

    createBranch(data: any): Promise<any> {
        return this.branchRepository.save(data);
    }
    createMany(data: any[]): Promise<any> {
        return this.branchRepository.saveAll(data);
    }
    loadAll(): Promise<any> {
        return this.branchRepository.findAll();
    }
    getById(id: number): Promise<any> {
        return this.branchRepository.findById(id);
    }
    updateById(data: any, id: number): Promise<any> {
        return this.branchRepository.update(data, id);
    }

}