import { inject, injectable } from "inversify";
import axios from 'axios';
import logger from "../utils/logger";
import { DebtToIncomeDTO } from "../dto/debttoincome.dto";
import { TYPES } from "../configs/types";
import { ILoanProductService } from "./loanproduct.service";
import { InvalidTokenError } from "../errors/app.errors";

export interface IExternalService {
    getDebtToIncome(data: DebtToIncomeDTO): Promise<any>;
    getCreditStatus(_data: any): Promise<any>;
    getCustomerInfo(_id: number): Promise<any>;
    getCustomerDetailsByToken(token: String): Promise<any>;
    getAdminDetailsByToken(token: string): Promise<any>;
}

@injectable()
export default class ExternalService implements IExternalService {

    @inject(TYPES.LoanProductService) private loanProductService: ILoanProductService;

    async getDebtToIncome(data: DebtToIncomeDTO): Promise<any> {
        const productModel = await this.loanProductService.findById(data.productId);
        var product = productModel.get({ plain: true });

        return new  Promise<any>((res, _rej) => {
            var tenure = product.maxTermUnit == 'years' ? product.maxTerm * 12 : product.maxTerm;
            const monthlyAmt: number = data.amount/tenure;
            const debtToIncome: number = (monthlyAmt/data.monthlyIncome) * 100;
            res(debtToIncome.toFixed(1));
          }).catch(err => {
            logger.error('Error fetching debt to incom info ' + err);
          });
    }

    getCreditStatus(_data: any): Promise<any> {
        return new  Promise<number>((res, _rej) => {
            res(Number(String(process.env.CREDIT_STATUS)));
          });
    }

    getCustomerInfo(id: number): Promise<any> {
            return axios.get(
                `${process.env.CUSTOMER_DETAILS_SERVER_URL}/customerinfos/id/${id}`, {
                    auth: {
                        username: process.env.CUSTOMER_DETAILS_SERVER_BASIC_AUTH_USERNAME,
                        password: process.env.CUSTOMER_DETAILS_SERVER_BASIC_AUTH_PASSWORD
                      }
                }
                
              ).then(response => {
                return response.data;
            }).catch(err => {
                logger.error('Error fetching customer info ' + err);
            });
        
    }

    getCustomerDetailsByToken(token: string): Promise<any> {
        var retrievedToken = this.retrieveToken(token);
        return axios.get(
            `${process.env.CUSTOMER_DETAILS_SERVER_URL}/auth/check_loan`, {
                headers: { 
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${retrievedToken}`
                }
            }
            
          ).then(response => {
            return response.data;
        }).catch(err => {
            logger.error('Error fetching customer info ' + err);
            return {};
        });
    }

    getAdminDetailsByToken(token: string): Promise<any> {
        var retrievedToken = this.retrieveToken(token);
        return axios.get(
            `${process.env.CUSTOMER_DETAILS_SERVER_URL}/auth/check_admin`, {
                headers: { 
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${retrievedToken}`
                }
            }
            
          ).then(response => {
            return response.data;
        }).catch(err => {
            logger.error('Error fetching admin info ' + err);
            return {};
        });
    }


    private retrieveToken(token: string) {
        var retrievedToken = "";
        if(!token) {
            throw new InvalidTokenError("Invalid token provided!");
        }
        if (token.startsWith("JWT ")) {
            retrievedToken = token.split(/ (.+)/)[1];
        } else {
            retrievedToken = token;
        }
        return retrievedToken;
    }
}