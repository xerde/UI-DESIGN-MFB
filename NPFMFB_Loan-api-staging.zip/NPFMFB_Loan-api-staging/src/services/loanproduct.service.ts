import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { ILoanProductRepository } from "../repositories/loanproduct.repository";

export interface ILoanProductService {
    saveLoanProduct(t: any): Promise<any>;
    saveLoanProducts(data: any[]): Promise<any>;
    loadWithCategory(t: number): Promise<any>;
    loadAllWithCategory(): Promise<any>;
    updateById(data: any, id: number): Promise<any>;
    findById(id: number): Promise<any>;
    likeSearchByName(name: string): Promise<any>;
}

@injectable()
export default class LoanProductService implements ILoanProductService {
    
    @inject(TYPES.LoanProductRepository) private loanProductRepository: ILoanProductRepository;

    findById(id: number): Promise<any> {
        return this.loanProductRepository.findById(id);
    }

    updateById(data: any, id: number): Promise<any> {
        return this.loanProductRepository.update(data, id);
    }

    saveLoanProducts(data: any[]): Promise<any> {
        return this.loanProductRepository.saveAll(data);
    }

  
    saveLoanProduct(t: any): Promise<any> {
        return this.loanProductRepository.save(t);
    }

    loadAllWithCategory(): Promise<any> {
        return this.loanProductRepository.findAll();
      }

    loadWithCategory(t: number): Promise<any> {
        return this.loanProductRepository.loadWithCategory(t)
        .catch(err => {
            console.log(`Error fetching loanProduct by id with category in repository!`+ err + "****"+ t+ "*****t");
          });
      }

      likeSearchByName(name: string): Promise<any> {
        return this.loanProductRepository.likeSearchByName(name)
        .catch(err => {
            console.log(`Error fetching loanProducts by name search with category in repository!`+ err + "****"+ name+ "*****t");
          });
    }

}