import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { ILoanAppRepository } from "../repositories/loanapp.repository";

export interface IDashboardService {
    getDashboardInfo(): Promise<any>;
}

/*
dashboard: {
   new_applications: "",
   upcoming_disbursement: "",
   total_loan_value: "",
   total_repayments: ""
}
*/
@injectable()
export default class DashboardService implements IDashboardService {

    @inject(TYPES.LoanAppRepository) private loanAppRepository: ILoanAppRepository;

    async getDashboardInfo(): Promise<any> {

        let dashboardInfo = new Map();

        dashboardInfo["new_applications"] = await this.loanAppRepository.getCountByStatus("PENDING");
        dashboardInfo["upcoming_disbursement"] = 0;
        let totalLoanValue = await this.loanAppRepository.getTotalLoanValue();
        dashboardInfo["total_loan_value"] = totalLoanValue;
        let totalRepayments = await this.loanAppRepository.getTotalLoanAmountRepayments();
        dashboardInfo["total_repayments"] = totalRepayments;
        
        return dashboardInfo;
    }
}