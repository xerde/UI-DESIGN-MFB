import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { MissingFieldError } from "../errors/app.errors";
import { ICriteriaService } from "../services/criteria.service";


@injectable()
export default class CriteriaController {
  @inject(TYPES.CriteriaService) private criteriaService: ICriteriaService

  constructor() {}

public async get(_req: Request, res: Response): Promise<any> {

  try {
    const resp = await this.criteriaService.loadAll();
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get base info by id: ${error}` });
  }
}

public async getById(req: Request, res: Response): Promise<any> {

  if (!req.params.id) {
    throw new MissingFieldError('id');
  }

  try {
    const resp = await this.criteriaService.getById(parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get base info by id: ${error}` });
  }
}

public async updateById(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
      throw new MissingFieldError('id');
    }

    try {
      const resp = await this.criteriaService.updateById(req.body, parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update base info by id: ${error}` });
    }
}
}