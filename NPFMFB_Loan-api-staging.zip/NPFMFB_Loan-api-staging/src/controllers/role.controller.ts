import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { IRoleService } from "../services/role.service";
import { Request, Response } from 'express';
import { MissingFieldError } from "../errors/app.errors";

@injectable()
export default class RoleController {
  @inject(TYPES.RoleService) private roleService: IRoleService;

  constructor() {}

  public async saveMultipleRoles(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.roleService.createManyRoles(req.body);
      
      return res.status(201).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create multiple Roles: ${error}` });
    }
}

public async saveRole(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.roleService.createRole(req.body);
      
      return res.status(201).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create a Role: ${error}` });
    }
}

public async getRoleById(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
        throw new MissingFieldError('id');
      }

    try {
      const resp = await this.roleService.findById(parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update a Role: ${error}` });
    }
}

public async getRoles(_req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.roleService.getRoles();
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update a Role: ${error}` });
    }
}

public async updateRole(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
        throw new MissingFieldError('id');
      }

    try {
      const resp = await this.roleService.updateRole(req.body, parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update a Role: ${error}` });
    }
}

}