import { inject, injectable } from "inversify";
import { Request, Response } from 'express';
import { TYPES } from "../configs/types";
import { IExternalService } from "../services/external.service";
import { MissingFieldError } from "../errors/app.errors";
import { DebtToIncomeDTO } from "../dto/debttoincome.dto";

@injectable()
export class ExternalController {

  @inject(TYPES.ExternalService) private externalService: IExternalService;


  public async getDebtToIncome(req: Request, res: Response): Promise<any> {

    try {

      var debtToIncomeDTO = <DebtToIncomeDTO>{
        amount: req.body.loanApp_amount,
        monthlyIncome: req.body.loanApp_monthlyIncome,
        productId: req.body.loan_product_id,
        
    };
      const resp = await this.externalService.getDebtToIncome(debtToIncomeDTO);
      
      return res.status(200).json({status: "success", data: resp });
  
  
  
    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to get debt to income info : ${error}` });
    }
  }

  public async getCreditLookup(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.externalService.getCreditStatus(req);
      
      return res.status(200).json({status: "success", data: resp });
  
  
  
    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to get Credit Lookup info : ${error}` });
    }
  }

  public async getCustomerDetails(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
      throw new MissingFieldError('id');
    }
    
    try {
      const resp = await this.externalService.getCustomerInfo(parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });
  
  
  
    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to get Customer Details : ${error}` });
    }
  }

  public async getCustomerTokenStatus(req: Request, res: Response): Promise<any> {
    try {
      var resp = await this.externalService.getCustomerDetailsByToken(req.header('Authorization'));
      var status = "success"

      if(!resp) {
        resp = {};
        status = "error"
      }
      
      return res.status(200).json({status: status, data: resp });
  
    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to get Customer Details : ${error}` });
    }
  }

}