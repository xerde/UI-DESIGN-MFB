import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { IBaseInfoService } from "../services/baseinfo.service";
import { MissingFieldError } from "../errors/app.errors";


@injectable()
export default class BaseInfoController {
  @inject(TYPES.BaseInfoService) private baseInfoService: IBaseInfoService

  constructor() {}

  public async saveBaseInfo(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.baseInfoService.create(req.body);
      
      return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed create base info: ${error}` });
    }
}

public async saveMultipleBaseInfos(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.baseInfoService.createMany(req.body);
      
      return res.status(201).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create multiple base infos: ${error}` });
    }
}

public async get(_req: Request, res: Response): Promise<any> {

  try {
    const resp = await this.baseInfoService.loadAll();
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get base info by id: ${error}` });
  }
}

public async getById(req: Request, res: Response): Promise<any> {

  if (!req.params.id) {
    throw new MissingFieldError('id');
  }

  try {
    const resp = await this.baseInfoService.getById(parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get base info by id: ${error}` });
  }
}

public async updateById(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
      throw new MissingFieldError('id');
    }

    try {
      const resp = await this.baseInfoService.updateById(req.body, parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update base info by id: ${error}` });
    }
}
}