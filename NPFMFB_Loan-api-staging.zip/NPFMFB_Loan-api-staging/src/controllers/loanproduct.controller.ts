import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { ILoanProductService } from "../services/loanproduct.service";
import { MissingFieldError } from "../errors/app.errors";
import { IBaseInfoService } from "../services/baseinfo.service";


@injectable()
export default class LoanProductController {
 
  @inject(TYPES.LoanProductService) private loanProductService: ILoanProductService;

  @inject(TYPES.BaseInfoService) private baseInfoService: IBaseInfoService;

  constructor() {}

  public async saveLoanProduct(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.loanProductService.saveLoanProduct(req.body);
      
      return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create LoanProduct : ${error}` });
    }
    
}

public async saveLoanProducts(req: Request, res: Response): Promise<any> {

  try {
    const resp = await this.loanProductService.saveLoanProducts(req.body);
    
    return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to create many LoanProducts : ${error}` });
  }
}

public async getById(req: Request, res: Response): Promise<any> {
    if (!req.params.id) {
      throw new MissingFieldError('id');
    }
    const product = await this.loanProductService.loadWithCategory(parseInt(req.params.id));
    const baseInfos = await this.baseInfoService.loadByRequiredApplicantInput();
    
    let productWithCategory = new Map();
    
    productWithCategory['product'] = product;
    productWithCategory['baseInfos'] = baseInfos;

    return res.status(200).json({status: "success", data: productWithCategory });
}
public async get(_req: Request, res: Response): Promise<any> {

  
  const product = await this.loanProductService.loadAllWithCategory();
  const baseInfos = await this.baseInfoService.loadByRequiredApplicantInput();
  
  
  let productWithCategory = new Map();
  
  productWithCategory['products'] = product;
  productWithCategory['baseInfos'] = baseInfos;
  return res.status(200).json({status: "success", data: productWithCategory });
}

public async likeSearchByName(req: Request, res: Response): Promise<any> {

  if (!req.params.name) {
    throw new MissingFieldError('name');
  }
  
  const product = await this.loanProductService.likeSearchByName(req.params.name);
  
  
  let productWithCategory = new Map();
  
  productWithCategory['products'] = product;
  return res.status(200).json({status: "success", data: productWithCategory });
}

public async updateById(req: Request, res: Response): Promise<any> {

  if (!req.params.id) {
    throw new MissingFieldError('id');
  }

  try {
    const resp = await this.loanProductService.updateById(req.body, parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to update base info by id: ${error}` });
  }
}
}