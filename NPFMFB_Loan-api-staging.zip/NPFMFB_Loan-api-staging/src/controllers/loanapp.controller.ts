import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { BadRequestError, InvalidTokenError, MissingFieldError } from "../errors/app.errors";
import { ILoanAppService } from "../services/loanapp.service";
import { IUploadService } from "../services/i-upload.service";
import { IBaseInfoService } from "../services/baseinfo.service";
import { IExternalService } from "../services/external.service";
import { IBranchService } from "../services/branch.service";
import { IAuthService } from "../services/diauth.service";
import { ILoanCustomerService } from "../services/loancustomer.service";
import { ILoanProductService } from "../services/loanproduct.service";
import { IDashboardService } from "../services/dashboard.service";

@injectable()
export default class LoanAppController {
  @inject(TYPES.LoanAppService) private loanAppService: ILoanAppService;

  @inject(TYPES.LoanCustomerService) private loanCustomerService: ILoanCustomerService;

  @inject(TYPES.FileUploadService) private fileUploadService: IUploadService;

  @inject(TYPES.BaseInfoService) private baseInfoService: IBaseInfoService;

  @inject(TYPES.ExternalService) private externalService: IExternalService;

  @inject(TYPES.BranchService) private branchService: IBranchService;

  @inject(TYPES.DiAuthService) private diAuthServiceInstance: IAuthService;

  @inject(TYPES.LoanProductService) private loanProductService: ILoanProductService;

  @inject(TYPES.DashboardService) private dashboardService: IDashboardService;
  
  constructor() {}


  public async adminViewApplications(req: Request, res: Response): Promise<any> {

    const adminDetails = await this.externalService.getAdminDetailsByToken(req.header('Authorization'));

    
    if(!adminDetails || !adminDetails.data || Object.entries(adminDetails.data).length === 0) {
      throw new InvalidTokenError("ACCESS");
    }

    const loans = await this.loanCustomerService.getLoanCustomersDto()

    let pendingLoanApp = new Map();

    pendingLoanApp['loans'] = loans;
    pendingLoanApp['token'] = this.diAuthServiceInstance.genTokenForEftAdmin(adminDetails.data.id);
    pendingLoanApp['dashboard'] = await this.dashboardService.getDashboardInfo();
  
    return res.status(200).json({status: "success", data: pendingLoanApp });
  }


  public async startApplication(req: Request, res: Response): Promise<any> {

    const customerDetails = await this.externalService.getCustomerDetailsByToken(req.header('Authorization'));

    var pendingLoanApp = {};

    if(!customerDetails || !customerDetails.data) {
      throw new InvalidTokenError("ACCESS");
    }

    pendingLoanApp = await this.loanAppService.loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(customerDetails.data.id, 'PENDING')

    if(!pendingLoanApp || Object.entries(pendingLoanApp["loanApp"]).length === 0){
      await this.loanCustomerService.saveLoanCustomer(this.loanCustomerService.createLoanCustomerDTO(customerDetails.data));
    }
    
    
    const branches = await this.branchService.loadAll();
    const products = await this.loanProductService.loadAllWithCategory();
    const baseInfos = await this.baseInfoService.loadByRequiredApplicantInput();
    
    let productWithCategory = new Map();

    productWithCategory['minimumAmount'] = Number(String(process.env.MIN_LOAN_AMT_VAL)) || 2000;
    productWithCategory['products'] = products;
    productWithCategory['baseInfos'] = baseInfos;
    productWithCategory['pendingLoanApp'] = pendingLoanApp;
    productWithCategory['customerDetails'] = customerDetails;
    productWithCategory['branches'] = branches;
    productWithCategory['token'] = this.diAuthServiceInstance.genTokenForEftCustomer(customerDetails.data.id);
  
    return res.status(200).json({status: "success", data: productWithCategory });
  }

  public async saveLoanAppWithAttachments(req: Request, res: Response): Promise<any> {

    try {

      let existingSameRunningLoanApplication = await this.loanAppService.getRunningLoanByCustomerIdAndLoanProductId(req.body.loanApp_user_id, req.body.loan_product_id, 'RUNNING');

      if(existingSameRunningLoanApplication) {
        throw new BadRequestError('Selected loan already running for the customer!');
      }
    

      const resp = await this.loanAppService.saveLoanAppDetailsV2(req);
      this.fileUploadService.doFileUploadWithIdentifier(req, res, resp.id);
      
      return res.status(201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create LoanProduct with CriteriaValues : ${error}` });
    }
}

public async saveLoanApp(req: Request, res: Response): Promise<any> {

  try {
    
    const resp = await this.loanAppService.saveLoanAppDetails(req.body.loanApp, req.body.criteriaValues, req.body.baseInfoValues);
    
    return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to create LoanProduct with CriteriaValuesxxxxxxxx : ${error}` });
  }
}

public async get(req: Request, res: Response): Promise<any> {
    if (!req.params.id) {
      throw new MissingFieldError('id');
    }
    
    let loanAppDetails = await this.loanAppService.loadLoanAppDetailsById(parseInt(req.params.id));
    
    return res.status(200).json({status: 200, data: loanAppDetails });
}

public async getPending(req: Request, res: Response): Promise<any> {

  if (!req.params.userid) {
    throw new MissingFieldError('userid');
  }

    const loanApp = await this.loanAppService.loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(parseInt(req.params.userid), 'PENDING');
    
    return res.status(200).json({status: 200, data: loanApp });
}
}