import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { MissingFieldError } from "../errors/app.errors";
import { ILoanProductCategoryService } from "../services/loanproductcategory.service";


@injectable()
export default class LoanProductCategoryController {
 
  @inject(TYPES.LoanProductCategoryService) private loanProductCategoryService: ILoanProductCategoryService;

  constructor() {}

  public async saveLoanProductCategoriesWithCriteria(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.loanProductCategoryService.saveLoanProductCategoriesWithCriteria(req);
      
      return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create LoanProduct Category with Criteria: ${error}` });
    }
}

  public async saveLoanProductCategoryWithCriteria(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.loanProductCategoryService.saveLoanProductCategoryWithCriteria(req.body.loanProductCategory, req.body.criterias);
      
      return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create LoanProduct Category with Criteria: ${error}` });
    }
}

public async getById(req: Request, res: Response): Promise<any> {
    if (!req.params.id) {
      throw new MissingFieldError('id');
    }
    const category = await this.loanProductCategoryService.loadWithCriteria(parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: category });
}
public async get(_req: Request, res: Response): Promise<any> {
    try {
  const category = await this.loanProductCategoryService.loadAllWithCriteria();
  
  return res.status(200).json({status: "success", data: category });
} catch (error) {
    return res.status(500).send({ status: "error", data: `Failed to get LoanProduct Categories with Criteria: ${error}` });
}
}

public async updateById(req: Request, res: Response): Promise<any> {

  if (!req.params.id) {
    throw new MissingFieldError('id');
  }

  try {
    const resp = await this.loanProductCategoryService.updateById(req.body, parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to update LoanProduct Category by id: ${error}` });
  }
}

public async attachCriteriaToLoanProductCategory(req: Request, res: Response): Promise<any> {
  if (!req.params.id) {
    throw new MissingFieldError('id');
  }
  const product = await this.loanProductCategoryService.attachNewCriteriaToExistingLoanProductCategory(req.body, parseInt(req.params.id));

  return res.status(201).json({status: "success", data: product });
}

public async getLoanProductCategoriesByCategoryType(req: Request, res: Response): Promise<any> {
  if (!req.params.categoryType) {
    throw new MissingFieldError('categoryType');
  }
  
  const product = await this.loanProductCategoryService.loadManyWithCriteriaByCategoryType(req.params.categoryType);

  return res.status(200).json({status: "success", data: product });
}


}