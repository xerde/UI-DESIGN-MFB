import { inject, injectable } from "inversify";
import { TYPES } from "../configs/types";
import { Request, Response } from 'express';
import { MissingFieldError } from "../errors/app.errors";
import { IBranchService } from "../services/branch.service";


@injectable()
export default class BranchController {
  @inject(TYPES.BranchService) private branchService: IBranchService

  constructor() {}

  public async saveBranch(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.branchService.createBranch(req.body);
      
      return res.status(resp.status === "success" ? 201: 201).json({status: 201, data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed create branch : ${error}` });
    }
}

public async saveMultipleBranches(req: Request, res: Response): Promise<any> {

    try {
      const resp = await this.branchService.createMany(req.body);
      
      return res.status(201).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to create multiple branches: ${error}` });
    }
}

public async get(_req: Request, res: Response): Promise<any> {

  try {
    const resp = await this.branchService.loadAll();
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get branches: ${error}` });
  }
}

public async getById(req: Request, res: Response): Promise<any> {

  if (!req.params.id) {
    throw new MissingFieldError('id');
  }

  try {
    const resp = await this.branchService.getById(parseInt(req.params.id));
    
    return res.status(200).json({status: "success", data: resp });



  } catch (error) {
      return res.status(500).send({ status: "error", data: `Failed to get branch by id: ${error}` });
  }
}

public async updateById(req: Request, res: Response): Promise<any> {

    if (!req.params.id) {
      throw new MissingFieldError('id');
    }

    try {
      const resp = await this.branchService.updateById(req.body, parseInt(req.params.id));
      
      return res.status(200).json({status: "success", data: resp });



    } catch (error) {
        return res.status(500).send({ status: "error", data: `Failed to update branch by id: ${error}` });
    }
}
}