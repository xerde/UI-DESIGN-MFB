"use strict";

module.exports = function (sequelize, DataTypes) {
  var BaseInfoValue = sequelize.define(
    "BaseInfoValue",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      value: { type: DataTypes.STRING, allowNull: false },
      base_info_id: { type: DataTypes.INTEGER, allowNull: false }
    },
    {
      timestamps: true,
      tableName: "base_info_values",
      freezeTableName: true
    }
  );

  BaseInfoValue.associate = function (models) {
    BaseInfoValue.belongsTo(models.BaseInfo, {
      foreignKey: "base_info_id", as: 'baseInfo'
    });
  };
  return BaseInfoValue;
};