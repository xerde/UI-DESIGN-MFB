"use strict";

module.exports = function (sequelize, DataTypes) {
  var LoanCustomer = sequelize.define(
    "LoanCustomer",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      customer_id: { type: DataTypes.INTEGER, allowNull: false},
      name: { type: DataTypes.STRING, allowNull: false },
      email: { type: DataTypes.STRING, allowNull: false },
      photo_location: { type: DataTypes.STRING, allowNull: false },
      bvn: { type: DataTypes.STRING, allowNull: true },
      phone: { type: DataTypes.STRING, allowNull: false },
      profilecomplete: { type: DataTypes.STRING, allowNull: false },
      livelinesschecked: { type: DataTypes.STRING, allowNull: false },
      dti: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0},
      createdBy: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0}
    },
    {
      timestamps: true,
      freezeTableName: true
    }
  );

  LoanCustomer.associate = function (models) {
    LoanCustomer.belongsTo(models.LoanApp, {
      foreignKey: "loan_app_id", as: 'loanApp'
    });
  };
  return LoanCustomer;
};