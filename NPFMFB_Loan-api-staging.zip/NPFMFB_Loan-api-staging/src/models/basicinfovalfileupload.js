"use strict";

module.exports = function (sequelize, DataTypes) {
  var BasicInfoValueFileUpload = sequelize.define(
    "BasicInfoValueFileUpload",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      fileName: { type: DataTypes.STRING, allowNull: false },
      loan_app_id: { type: DataTypes.INTEGER, allowNull: false },
      base_info_id: { type: DataTypes.INTEGER, allowNull: false }
    },
    {
      timestamps: true,
      tableName: "basic_info_val_file_uploads",
      freezeTableName: true
    }
  );

  BasicInfoValueFileUpload.associate = function (models) {

    BasicInfoValueFileUpload.belongsTo(models.BaseInfo, {
      foreignKey: "base_info_id", as: 'baseInfo'
    });
    BasicInfoValueFileUpload.belongsTo(models.LoanApp, {
      foreignKey: "loan_app_id", as: 'loanApp'
    });
  };
  return BasicInfoValueFileUpload;
};
