"use strict";

module.exports = function (sequelize, DataTypes) {
  var BaseInfo = sequelize.define(
    "BaseInfo",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      code: { type: DataTypes.STRING, allowNull: false, unique: true },
      name: { type: DataTypes.STRING, allowNull: false },
      description: { type: DataTypes.STRING, allowNull: false },
      required: { type: DataTypes.BOOLEAN, allowNull: true, defaultValue: false},
      inputType: { type: DataTypes.STRING, allowNull: false },
      optionValues: { type: DataTypes.ARRAY(DataTypes.STRING), allowNull: false, defaultValue: [] },
      applicantInputNeeded: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false},

    },
    {
      timestamps: true,
      tableName: "base_info",
      freezeTableName: true
    }
  );
  return BaseInfo;
};
