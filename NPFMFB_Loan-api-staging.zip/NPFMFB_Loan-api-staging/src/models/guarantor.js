"use strict";

module.exports = function (sequelize, DataTypes) {
  var Guarantor = sequelize.define(
    "Guarantor",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      name: { type: DataTypes.STRING, allowNull: false },
      accountNumber: { type: DataTypes.STRING, allowNull: false },
      guarantorForm: { type: DataTypes.STRING, allowNull: true }
    },
    {
      timestamps: true,
      tableName: "guarantors",
      freezeTableName: true
    }
  );
  return Guarantor;
};