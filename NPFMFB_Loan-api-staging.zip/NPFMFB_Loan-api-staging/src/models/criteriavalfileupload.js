"use strict";

module.exports = function (sequelize, DataTypes) {
  var CriteriaValueFileUpload = sequelize.define(
    "CriteriaValueFileUpload",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      fileName: { type: DataTypes.STRING, allowNull: false },
      criteria_id: { type: DataTypes.INTEGER, allowNull: false },
      loan_app_id: { type: DataTypes.INTEGER, allowNull: false }
    },
    {
      timestamps: true,
      tableName: "criteria_val_file_uploads",
      freezeTableName: true
    }
  );

  CriteriaValueFileUpload.associate = function (models) {
    CriteriaValueFileUpload.belongsTo(models.Criteria, {
        foreignKey: "criteria_id", as: 'criteria'
      });
    CriteriaValueFileUpload.belongsTo(models.LoanApp, {
      foreignKey: "loan_app_id", as: 'loanApp'
    });
  };
  return CriteriaValueFileUpload;
};
