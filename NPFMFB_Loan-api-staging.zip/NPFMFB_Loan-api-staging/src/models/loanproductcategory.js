"use strict";

module.exports = function (sequelize, DataTypes) {
  var LoanProductCategory = sequelize.define(
    "LoanProductCategory",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      name: { type: DataTypes.STRING, allowNull: false },
      description: { type: DataTypes.STRING, allowNull: false },
      categoryType: { type: DataTypes.STRING, allowNull: false, defaultValue: "SB"}
    },
    {
      timestamps: true,
      tableName: "LoanProductCategory",
      freezeTableName: true
    }
  );

  LoanProductCategory.associate = function (models) {
    LoanProductCategory.belongsToMany(models.Criteria, {
      as: "criterias", through: "LoanProductCategory_Criteria", sourceKey: 'id', foreignKey: { name: "loanProductCategory_id", primaryKey: false, references: null}, constraints: false 
    });
  };
  return LoanProductCategory;
};
