"use strict";

module.exports = function (sequelize, DataTypes) {
  var LoanProduct = sequelize.define(
    "LoanProduct",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      name: { type: DataTypes.STRING, allowNull: false },
      interestRate: { type: DataTypes.DOUBLE, allowNull: false },
      maxTerm: { type: DataTypes.INTEGER, allowNull: false },
      maxTermUnit: { type: DataTypes.STRING, allowNull: false },
      limit: { type: DataTypes.DOUBLE, allowNull: false },
      repaymentReqmt: { type: DataTypes.STRING, allowNull: false }, //SB or NSB
      guarantorsCnt: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      loanProductCategory_id: { type: DataTypes.INTEGER, allowNull: false },
    },
    {
      timestamps: true,
      tableName: "LoanProduct",
      freezeTableName: true
    }
  );

  LoanProduct.associate = function (models) {
    LoanProduct.belongsTo(models.LoanProductCategory, {
      foreignKey: "loanProductCategory_id", as: 'loanProductCategory'
    });
  };
  return LoanProduct;
};
