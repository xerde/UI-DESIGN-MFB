"use strict";

module.exports = function (sequelize, DataTypes) {
  var CriteriaValue = sequelize.define(
    "CriteriaValue",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      value: { type: DataTypes.STRING, allowNull: false },
      criteria_id: { type: DataTypes.INTEGER, allowNull: false },
      reviewer_input: { type: DataTypes.STRING, allowNull: true }
    },
    {
      timestamps: true,
      tableName: "criteria_values",
      freezeTableName: true
    }
  );

  CriteriaValue.associate = function (models) {
    CriteriaValue.belongsTo(models.Criteria, {
      foreignKey: "criteria_id", as: 'criteria'
    });
  };
  return CriteriaValue;
};