"use strict";

module.exports = function (sequelize, DataTypes) {
  var LoanApp = sequelize.define(
    "LoanApp",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      name: { type: DataTypes.STRING, allowNull: false },
      loan_product_id: { type: DataTypes.INTEGER, allowNull: false },
      amount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0.00 },
      user_id: { type: DataTypes.INTEGER, allowNull: false },
      workFlowLevel: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
      approvalBranch_id: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 1 },
      monthlyIncome: { type: DataTypes.DOUBLE, allowNull: false},
      approvedAmount: { type: DataTypes.DOUBLE, allowNull: false, defaultValue: 0.00 },
      approvedTenure: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0  },
      loan_purpose: { type: DataTypes.STRING, allowNull: false },
      creditRptRequested: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false},
      status: { type: DataTypes.ENUM, values: ['PENDING', 'APPROVE', 'REJECT', 'RUNNING', 'PAID'], allowNull: false , defaultValue: "PENDING"},
      narrative: { type: DataTypes.STRING, allowNull: false, defaultValue: "" },
      date_completed: {type: DataTypes.DATE},
      customer_id: { type: DataTypes.INTEGER, allowNull: true },
      requested_loan_tenure: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0  }
    },
    {
      timestamps: true,
      tableName: "loan_apps",
      freezeTableName: true
    }
  );
    
LoanApp.associate = function (models) {
    LoanApp.belongsToMany(models.CriteriaValue, {
      as: "criteriaValues", through: "loan_apps_criteriavalues", sourceKey: 'id', foreignKey: { name: "loan_apps_id", primaryKey: false, references: null}, constraints: false 
    });

    LoanApp.belongsToMany(models.BaseInfoValue, {
      as: "baseInfoValues", through: "loan_apps_base_info_values", sourceKey: 'id', foreignKey: { name: "loan_apps_id", primaryKey: false, references: null}, constraints: false 
    });

    LoanApp.belongsToMany(models.Guarantor, {
      as: "guarantors", through: "loan_apps_guarantors", sourceKey: 'id', foreignKey: { name: "loan_apps_id", primaryKey: false, references: null}, constraints: false 
    });

    LoanApp.belongsTo(models.LoanProduct, {
    foreignKey: "loan_product_id", as: 'loanProduct'
   });

  //  LoanApp.belongsTo(models.User, {
  //   foreignKey: "user_id", as: 'user'
  //  });
  };

  return LoanApp;
};
