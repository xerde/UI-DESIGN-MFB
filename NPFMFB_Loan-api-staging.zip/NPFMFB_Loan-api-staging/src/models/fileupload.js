"use strict";

module.exports = function (sequelize, DataTypes) {
  var FileUpload = sequelize.define(
    "FileUpload",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      fileName: { type: DataTypes.STRING, allowNull: false },
      loan_app_id: { type: DataTypes.INTEGER, allowNull: false }
    },
    {
      timestamps: true,
      tableName: "file_uploads",
      freezeTableName: true
    }
  );

  FileUpload.associate = function (models) {
    FileUpload.belongsTo(models.LoanApp, {
      foreignKey: "loan_app_id", as: 'loanApp'
    });
  };
  return FileUpload;
};
