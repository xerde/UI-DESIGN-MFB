"use strict";

module.exports = function (sequelize, DataTypes) {
  var Branch = sequelize.define(
    "Branch",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      code: { type: DataTypes.STRING, allowNull: false, unique: true },
      name: { type: DataTypes.STRING, allowNull: false }

    },
    {
      timestamps: true,
      tableName: "Branch",
      freezeTableName: true
    }
  );
  return Branch;
};
