"use strict";

module.exports = function (sequelize, DataTypes) {
  var Criteria = sequelize.define(
    "Criteria",
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true},
      code: { type: DataTypes.STRING, allowNull: false },
      scoreType: { type: DataTypes.STRING, allowNull: false },
      requirements: { type: DataTypes.STRING, allowNull: false },
      maxScore: { type: DataTypes.INTEGER, allowNull: false },
      inputType: { type: DataTypes.STRING, allowNull: false },
      optionValues: { type: DataTypes.ARRAY(DataTypes.STRING), allowNull: false, defaultValue: [] },
      applicantInputNeeded: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false}
    },
    {
      timestamps: true,
      tableName: "Criteria",
      freezeTableName: true
    }
  );

  Criteria.associate = function (models) {
    Criteria.belongsToMany(models.LoanProductCategory, {
      as: "categories", through: "LoanProductCategory_Criteria", sourceKey: 'id', foreignKey: { name: "criteria_id", primaryKey: false, references: null}, constraints: false 
    });
  };
  return Criteria;
};
