export interface PendingLoanDTO {
    id?: number;
    name: string;
    customer_id: string;
    email: string;
    photo_location: string;
    bvn: string;
    phone: string;
    profilecomplete: string;
    livelinesschecked: string;
    loan_name: string;
    loan_amount: string;
    approved_amount: string;
    approved_tenure: string;
    loan_repayment_method: string;
    loan_repayment_tenure: string;
    status: string;
    score: number;
    application_date: string;
    narrative: string;
    date_completed: Date;
  }