export interface GuarantorCreateDTO {
    id?: number;
    name: string;
    accountNo: string;
  }