export interface CriteriaValueCreateDTO {
    id?: number;
    name?: string;
    value: string;
    criteriaId: number;
  }

  export interface CriteriaValueUpdateDTO {
    id: number;
    name: string;
    value: string;
    criteriaId: number;
  }