export interface BaseInfoValueCreateDTO {
    id?: number;
    name?: string;
    value: string;
    basicInfoId: number;
  }

  export interface BaseInfoValueUpdateDTO {
    id: number;
    name: string;
    value: string;
    basicInfoId: number;
  }