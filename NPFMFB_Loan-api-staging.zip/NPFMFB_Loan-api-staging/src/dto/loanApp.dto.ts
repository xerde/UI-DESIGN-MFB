export interface LoanAppCreateDTO {
    id?: number;
    name?: string;
    loan_product_id: number;
    amount: number;
    user_id?: number;
    customer_id?: number;
    approvalBranch_id: number;
    monthlyIncome: number;
    creditRptRequested: boolean;
    loan_purpose: string;
    requested_loan_tenure: number;
  }