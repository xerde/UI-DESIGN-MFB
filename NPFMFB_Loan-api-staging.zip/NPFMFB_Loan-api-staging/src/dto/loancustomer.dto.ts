export interface LoanCustomerCreateDTO {
    id?: number;
    customerId: number;
    name: string;
    email: string;
    photoLocation: string;
    bvn: string;
    phone: string;
    profileComplete: string;
    livelinessChecked: string;
    dti: number;
    loanAppId?: number;
    createdBy: number;
  }