export interface DebtToIncomeDTO {
    amount: number;
    monthlyIncome: number;
    tenure: number;
    productId: number;
    tenureUnit?: number;
  }