import { PendingLoanDTO } from "../dto/pendingloan.dto";

export class PendingLoanMapper {


    public static toDTO (model: any): PendingLoanDTO {
        return {
            id: model.id,
            name: model.name,
            customer_id: model.customer_id,
            email: model.email,
            photo_location: model.photo_location,
            bvn: model.bvn,
            phone: model.phone,
            profilecomplete: model.profilecomplete,
            livelinesschecked: model.livelinesschecked,
            loan_name: model.loanApp.loanProduct.name,
            loan_amount: model.loanApp.amount,
            approved_amount: model.loanApp.approvedAmount,
            approved_tenure: model.loanApp.approvedTenure,
            loan_repayment_method: model.loanApp.loanProduct.repaymentReqmt == 'SB' ? 'Salary Based Lending' : 'Non-Salary Based Lending',
            loan_repayment_tenure: model.loanApp.approvedTenure + ' '+ model.loanApp.loanProduct.maxTermUnit,
            status: model.loanApp.status,
            score: model.score ? model.score : 0,
            application_date: model.loanApp.createdAt,
            narrative: model.loanApp.narrative,
            date_completed: model.loanApp.date_completed
        }
      }
}