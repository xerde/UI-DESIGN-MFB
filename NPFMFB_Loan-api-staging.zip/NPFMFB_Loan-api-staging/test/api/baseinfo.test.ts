import * as request from 'supertest';
import app from '../../src/app';
import { readFileSync } from 'fs';
import * as path from 'path';


const database = require('../../src/models');

describe("# BaseInfo", () => {

    beforeAll(async () => {
        await database.sequelize.sync({ force: true })
    })

    test.skip("should successfully save a base info", () => {

        request(app).post("/baseinfo")
        .send({"code": "code1", "name": "name1", "description": "description1"})
        .expect(201);
    });

    test("should successfully save many base infos", async () => {

        const filePath: string = path.join(__dirname, "../payloads/basicinfo.json");
        const data = readFileSync(filePath, 'utf-8');
        request(app).post("/baseinfos")
        .send(data).then((resp) => {
            expect(resp.status).toBeTruthy();
            expect(resp.status).toBe(201);
        })
        
    });



    afterAll(async () => {
        await database.sequelize.close()
      })
      
    });
