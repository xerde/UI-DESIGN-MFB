import * as request from 'supertest';
import app from '../../src/app';
import container from '../../src/configs/inversify';
import { TYPES } from '../../src/configs/types';
import { IBranchService } from '../../src/services/branch.service';
import { IExternalService } from '../../src/services/external.service';
import { ILoanProductService } from '../../src/services/loanproduct.service';
import { ILoanProductCategoryService } from '../../src/services/loanproductcategory.service';
import { createUserV2, loginByUsername } from './common.test';

const database = require('../../src/models');

export const createBranch = async (branch): Promise<any> => {
    const branchService = container.get<IBranchService>(TYPES.BranchService);
    const savedBranch = await branchService.createBranch(branch);
    return savedBranch;
        
    };

    export const createLoanProduct = async (loanProduct): Promise<any> => {
      const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
      const loan = await loanProductServiceInstance.saveLoanProduct(loanProduct);
      return loan;
          
      };
      export const createCategory = async (data): Promise<any> => {
          const categoryService = container.get<ILoanProductCategoryService>(TYPES.LoanProductCategoryService);
          return  await categoryService.saveLoanProductCategoryWithCriteria(data.loanProductCategory, data.criterias);
          };
    export const getDebtToIncome = async (data): Promise<any> => {
      const externalService = container.get<IExternalService>(TYPES.ExternalService);
      return  await externalService.getDebtToIncome(data);
      };
  


describe('External Services', () => {

  beforeAll(async () => {
    await database.sequelize.sync({ force: true })
  })

  
    test("should successfully fetch debit to income info", async () => {
      const data = { 
        "loanProductCategory": {"name":"Name1","description":"Description1","categoryType":"SB"}, 
    "criterias": [
    {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE3", "scoreType":"App3", "requirements": "REQ3", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE4", "scoreType":"App4", "requirements": "REQ4", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };
     const category = await createCategory(data);
    const product =  await createLoanProduct({
        "name": "LoanProduct1",
       "interestRate": 5,
        "maxTerm": 2,
        "maxTermUnit": "years",
        "limit": 3000000,
        "repaymentReqmt": "SB",
        "loanProductCategory_id": category.id
    })
        const user = { "username": "username22221", "password": "password2221", "roles": ["ADMIN"] };
        await createUserV2(user);

        const debtToIncomeStatus = await getDebtToIncome({ "amount": 2000000, "monthlyIncome": 400000, "productId": product.id});
        return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
            .then(res => {
                return request(app)
                .post("/debt-to-income")
                .set("Authorization", res.body.data)
                .send({ "loanApp_amount": 2000000, "loanApp_monthlyIncome": 400000, "loan_product_id": product.id})
                }).then(res => {
                    expect(res.status).toBe(200);
                    expect(res.body.data).toBe(debtToIncomeStatus);
                });
    });

    test.skip("should successfully fetch credit lookup info", async () => {
        return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
            .then(res => {
                return request(app)
                .get("/credit-lookup")
                .set("Authorization", res.body.data)
                }).then(res => {
                    expect(res.status).toBe(200);
                    expect(res.body.data).toBe(5000);
                });
    });

    test.skip("should successfully fetch customer details", () => {
      return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
          .then(res => {
              return request(app)
              .get("/customer-details/9")
              .set("Authorization", res.body.data)
              }).then(res => {
                  expect(res.status).toBe(200);
                  expect(res.body.data).toBeTruthy();
                  expect(res.body.data.id).toBe(9);
                  expect(res.body.data.CustomerUser).toBeTruthy();
                  expect(res.body.data.CustomerUser.id).toBe(9);
              });
  });

  test("should validate token via external service", () => {
            return request(app)
            .get("/validate-token")
            .set("Authorization", "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwiZmlyc3RuYW1lIjpudWxsLCJsYXN0bmFtZSI6bnVsbCwicm9sZXMiOlsiQURNSU4iLCJDU08iXSwiaWF0IjoxNjE2MjczMDIyLCJleHAiOjE2MTYyNzY2MjJ9.p1y0twng55e9BKDsNSXpq2n9jmoEbXzCi0X8D8WqpJc")
            .then(res => {
                expect(res.status).toBe(401);
                expect(res.body.data).toBeTruthy();
                console.log(res.body)
            });
});

  afterAll(async () => {
    await database.sequelize.close()
  })
  
});

