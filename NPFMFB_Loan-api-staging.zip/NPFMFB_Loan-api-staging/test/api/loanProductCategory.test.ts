import * as request from 'supertest';
import app from '../../src/app';
import container from '../../src/configs/inversify';
import { TYPES } from '../../src/configs/types';
//import { IBranchService } from '../../src/services/branch.service';
import { ILoanProductCategoryService } from '../../src/services/loanproductcategory.service';
import { createUserV2, loginByUsername } from './common.test';

const database = require('../../src/models');

export const createCategory = async (data): Promise<any> => {
    const categoryService = container.get<ILoanProductCategoryService>(TYPES.LoanProductCategoryService);
    return  await categoryService.saveLoanProductCategoryWithCriteria(data.loanProductCategory, data.criterias);
    };

    export const getCategory = async (id): Promise<any> => {
        const categoryService = container.get<ILoanProductCategoryService>(TYPES.LoanProductCategoryService);
        return  await categoryService.loadWithCriteria(id);
        };


describe('Loan Product Categories', () => {

  beforeAll(async () => {
    await database.sequelize.sync({ force: true })
  })

  test("should successfully create a category", () => {
    const user = { "username": "username22221", "password": "password2221", "roles": ["ADMIN"] };
     createUserV2(user);
    
    const data = { 
        "loanProductCategory": {"name":"Name1","description":"Description1","categoryType":"SB"}, 
    "criterias": [{"code":"CODE1", "scoreType":"App1", "requirements": "REQ1", "maxScore":5, "inputType": "text","applicantInputNeeded":true},
                    {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":7, "inputType": "dropdown","applicantInputNeeded":false}    
                    ]
    };
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .post("/loanproductcategory")
            .set("Authorization", res.body.data)
            .send(data)
            .expect(201);
            });
});

test.skip("should successfully fetch created category", async () => {
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .get("/loanproductcategory/1")
            .set("Authorization", res.body.data)
            }).then(res => {
                expect(res.body.data.name).toBe("Name1");
                expect(res.body.data.description).toBe("Description1");
                expect(res.body.data.criterias).toBeTruthy();
                expect(res.body.data.criterias.length).toBe(2);
                expect(res.body.data.id).toBe(1);
                expect(res.status).toBe(200);
            });
});

test.skip("should successfully fetch created categories", () => {
    const data = { 
        "loanProductCategory": {"name":"Name2","description":"Description2","categoryType":"NSB"}, 
    "criterias": [
    {"code":"CODE3", "scoreType":"App3", "requirements": "REQ3", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE4", "scoreType":"App4", "requirements": "REQ4", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE5", "scoreType":"App5", "requirements": "REQ5", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };
     createCategory(data).then(async () => {
        const res = await loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] });
         const res_1 = await request(app)
             .get("/loanproductcategories")
             .set("Authorization", res.body.data);
         expect(res_1.body.data.length).toBe(2);
         expect(res_1.body.data[0].name).toBe("Name1");
         //expect(res.body.data[1].name).toBe("Name2");
         expect(res_1.body.data.criterias).toBeTruthy();
         expect(res_1.body.data[0].criterias.length).toBe(2);
         //expect(res.body.data[1].criterias.length).toBe(3);
         expect(res_1.status).toBe(200);
     });
    
});

test("should successfully fetch created categories by category type", async () => {
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .get("/loanproductcategories/SB")
            .set("Authorization", res.body.data)
            }).then(res => {
                expect(res.body.data.length).toBe(1);
                expect(res.body.data[0].name).toBe("Name1");
                expect(res.body.data[0].description).toBe("Description1");
                expect(res.body.data[0].criterias).toBeTruthy();
                expect(res.body.data[0].criterias.length).toBe(2);
                expect(res.body.data[0].id).toBe(1);
                expect(res.status).toBe(200);
            });
});

test.skip("should successfully create many categories", () => {
    const data = { 
        "loanProductCategory": {"name":"Name3","description":"Description3","categoryType":"SB"}, 
    "criterias": [
    {"code":"CODE6", "scoreType":"App6", "requirements": "REQ6", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE7", "scoreType":"App7", "requirements": "REQ7", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE8", "scoreType":"App8", "requirements": "REQ8", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };

    const data2 = { 
        "loanProductCategory": {"name":"Name4","description":"Description4","categoryType":"NSB"}, 
    "criterias": [
    {"code":"CODE9", "scoreType":"App9", "requirements": "REQ9", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE10", "scoreType":"App10", "requirements": "REQ10", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE11", "scoreType":"App11", "requirements": "REQ11", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
    .then(res => {
        return request(app)
        .post("/loanproductcategories")
        .set("Authorization", res.body.data)
        .send([data, data2])
        .expect(201);
        });
    
});

test("should successfully update a category", async () => {
    
    const data = { 
        "loanProductCategory": {"name":"Name1","description":"Description4","categoryType":"SB"}, 
    "criterias": [{"code":"CODE1", "scoreType":"App1", "requirements": "REQ1", "maxScore":5, "inputType": "text","applicantInputNeeded":true},
                    {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":7, "inputType": "dropdown","applicantInputNeeded":false}    
                    ]
    };
     loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .put("/loanproductcategory/1")
            .set("Authorization", res.body.data)
            .send(data)
            .expect(200)
            }).then(async () => {
                const category = await getCategory(1);
                expect(category.description).toBe("Description4");
            });

            


});

  afterAll(async () => {
    await database.sequelize.close()
  })
  
});

