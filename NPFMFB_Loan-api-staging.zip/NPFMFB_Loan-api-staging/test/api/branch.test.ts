import * as request from 'supertest';
import app from '../../src/app';
import container from '../../src/configs/inversify';
import { TYPES } from '../../src/configs/types';
import { IBranchService } from '../../src/services/branch.service';
import { createUserV2, loginByUsername } from './common.test';

const database = require('../../src/models');

export const createBranch = async (branch): Promise<any> => {
    const branchService = container.get<IBranchService>(TYPES.BranchService);
    const savedBranch = await branchService.createBranch(branch);
    return savedBranch;
        
    };


describe('Branches', () => {

  beforeAll(async () => {
    await database.sequelize.sync({ force: true })
  })

  test("should successfully create a branch", async () => {
    const user = { "username": "username22221", "password": "password2221", "roles": ["ADMIN"] };
    await createUserV2(user);
    const data = {"code": "BR001", "name": "Branch One"};
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .post("/branch")
            .set("Authorization", res.body.data)
            .send(data)
            .expect(201);
            });
});

test("should successfully fetch created branch", async () => {
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .get("/branch/1")
            .set("Authorization", res.body.data)
            }).then(res => {
                expect(res.body.data.name).toBe("Branch One");
                expect(res.body.data.id).toBe(1);
                expect(res.status).toBe(200);
            });
});

test("should successfully fetch created branches", async () => {
    const data = {"code": "BR002", "name": "Branch Two"};
    createBranch(data);
    return loginByUsername({ "username": "username22221", "password": "password2221", "roles": ["ADMIN"] })
        .then(res => {
            return request(app)
            .get("/branches")
            .set("Authorization", res.body.data)
            }).then(res => {
                expect(res.body.data.length).toBe(2);
                expect(res.body.data[0].name).toBe("Branch One");
                expect(res.body.data[1].name).toBe("Branch Two");
                expect(res.status).toBe(200);
            });
});

  afterAll(async () => {
    await database.sequelize.close()
  })
  
});

