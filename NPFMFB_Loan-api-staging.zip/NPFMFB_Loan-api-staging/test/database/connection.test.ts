const database = require('../../src/models').db;

describe('Database', () => {
  test.skip('Test connection', async () => {
    await database.sequelize.authenticate()

    await database.sequelize.sync({force: true})
    .then(() => {
      console.log(`Database & tables created!`)
    })
    .catch(err => {
      console.log(`Error syncing!`+ err)
    })
  });
});
