import container from "../../src/configs/inversify";
import { TYPES } from "../../src/configs/types";
import { ILoanProductService } from "../../src/services/loanproduct.service";
import * as request from 'supertest';
import app from '../../src/app';
//import { readFileSync } from 'fs';
//import * as path from 'path';
import { ILoanProductCategoryService } from "../../src/services/loanproductcategory.service";

const database = require('../../src/models');

export const createLoanProduct = async (loanProduct): Promise<any> => {
    const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
    const loan = await loanProductServiceInstance.saveLoanProduct(loanProduct);
    return loan;
        
    };

    export const getLoanProductById = async (loanProductId): Promise<any> => {
        const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
        const product = await loanProductServiceInstance.loadWithCategory(loanProductId);
        return product;
            
        };

    export const createCategory = async (data): Promise<any> => {
        const categoryService = container.get<ILoanProductCategoryService>(TYPES.LoanProductCategoryService);
        return  await categoryService.saveLoanProductCategoryWithCriteria(data.loanProductCategory, data.criterias);
        };

        export const getLoanProducts = async (): Promise<any> => {
            const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
            const products = await loanProductServiceInstance.loadAllWithCategory();
            return products;
                
            };
        

// export const createLoanProductWithCriteria = async (loanProduct,  criteria): Promise<any> => {
//     const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
//     const loan = await loanProductServiceInstance.saveLoanProductWithCriteria(loanProduct, criteria);
//     return loan;
        
//     };
//     export const loadWithCriteria = async (loanProductId): Promise<any> => {
//         const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
//         const loan = await loanProductServiceInstance.loadWithCriteria(loanProductId);
//         return loan;
            
//         };

    describe("# LoanProduct", () => {

        beforeAll(async () => {
            await database.sequelize.sync({ force: true })
        })

        test("should successfully save a loanProduct", async () => {

            const data = { 
                "loanProductCategory": {"name":"Name1","description":"Description1","categoryType":"SB"}, 
            "criterias": [
            {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
            {"code":"CODE3", "scoreType":"App3", "requirements": "REQ3", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
            {"code":"CODE4", "scoreType":"App4", "requirements": "REQ4", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
                ]
            };
             const category = await createCategory(data);
            return createLoanProduct({
                "name": "LoanProduct1",
               "interestRate": 5,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 3000000,
                "repaymentReqmt": "SB",
                "loanProductCategory_id": category.id
            })
            .then(res => { 
                var r = res.get({ plain: true });
                expect(r).toBeTruthy();
                expect(r.id).toBeTruthy();
                expect(r.id).not.toBeNull();
                expect(r.name).toBe("LoanProduct1");
                expect(r.loanProductCategory_id).toBe(category.id);
            });
        });

        // test("should successfully save a loanProduct with criteria", () => {
        //     return createLoanProductWithCriteria({
        //         "name": "LoanProduct1",
        //         "interestRate": 5,
        //         "maxTerm": 2,
        //         "maxTermUnit": "years",
        //         "limit": 3000000,
        //         "repaymentReqmt": "S"}, [{
        //             "code": "code1",
        //             "scoreType": "App",
        //             "requirements": "Loan application letter duly signed by the account holder",
        //             "maxScore": 5,
        //             "inputType": "dropdown",
        //             "optionValues": ["Yes","No"]
        //         },
        //         {
        //             "code": "code2",
        //             "scoreType": "App",
        //             "requirements": "All site verification, collateral Inspection shall identify and evaluate Environment & Social Risk Factors(Where applicable)",
        //             "maxScore": 10,
        //             "inputType": "dropdown",
        //             "optionValues": ["Yes","No"]
        //         },
        //         {
        //             "code": "code3",
        //             "scoreType": "App",
        //             "requirements": "Existing loan exposure",
        //             "maxScore": 20,
        //             "inputType": "dropdown",
        //             "optionValues": ["Total loan repayment as a % of salary (less than 50%)- 2",
        //                     "Total loan repayment as a % of salary (51% - 70%)- 1",
        //                     "Total loan repayment as a % of salary (Above 70%)- 0"
        //                 ]
        //         }])
        //     .then(async res => { 
        //         var r = res.get({ plain: true });
        //         var t = await loadWithCriteria(r.id)
        //         expect(t).toBeTruthy();
        //         expect(t.id).toBeTruthy();
        //         expect(t.id).not.toBeNull();
        //         expect(t.name).toBe("LoanProduct1");
        //     });
        // });

        test("should successfully save a loanProduct via endpoint", async () => {

            const data = { 
                "loanProductCategory": {"name":"Name2","description":"Description2","categoryType":"NSB"}, 
            "criterias": [
            {"code":"CODE5", "scoreType":"App5", "requirements": "REQ5", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
            {"code":"CODE6", "scoreType":"App6", "requirements": "REQ6", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
            {"code":"CODE7", "scoreType":"App7", "requirements": "REQ7", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
                ]
            };
             const category = await createCategory(data);

            const prod = {
                "name": "LoanProduct2",
               "interestRate": 5,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 3000000,
                "repaymentReqmt": "S",
                "loanProductCategory_id": category.id
            }
            request(app).post("/loanproduct")
            .send(prod)
            .expect(201);
        });

        test("should successfully fetch a loanProduct with category and criterias", async () => {
                 return getLoanProductById(1).then(res => {
               expect(res.name).toBe("LoanProduct1");
               expect(res.loanProductCategory.id).toBe(1);
               expect(res.loanProductCategory.categoryType).toBe("SB");
               expect(res.loanProductCategory.criterias.length).toBe(2);
               expect(res.loanProductCategory.criterias[0].code).toBe("CODE2");
            });
        });

        test("should successfully save many loanProduct via endpoint", async () => {

            const data = { 
                "loanProductCategory": {"name":"Name3","description":"Description3","categoryType":"NSB"}, 
            "criterias": [
            {"code":"CODE8", "scoreType":"App5", "requirements": "REQ5", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
            {"code":"CODE9", "scoreType":"App6", "requirements": "REQ6", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
            {"code":"CODE10", "scoreType":"App7", "requirements": "REQ7", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
                ]
            };
             const category = await createCategory(data);

            const prod3 = {
                "name": "LoanProduct3",
               "interestRate": 5,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 3000000,
                "repaymentReqmt": "SB",
                "loanProductCategory_id": category.id
            }

            const prod4 = {
                "name": "LoanProduct4",
               "interestRate": 5,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 3000000,
                "repaymentReqmt": "SB",
                "loanProductCategory_id": category.id
            }

            
            request(app).post("/loanproducts")
            .send([prod3,prod4])
            .expect(201);
    });

    test("should successfully fetch loanProducts with category and criterias", () => {
        return getLoanProducts().then(res => {
            expect(res.length).toBe(1);
            expect(res[0].name).toBe("LoanProduct1");
            expect(res[0].loanProductCategory.categoryType).toBe("SB");
       expect(res[0].loanProductCategory.criterias.length).toBe(2);
       expect(res[0].loanProductCategory.criterias[0].code).toBe("CODE2");
   });
});

        afterAll(async () => {
            await database.sequelize.close()
        })

    });