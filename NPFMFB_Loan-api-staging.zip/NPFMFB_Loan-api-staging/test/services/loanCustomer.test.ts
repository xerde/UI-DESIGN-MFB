import container from "../../src/configs/inversify";
import { TYPES } from "../../src/configs/types";
import { ILoanCustomerService } from "../../src/services/loancustomer.service";
import * as LoanAppTest from "../services/loanApp.test";


const database = require('../../src/models');
const loanCustomerServiceInstance = container.get<ILoanCustomerService>(TYPES.LoanCustomerService);

const customerDetails = {
    "id": 54,
    "email": "testdartpay@gmail.com",
    "firstname": "Franklin",
    "lastname": "Godwin",
    "phone": "2349073443561",
    "bvn": null,
    "has_pin": true,
    "isotpverified": true,
    "photo_location": "https://csb10032000f5765b8c.blob.core.windows.net/npf-mfb-staging/54%2Fphoto%2Fimage.jpg",
    "customerNumber": "100219385",
    "PND": false,
    "isnewbankcustomer": true,
    "signup_incomplete": false,
    "enabled": true,
    "livelinesschecked": "APPROVED",
    "document_location": "https://csb10032000f5765b8c.blob.core.windows.net/npf-mfb-staging/54%2Fdocument%2Fimage.jpg",
    "video_location": "https://csb10032000f5765b8c.blob.core.windows.net/npf-mfb-staging/54%2Fvideo%2Fvideo.mp4",
    "photostatus": "APPROVED",
    "documentstatus": "APPROVED",
    "signaturestatus": "APPROVED",
    "profilecomplete": "APPROVED",
    "last_login_date": "2021-04-14T14:52:11.034Z",
    "last_logout_date": "2021-04-14T08:46:04.246Z"
};

export const createLoanCustomer = async (loanCustomer): Promise<any> => {
    
    const loanCust = await loanCustomerServiceInstance.saveLoanCustomer(loanCustomer);
    return loanCust;
        
    };
export const createLoanCustomerWithCustomerDetails = async (): Promise<any> => {

    var loanCustDto = loanCustomerServiceInstance.createLoanCustomerDTO(customerDetails);
    return createLoanCustomer(loanCustDto);      
    };


describe("# Loan Customer", () => {

    beforeAll(async () => {
        await database.sequelize.sync({ force: true })
    })

    test.skip("should successfully save a loanCustomer", async () => {
        return createLoanCustomer({
            customerId: 128,
            name: "loanCustomer",
            email: "loancustomer@email.com",
            photoLocation: "loancustomerfilephotopath",
            bvn: "123456789011",
            phone: "080912345678",
            profileComplete: "Active",
            livelinessChecked: "APPROVED",
            dti: 25
          })
        .then(res => { 
            var r = res.get({ plain: true });
            expect(r).toBeTruthy();
            expect(r.id).toBeTruthy();
            expect(r.id).not.toBeNull();
            expect(r.name).toBe("loanCustomer");
            expect(r.email).toBe("loancustomer@email.com");
            expect(r.bvn).toBe("123456789011");
            expect(r.profilecomplete).toBe("Active");
            expect(r.dti).toBe(25);
        });
    });

    test.skip("should successfully save a loanCustomer 2", async () => {
        var loanCust = loanCustomerServiceInstance.createLoanCustomerDTO(customerDetails);
        //loanCust["dti"] = 25;
        return createLoanCustomer(loanCust)
        .then(res => { 
            var r = res.get({ plain: true });
            expect(r).toBeTruthy();
            expect(r.id).toBeTruthy();
            expect(r.id).not.toBeNull();
            expect(r.name).toBe("Franklin");
            expect(r.email).toBe("testdartpay@gmail.com");
            expect(r.bvn).toBeNull();
            expect(r.profilecomplete).toBe("APPROVED");
            expect(r.livelinesschecked).toBe("APPROVED");
            expect(r.photo_location).toBe("https://csb10032000f5765b8c.blob.core.windows.net/npf-mfb-staging/54%2Fphoto%2Fimage.jpg");
            expect(r.dti).toBe(0);
        });
    });

    test("should successfully save a loanCustomer 3", async () => {
        
        await LoanAppTest.createLoanAppWithCustomerDetails();
        //loanCust["dti"] = 25;
        //loanCustomerServiceInstance.getLoanCustomersDto
        return loanCustomerServiceInstance.getLoanCustomersDto()
        .then(res => { 
            expect(res).toBeTruthy();
            
        });
    });

})