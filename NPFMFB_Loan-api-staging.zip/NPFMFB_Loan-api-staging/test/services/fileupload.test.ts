import container from "../../src/configs/inversify";
import { TYPES } from "../../src/configs/types";
import { IUploadService } from "../../src/services/i-upload.service";
import { ILoanAppService } from "../../src/services/loanapp.service";
import { IUserService } from "../../src/services/user.service";
import { ILoanProductService } from "../../src/services/loanproduct.service";

const database = require('../../src/models');

export const createLoanApp = async (loanApp): Promise<any> => {
    const loanAppServiceInstance = container.get<ILoanAppService>(TYPES.LoanAppService);
    const loan = await loanAppServiceInstance.saveLoanApp(loanApp);
    return loan;
        
    };

export const createFileUpload = async (fileNames, loanAppId): Promise<any> => {
    const fileUploadServiceInstance = container.get<IUploadService>(TYPES.FileUploadService);
    await fileUploadServiceInstance.saveFileUploads(fileNames, loanAppId);
        
};

export const getFileUploadsByLoanAppId = async (loanAppId): Promise<any> => {
    const fileUploadServiceInstance = container.get<IUploadService>(TYPES.FileUploadService);
    const fileUploads: any[] = await fileUploadServiceInstance.getFileUploadByLoanAppId(loanAppId);
    return fileUploads;
        
};

export const createUser = async (user): Promise<any> => {
    const userService = container.get<IUserService>(TYPES.UserService);
    const savedUser = await userService.save(user);
    return savedUser;
        
    };
export const createLoanProduct = async (loanProduct): Promise<any> => {
    const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);
    const loan = await loanProductServiceInstance.saveLoanProduct(loanProduct);
    return loan;
        
    };

describe("# File Uploads", () => {

    beforeAll(async () => {
        await database.sequelize.sync({ force: true });
    });

    test("should successfully save File Uploads", async () => {
        const user = await createUser({ "username": "usernameLoanApp2", "password": "passwordLoanApp2", "roles": ["ADMIN", "GUEST"] })
        const product = await createLoanProduct({
            "name": "LoanProduct2",
            "interestRate": 5,
            "maxTerm": 2,
            "maxTermUnit": "years",
            "limit": 3000000,
            "repaymentReqmt": "SB"})
        const loanApp = await createLoanApp({ "name": "LoanApp2", "loan_product_id": product.id, "amount": 5000000.00, "user_id": user.id, "monthlyIncome":2000000});
        var fileNames = {data: ["xxxxxxx","yyyyyyy"]};
        createFileUpload(fileNames, loanApp.id)
        .then(async () => {
            const fileUploads: any[] = await getFileUploadsByLoanAppId(loanApp.id);
            expect(fileUploads.length).toBe(2);
            expect(fileUploads[0].fileName).toBe("xxxxxxx");
            expect(fileUploads[0].loan_app_id).toBe(loanApp.id);
            expect(fileUploads[1].fileName).toBe("yyyyyyy");
            expect(fileUploads[1].loan_app_id).toBe(loanApp.id);
        });
        
    });


    afterAll(async () => {
        await database.sequelize.close();
    });

});