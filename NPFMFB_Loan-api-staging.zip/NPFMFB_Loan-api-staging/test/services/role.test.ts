import container from "../../src/configs/inversify";
import { TYPES } from "../../src/configs/types";
import { IRoleService } from "../../src/services/role.service";

const database = require('../../src/models');

export const createRole = async (roleData: any): Promise<any> => {
    const roleServiceInstance = container.get<IRoleService>(TYPES.RoleService);
    const role = await roleServiceInstance.createRole(roleData);
    return role;
        
    };

    export const updateRole = async (roleData: any, roleId: number): Promise<any> => {
        const roleServiceInstance = container.get<IRoleService>(TYPES.RoleService);
        const role = await roleServiceInstance.updateRole(roleData, roleId);
        return role;
            
        };
    

    export const createRoles = async (roleData: any[]): Promise<any> => {
        const roleServiceInstance = container.get<IRoleService>(TYPES.RoleService);
        const role = await roleServiceInstance.createManyRoles(roleData);
        return role;
            
        };

    export const getRoleyId = async (roleId: number): Promise<any> => {
        const roleServiceInstance = container.get<IRoleService>(TYPES.RoleService);
        const role = await roleServiceInstance.findById(roleId);
        return role;
            
        };
        export const getRoles = async (): Promise<any> => {
            const roleServiceInstance = container.get<IRoleService>(TYPES.RoleService);
            const role = await roleServiceInstance.getRoles();
            return role;
                
            };

describe("# Roles", () => {

    beforeAll(async () => {
        await database.sequelize.sync({ force: true })
    })

    test("should successfully save a Role", () => {
        return createRole({ name: "NAME1", code: "CODE1", minLimit: 100000, maxLimit: 2000000 })
        .then(async res => { 
            var r = res.get({ plain: true });
            var t = await getRoleyId(r.id)
            var s = t.get({ plain: true });
            expect(s.name).toBe("NAME1");
            expect(s.code).toBe("CODE1");
            expect(s.maxLimit).toBe(2000000);
            expect(s.minLimit).toBe(100000);
        });
    });

    test("should successfully save many Roles", () => {
        return createRoles([{ name: "NAME2", code: "CODE2", minLimit: 100000, maxLimit: 2000000 }, { name: "NAME3", code: "CODE3", minLimit: 3000000, maxLimit: 5000000 }])
        .then(async () => {    
            var t: any[] = await getRoles()
            expect(t.length).toBeGreaterThan(1);
        });
    });

    test("should successfully update a Role", () => {
        return createRole({ name: "NAME4", code: "CODE4", minLimit: 6000000, maxLimit: 9000000 })
        .then(async res => { 
            var r = res.get({ plain: true });
            expect(r.workFlowLevel).toBe(1);
            await updateRole({ name: "NAME5", code: "CODE5", minLimit: 7000000, maxLimit: 8000000, workFlowLevel: 2 }, r.id);
            var u = await getRoleyId(r.id);
            var s = u.get({ plain: true });
            expect(s.name).toBe("NAME5");
            expect(s.code).toBe("CODE5");
            expect(s.maxLimit).toBe(8000000);
            expect(s.minLimit).toBe(7000000);
            expect(s.workFlowLevel).toBe(2);
        });
    });


    afterAll(async () => {
        await database.sequelize.close()
    })

});