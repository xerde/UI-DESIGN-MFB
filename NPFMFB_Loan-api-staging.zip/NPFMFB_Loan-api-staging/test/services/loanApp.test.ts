import container from "../../src/configs/inversify";
import { TYPES } from "../../src/configs/types";
import { ILoanAppService } from "../../src/services/loanapp.service";
import * as request from 'supertest';
import app from '../../src/app';
import * as path from 'path';
import { IUserService } from "../../src/services/user.service";
import { ILoanProductService } from "../../src/services/loanproduct.service";
import { LoanAppCreateDTO } from "../../src/dto/loanApp.dto";
import { ICriteriaService } from "../../src/services/criteria.service";
import { IBaseInfoService } from "../../src/services/baseinfo.service";
import { IBranchService } from "../../src/services/branch.service";
import { ILoanProductCategoryService } from "../../src/services/loanproductcategory.service";
import * as LoanCustomerTest from "../services/loanCustomer.test";

const database = require('../../src/models');
const loanAppServiceInstance = container.get<ILoanAppService>(TYPES.LoanAppService);
const loanProductServiceInstance = container.get<ILoanProductService>(TYPES.LoanProductService);

export const createLoanApp = async (loanApp): Promise<any> => {
    
    const loan = await loanAppServiceInstance.saveLoanApp(loanApp);
    return loan;
        
    };

export const createLoanAppModels = async (criteriaValuesModels: any[], baseInfoValuesModels: any[], guarantorModels: any[], loanApp: LoanAppCreateDTO): Promise<any> => {
    const loan = await loanAppServiceInstance.saveLoanAppDetailsModels(criteriaValuesModels, baseInfoValuesModels, guarantorModels, loanApp);
    return loan;
        
    };

export const createLoanAppWithCriteriaValues = async (loanApp,  criteriaValues, baseInfoValues): Promise<any> => {
    const loan = await loanAppServiceInstance.saveLoanAppDetails(loanApp, criteriaValues, baseInfoValues);
    return loan;
        
    };
export const loadWithCriteriaValues = async (loanProductId): Promise<any> => {
    const loan = await loanAppServiceInstance.loadByIdWithCriteriaValuesAndBaseInfoValues(loanProductId);
    return loan;
        
    };
export const createUser = async (user): Promise<any> => {
    const userService = container.get<IUserService>(TYPES.UserService);
    const savedUser = await userService.save(user);
    return savedUser;
        
    };
export const createLoanProduct = async (loanProduct): Promise<any> => {
    const loan = await loanProductServiceInstance.saveLoanProduct(loanProduct);
    return loan;
        
    };

export const createLoanProductWithCategory = async (): Promise<any> => {

    const data = { 
        "loanProductCategory": {"name":"Name1_","description":"Description1","categoryType":"SB"}, 
    "criterias": [
    {"code":"CODE2_", "scoreType":"App2", "requirements": "REQ2", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE3_", "scoreType":"App3", "requirements": "REQ3", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE4_", "scoreType":"App4", "requirements": "REQ4", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };

    const category = await createCategory(data);

    const product = await createLoanProduct({
        "name": "LoanProduct2",
        "interestRate": 6,
        "maxTerm": 2,
        "maxTermUnit": "years",
        "limit": 10000000,
        "repaymentReqmt": "SB",
        "loanProductCategory_id": category.id
    });

    return product;
        
    };

export const createCriteria = async (criteriaData): Promise<any> => {
    const criteriaServiceInstance = container.get<ICriteriaService>(TYPES.CriteriaService);
    const criteria = await criteriaServiceInstance.createCriteria(criteriaData);
    return criteria;
        
    };
export const createBaseInfo = async (baseInfoData): Promise<any> => {
    const baseInfoServiceInstance = container.get<IBaseInfoService>(TYPES.BaseInfoService);
    const baseInfo = await baseInfoServiceInstance.create(baseInfoData);
    return baseInfo;
        
    };
export const createBranch = async (branch): Promise<any> => {
    const branchServiceInstance = container.get<IBranchService>(TYPES.BranchService);
    return await branchServiceInstance.createBranch(branch);
        
    };
export const createCategory = async (data): Promise<any> => {
    const categoryService = container.get<ILoanProductCategoryService>(TYPES.LoanProductCategoryService);
    return  await categoryService.saveLoanProductCategoryWithCriteria(data.loanProductCategory, data.criterias);
    };

export const loadByUserIdAndStatusWithCriteriaValues = async (userId: number, status: string): Promise<any> => {
    const loanAppServiceInstance = container.get<ILoanAppService>(TYPES.LoanAppService);
    const loan = await loanAppServiceInstance.loadByUserIdAndStatusWithCriteriaValuesAndBaseInfoValues(userId, status);
    return loan;
        
    };
export const loadByIdWithCriteriaValuesAndBaseInfoValues = async (loanId: number): Promise<any> => {
    const loanAppServiceInstance = container.get<ILoanAppService>(TYPES.LoanAppService);
    const loan = await loanAppServiceInstance.loadByIdWithCriteriaValuesAndBaseInfoValues(loanId);
    return loan;
        
    };

export const createLoanAppWithCustomerDetails = async (): Promise<any> => {
    var loanCustomer = LoanCustomerTest.createLoanCustomerWithCustomerDetails();
    const data = { 
        "loanProductCategory": {"name":"Name1","description":"Description1","categoryType":"SB"}, 
    "criterias": [
    {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
    {"code":"CODE3", "scoreType":"App3", "requirements": "REQ3", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
    {"code":"CODE4", "scoreType":"App4", "requirements": "REQ4", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
        ]
    };

    const category = await createCategory(data);

    const product = await createLoanProduct({
        "name": "LoanProduct2",
        "interestRate": 6,
        "maxTerm": 2,
        "maxTermUnit": "years",
        "limit": 10000000,
        "repaymentReqmt": "SB",
        "loanProductCategory_id": category.id
    });
    
    const branch = await createBranch({"code": "BR001", "name": "Branch One"});

    var loan = { 
        "name": "LoanApp2", "loan_product_id": product.id, "amount": 7000000.00, "user_id": loanCustomer['customer_id'],"customer_id": loanCustomer['customer_id'], "monthlyIncome":2000000,
        "approvalBranch_id": branch.id,
        "creditRptRequested": true,
        "loan_purpose": "I need money",
        "requested_loan_tenure": 12
    };
    var criteria = await createCriteria({"code":"CODE1", "scoreType":"App1", "requirements": "REQ1", "maxScore":5, "inputType": "text"});
    var baseInfo = await createBaseInfo({ "name": "baseInfoName", "code": "CODE1", "description": "DESC1", "inputType": "text"});
    var criteriaValueModels: any[] = new Array();
    criteriaValueModels.push({
        "value": "CV value1",
        "criteria_id": criteria.id
    });
    
    var baseInfoValuesModels: any[] = new Array();

    baseInfoValuesModels.push({
        "value": "BaseInfoVavalue",
        "base_info_id": baseInfo.id
    });
    var guarantorModels: any[] = new Array();
    
    guarantorModels.push({
        "name": "GuarantorName",
        "accountNumber": "234509876"
    });
return createLoanAppModels(criteriaValueModels, baseInfoValuesModels, guarantorModels, loan)
    
    };

    describe("# Loan App", () => {

        beforeAll(async () => {
            await database.sequelize.sync({ force: true })
        })

        test.skip("should successfully save a loanApp", async () => {
            const user = await createUser({ "username": "usernameLoanApp1", "password": "passwordLoanApp1", "roles": ["ADMIN", "GUEST"] })
            const product = await createLoanProduct({
                "name": "LoanProduct1",
                "interestRate": 5,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 3000000,
                "repaymentReqmt": "SB"})
            return createLoanApp({ "name": "LoanApp1", "loan_product_id": product.id, "amount": 5000000.00, "user_id": user.id})
            .then(res => { 
                var r = res.get({ plain: true });
                expect(r).toBeTruthy();
                expect(r.id).toBeTruthy();
                expect(r.id).not.toBeNull();
                expect(r.name).toBe("LoanApp1");
                expect(r.loan_product_id).not.toBeNull();
                expect(r.amount).toBe(5000000);
                expect(r.user_id).not.toBeNull();
            });
        });

        test.skip("should successfully save a loanApp with associations", async () => {
            const user = await createUser({ "username": "usernameLoanApp2", "password": "passwordLoanApp2", "roles": ["ADMIN", "GUEST"] })

            const data = { 
                "loanProductCategory": {"name":"Name1","description":"Description1","categoryType":"SB"}, 
            "criterias": [
            {"code":"CODE2", "scoreType":"App2", "requirements": "REQ2", "maxScore":9, "inputType": "file","applicantInputNeeded":true},
            {"code":"CODE3", "scoreType":"App3", "requirements": "REQ3", "maxScore":11, "inputType": "radio","applicantInputNeeded":true},
            {"code":"CODE4", "scoreType":"App4", "requirements": "REQ4", "maxScore":13, "inputType": "dropdown","applicantInputNeeded":false},
                ]
            };

            const category = await createCategory(data);

            const product = await createLoanProduct({
                "name": "LoanProduct2",
                "interestRate": 6,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 10000000,
                "repaymentReqmt": "SB",
                "loanProductCategory_id": category.id
            });
            
            const branch = await createBranch({"code": "BR001", "name": "Branch One"});
    
            var loan = { 
                "name": "LoanApp2", "loan_product_id": product.id, "amount": 7000000.00, "user_id": user.id,"customer_id": user.id, "monthlyIncome":2000000,
                "approvalBranch_id": branch.id,
                "creditRptRequested": true,
                "loan_purpose": "I need money",
                "requested_loan_tenure" : 12
            };
            var criteria = await createCriteria({"code":"CODE1", "scoreType":"App1", "requirements": "REQ1", "maxScore":5, "inputType": "text"});
            var baseInfo = await createBaseInfo({ "name": "baseInfoName", "code": "CODE1", "description": "DESC1", "inputType": "text"});
            var criteriaValueModels: any[] = new Array();
            criteriaValueModels.push({
                "value": "CV value1",
                "criteria_id": criteria.id
            });
            
            var baseInfoValuesModels: any[] = new Array();

            baseInfoValuesModels.push({
                "value": "BaseInfoVavalue",
                "base_info_id": baseInfo.id
            });
            var guarantorModels: any[] = new Array();
            
            guarantorModels.push({
                "name": "GuarantorName",
                "accountNumber": "234509876"
            });
        return createLoanAppModels(criteriaValueModels, baseInfoValuesModels, guarantorModels, loan)
            .then(async res => { 
                var r = res.get({ plain: true });
                expect(r.id).toBeTruthy();
                console.log("r====="+r.id);
                //var t = await loadWithCriteriaValues(r.id)
                //expect(t.name).toBe("LoanApp2");
                //expect(t.approvalBranch_id).toBe(branch.id);
                //expect(t.creditRptRequested).toBe(true);
                //expect(t.loan_purpose).toBe("I need money");
            });
        });

        test.skip("should successfully save a loanApp", async () => {

            var guarantorModels: any[] = new Array();
            
            guarantorModels.push({
                "id": 1,
                "name": "GuarantorName",
                "accountNumber": "234509876"
            });

            var criteriaValueModels: any[] = new Array();
            criteriaValueModels.push({
                "id": 1,
                "value": "CV value1",
                "criteria_id": 1
            });
            
            var baseInfoValuesModels: any[] = new Array();

            baseInfoValuesModels.push({
                "id": 1,
                "value": "BaseInfoVavalue",
                "base_info_id": 1
            });

            var loan = { 
                "id": 1,"name": "LoanApp2", "loan_product_id": 1, "amount": 7000000.00, "user_id": 1,"customer_id": 1, "monthlyIncome":2000000,
                "approvalBranch_id": 1,
                "creditRptRequested": true,
                "loan_purpose": "I need money",
                "requested_loan_tenure": 12
            };

            const res = await createLoanAppModels([], [], guarantorModels, loan);
            var r = res.get({ plain: true });
            expect(r.id).toBeTruthy();
            console.log("r=====" + r.id);
        });

        test.skip("should successfully load a loanApp by status and user id", async () => { 
            const res = await loadByUserIdAndStatusWithCriteriaValues(1, 'PENDING');
            var r = res.get({ plain: true });
            expect(r.id).toBeTruthy();
            console.log("r=====" + r.id);

        });

        test.skip("should successfully load a loanApp by status and user id via endpoint", () => {

            request(app).get("/loanapplication-pending/1").then(res => {
                expect(res.status).toBe(200);
                expect(res.body.data.id).toBeTruthy();
                expect(res.body.data.id).toBe(1);
                expect(res.body.data.name).toBe("LoanApp2");
            });
        });

        test.skip("should successfully save a loanApp with criteria values", () => {
            return createLoanAppWithCriteriaValues({ "name": "LoanApp1"}, [{"name": 'name1', "value": 'value1'},
            {"name": 'name2', "value": 'value2'}], [{"name": 'name1', "value": 'value1'},
            {"name": 'name2', "value": 'value2'}])
            .then(async res => { 
                var r = res.get({ plain: true });
                var t = await loadWithCriteriaValues(r.id)
                var s = t.get({ plain: true });
                console.log(s);
                expect(s.name).toBe("LoanApp1");
            });
        });

        test.skip("should successfully save a loanApp with criteria values via endpoint", () => {

            const filePath: string = path.join(__dirname, "../uploads/fileuploadtest")
            request(app).post("/loanapplication").attach('upload', filePath)
            .field("data", "data")
            .expect(201);
        });

        test("should successfully get min amount", async () => {

           const product =  await createLoanProductWithCategory();
           const percent = Number(String(process.env.MIN_LOAN_AMT_PERCENTAGE_VAL)) || 15;
           let amtRange: Map<string, number> = await loanAppServiceInstance.getLoanProductAmtRange(product.id);
           console.log("Percent ====="+percent);
           console.log("Limit ====="+amtRange["maximum"]);
           //var minAmount = (percent/100) * product.limit;
           var minAmount = Number(String(process.env.MIN_LOAN_AMT_VAL)) || 2000;
           console.log("minimum amount ====="+amtRange["minimum"]);
           expect(amtRange["minimum"]).toBe(minAmount);
        });

        test("should successfully get loan range amounts", async () => {

            await createLoanProduct({
                "name": "LoanProduct2",
                "interestRate": 6,
                "maxTerm": 2,
                "maxTermUnit": "years",
                "limit": 15000000,
                "repaymentReqmt": "SB",
                "loanProductCategory_id": 1
            });

            const products = await loanProductServiceInstance.loadAllWithCategory();

            let productWithCategory = new Map();
    
            productWithCategory['products'] = products;
            for(let i=0; i<productWithCategory['products'].length; i++){
                let amtRange: Map<string, number> = loanAppServiceInstance.getLoanProductObjectAmtRange(productWithCategory['products'][i]);
                productWithCategory['products'][i]['maximimumAmount'] = amtRange["maximum"];
                productWithCategory['products'][i]['minimimumAmount'] = amtRange["minimum"];
            }
            console.log("productWithCategory========");
            console.log(productWithCategory);
         });

        afterAll(async () => {
            await database.sequelize.close()
        })

    });