var readCredentials = ['api-read', 'password-read'];
var writeCredentials = ['api-write', 'password-write'];
var deleteCredentials = ['api-delete', 'password-delete'];

exports.read = readCredentials;
exports.write = writeCredentials;
exports.delete = deleteCredentials;