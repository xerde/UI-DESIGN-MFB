var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").BankAccountController;

const passport = require("../security/passport");

const jwtAuth = passport.authenticate("jwtCheck", { session: false });

router.post("/create_pin", jwtAuth, controller.create_pin);

router.post("/change_pin", jwtAuth, controller.change_pin);

router.get("/balance", jwtAuth, controller.balance);

router.get("/all_accounts", jwtAuth, controller.all_accounts);

router.get("/recent_transactions", jwtAuth, controller.recent_transactions);

router.post(
    "/create_local_bank_beneficiary",
    jwtAuth,
    controller.create_local_bank_beneficiary
  );
  
  router.post(
    "/create_inter_bank_beneficiary",
    jwtAuth,
    controller.create_inter_bank_beneficiary
  );
  
  router.get(
    "/view_local_bank_beneficiaries",
    jwtAuth,
    controller.view_local_bank_beneficiaries
  );
  
  router.get(
    "/view_inter_bank_beneficiaries",
    jwtAuth,
    controller.view_inter_bank_beneficiaries
  );

  router.get(
    "/view_all_beneficiaries",
    jwtAuth,
    controller.view_all_beneficiaries
  );

router.get("/receipt", 
// jwtAuth, 
controller.receipt);


module.exports = router;
