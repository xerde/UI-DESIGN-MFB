var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").FundsTransferController;
var values = require("./values");

const passport = require("passport");
const jwtAuth = passport.authenticate("jwtCheck", { session: false });

router.post("/inter_bank_query", jwtAuth, controller.inter_bank_query);

router.post("/inter_bank", jwtAuth, controller.inter_bank);

router.post("/local_transfer_query", jwtAuth, controller.local_transfer_query);

router.post("/local_transfer", jwtAuth, controller.local_transfer);

router.get("/get_banks", 
jwtAuth, 
controller.get_banks);


module.exports = router;
