var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").SignUpController;
const authController = require("../controllers").AuthController;
var values = require("./values");
const multer = require("multer");
const multerConfig = multer({ dest: "uploads/" });

const passport = require("../security/passport");

const jwtTempAuth = passport.authenticate("jwtTempCheck", { session: false });

const jwtAuth = passport.authenticate("jwtCheck", { session: false });

router.post("/fetch_by_BVN", controller.fetch_by_BVN);

router.post("/fetch_by_bank_account", controller.fetch_by_bank_account);

router.post("/fetch_by_phone", controller.fetch_by_phone);

router.post(
  "/verify_phone_by_bvn",
  controller.verify_phone_by_bvn,
  authController.createTempCustomerJWT
);

router.post(
  "/verify_phone_by_account",
  controller.verify_phone_by_account,
  authController.createTempCustomerJWT
);

router.post(
  "/verify_phone",
  controller.verify_phone,
  authController.createTempCustomerJWT
);

router.post("/update_account", jwtTempAuth, controller.update_account);

router.get("/check_email_exists/:email", jwtTempAuth, controller.check_email_exists);

router.get("/check_phone_exists/:phone", jwtTempAuth, controller.check_phone_exists);

router.post(
  "/create_photo",
  jwtAuth,
  multerConfig.single("photo"),
  controller.create_photo
); 

router.post(
  "/create_video",
  jwtAuth,
  multerConfig.single("video"),
  controller.create_video
);

router.post(
  "/create_signature",
  jwtAuth,
  multerConfig.single("signature"),
  controller.create_signature
);

router.post(
  "/create_document",
  jwtAuth,
  multerConfig.single("document"),
  controller.create_document
);

router.post("/complete_signup", jwtAuth, controller.complete_signup);

router.get("/get_support_lines", controller.get_support_lines);

router.get("/get_doc_types", controller.get_doc_types);

router.get("/get_sectors", controller.get_sectors);

module.exports = router;
