var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").BillerController;
var values = require("./values");
const AuthController = require("../controllers").AuthController;
const fundsTransferController = require("../controllers")
  .FundsTransferController;

const passport = require("../security/passport");
const jwtAuth = passport.authenticate("jwtCheck", { session: false });

const jwtAdminCheck = passport.authenticate("jwtAdminCheck", {
  session: false,
});

router.post(
  "/create_category",
  // jwtAuth,
  controller.create_category
);

router.get(
  "/biller_categories",
  // jwtAuth,
  controller.biller_categories
);

router.get(
  "/view_billers",
  // jwtAuth,
  controller.view_billers
);

router.get(
  "/view_all_billers",
  // jwtAuth,
  controller.view_all_billers
);

router.get(
  "/view_services",
  // jwtAuth,
  controller.view_services
);

router.get(
  "/view_custom_fields",
  // jwtAuth,
  controller.view_custom_fields
);

router.get(
  "/required_fields",
  // jwtAuth,
  controller.required_fields
);

router.post(
  "/parse_services",
  // jwtAuth,
  controller.parse_services
);

router.post(
  "/pay_bill",
  jwtAuth,
  // controller.lookup_field,
  controller.generate_rrr,
  fundsTransferController.local_transfer,
  controller.process_transaction
);

router.post("/generate_rrr", jwtAuth, controller.generate_rrr);

router.post("/lookup_field", jwtAuth, controller.lookup_field);

router.post(
  "/fetch_billing_data",
  jwtAuth,
  controller.fetch_billing_data
);

router.post(
  "/process_transaction",
  // jwtAuth,
  controller.process_transaction
);

router.get(
  "/transaction_status",
  // jwtAuth,
  controller.transaction_status
);

router.post(
  "/payment_notification",
  // jwtAuth,
  controller.payment_notification
);

router.get(
  "/airtime_options",
  // jwtAuth,
  controller.airtime_options
);

router.get(
  "/data_billers",
  // jwtAuth,
  controller.data_billers
);

router.get(
  "/service_options",
  // jwtAuth,
  controller.service_options
);

module.exports = router;
