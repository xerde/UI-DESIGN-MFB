const mung = require("express-mung");
const Log = require("../models").Log;

const logAudit = async (body, req, res) => {
  // console.log('req.body', req.body)
  // let headers = res.getHeaders()
  //   console.log('getHeaders', req.headers)
  //   console.log('connection', req.connection.remoteAddress)
  // console.log('body', body)
  // console.log('req', req)

  let authRequest = req.originalUrl.startsWith("/api/v1/auth") ? true : false;

  let protectedRoute = false;

  switch (req.originalUrl) {
    case "/api/v1/funds-transfer/local_transfer":
      protectedRoute = true;
      break;

    case "/api/v1/funds-transfer/inter_bank":
      protectedRoute = true;
      break;

    case "/api/v1/bank-account/create_pin":
      protectedRoute = true;
      break;

    case "/api/v1/bank-account/change_pin":
      protectedRoute = true;
      break;

    default:
      break;
  }

  req.headers.authorization = "REDACTED";

  try {
    let customerRole = null;

    if (req.user) {
      if (req.originalUrl === "/api/v1/auth/sign_in") {
        customerRole = true;
      } else if (req.originalUrl === "/api/v1/auth/admin_sign_in") {
        customerRole = false;
      } else {
        customerRole = req.user.roles.find((item) => item === "CUSTOMER");
      }
    }

    // console.log("customerRole", customerRole);
    //test
    await Log.create({
      ...(req.user &&
        customerRole && {
          //user is a customer
          customerId: req.user ? req.user.id : null,
        }),
      ...(req.user &&
        !customerRole && {
          //user is an admin
          adminId: req.user ? req.user.id : null,

          ...(req.method === "POST" && {
            subjectId: req.body.customer_id ? req.body.customer_id : null,
          }),

          ...(req.method === "GET" && {
            subjectId: req.query.customer_id ? req.query.customer_id : null,
          }),
        }),
      // customerId: req.user? req.user.id: null,
      ip: req.headers["x-forwarded-for"] || req.connection.remoteAddress,
      endpoint: req.originalUrl,
      requestMethod: req.method,
      requestHeaders: JSON.stringify(req.headers),
      requestBody:
        authRequest || protectedRoute
          ? JSON.stringify("REDACTED")
          : JSON.stringify(req.body),
      requestParams: JSON.stringify(req.params),
      requestQuery: JSON.stringify(req.query),
      responseCode: res.statusCode,
      responseHeaders: JSON.stringify(res.getHeaders()),
      responseBody: authRequest
        ? JSON.stringify("REDACTED")
        : JSON.stringify(body).slice(0, 3000),
    });
  } catch (error) {
    console.log("error", error);
  }

  return body;
};

module.exports = mung.jsonAsync(logAudit);
