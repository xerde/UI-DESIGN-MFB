var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").AdminController;
const AuthController = require("../controllers").AuthController;

const passport = require("../security/passport");

const jwtAdminCheck = passport.authenticate("jwtAdminCheck", {
  session: false,
});

router.delete(
  "/customer_by_phone/:phone",
  // jwtAdminCheck,
  // AuthController.role_authorization(["SUPER"]),
  controller.delete_customer_by_phone
);

router.get(
  "/view_roles",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_roles
);

router.get(
  "/view_admins",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_admins
);

router.get(
  "/view_admins_by_role",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_admins_by_role
);

router.post(
  "/create_role",
  jwtAdminCheck,
  AuthController.role_authorization(["SUPER"]),
  controller.create_role
);

router.post(
  "/create_admin",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.create_admin
);

router.post(
  "/delete_admin",
  jwtAdminCheck,
  AuthController.role_authorization(["SUPER"]),
  controller.delete_admin
);

router.post(
  "/assign_role",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.assign_role
);

router.post(
  "/remove_role_mapping",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.remove_role_mapping
);

router.post(
  "/remove_role_mapping_by_roleId",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.remove_role_mapping_by_roleId
);

router.get(
  "/view_admin_activity",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_admin_activity
);

router.get(
  "/view_admin_customer_activity",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_admin_customer_activity
);

router.get(
  "/view_customer_target_activity",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.view_customer_target_activity
);

module.exports = router;
