var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").ScriptController;
var values = require("./values");
const multer = require("multer");
const multerConfig = multer({ dest: "uploads/" });

const passport = require("passport");
const jwtAuth = passport.authenticate("jwtCheck", { session: false });

router.get("/task", controller.batchCreateBanks);

router.post(
  "/upload_photo",
  multerConfig.single("photo"),
  controller.upload_photo
);

router.get("/local_transfer_alert", jwtAuth, controller.local_transfer_alert);

module.exports = router;
