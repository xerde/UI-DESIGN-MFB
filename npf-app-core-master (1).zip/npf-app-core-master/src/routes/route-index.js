var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
var apiVersion = "1.0.0";

var dayjs = require("dayjs");

//Required routes
const CustomerUserRoute = require("./CustomerUser");
const AdminUserRoute = require("./AdminUser");
const CustomerInfoRoute = require("./CustomerInfo");
// const BankAccountRoute = require("./BankAccount");
const OfficerInfoRoute = require("./OfficerInfo");
const BeneficiaryRoute = require("./Beneficiary");
const SupportMessageRoute = require("./SupportMessage");
const FundsTransferRequestRoute = require("./FundsTransferRequest");
const AdminRoleRoute = require("./AdminRole");
const AdminUserRoleRoute = require("./AdminUserRole");
const CustomerAuditTrailRoute = require("./CustomerAuditTrail");
const PasswordChangeHistoryRoute = require("./PasswordChangeHistory");
const SignUpRoute = require("./signup-routes");
const BankAccountRoute = require("./bank-account-routes");
const FundsTransferRoute = require("./funds-transfer-routes");
const AdminRoute = require("./admin-routes");
const ScriptRoute = require("./script-routes");
const AuthRoute = require("./auth-routes");
const SupportRoute = require("./support-routes");
const BillerRoute = require("./biller-routes");
const AnalyticsRoute = require("./analytics-routes");

router.use(function (req, res, next) {
  console.log(`${dayjs()}: ${req.originalUrl}`);
  next();
});

router.use(require("./audit"));

//Registered routes
router.use("/customerusers", CustomerUserRoute);
router.use("/adminusers", AdminUserRoute);
router.use("/customerinfos", CustomerInfoRoute);
// router.use("/bankaccounts", BankAccountRoute);
router.use("/officerinfos", OfficerInfoRoute);
router.use("/beneficiaries", BeneficiaryRoute);
router.use("/supportmessages", SupportMessageRoute);
router.use("/fundstransferrequests", FundsTransferRequestRoute);
router.use("/adminroles", AdminRoleRoute);
router.use("/adminuserroles", AdminUserRoleRoute);
router.use("/customeraudittrails", CustomerAuditTrailRoute);
router.use("/passwordchangehistories", PasswordChangeHistoryRoute);
router.use("/bank-account", BankAccountRoute);
router.use("/signup", SignUpRoute);
router.use("/funds-transfer", FundsTransferRoute);
router.use("/admin", AdminRoute);
router.use("/script", ScriptRoute);
router.use("/auth", AuthRoute);
router.use("/support", SupportRoute);
router.use("/biller", BillerRoute)
router.use("/analytics", AnalyticsRoute)

//API start
router.get("/", function (req, res) {
  res.status(200).send({
    message: "Welcome to the  API - v" + apiVersion,
    status: "updated",
  });
});

module.exports = router;
