var express = require("express");
const passport = require("passport");
var router = express.Router();
const controller = require("../controllers").AuthController;

const localLogin = passport.authenticate("localLogin", { session: false });

const adminLogin = passport.authenticate("adminLogin", { session: false });

const jwtAuth = passport.authenticate("jwtCheck", { session: false });

const jwtTempAuth = passport.authenticate("jwtTempCheck", { session: false });

router.get("/check", jwtAuth, controller.fetchUserInfo);

// router.post("/sign_in", localLogin, controller.createCustomerJWT);

router.post("/sign_in", function (req, res, next) {
  passport.authenticate("localLogin", function (err, user, info) {
    if (err) {
      return next(err);
    }

    if (user) {
      req.user = user;
      controller.createCustomerJWT(req, res);
    } else {
      return res.status(401).json(info); //info contains the error message
    }
  })(req, res, next);
});

router.post("/admin_sign_in", adminLogin, controller.createAdminJWT);

router.post("/reset_password", controller.reset_password);

router.post(
  "/update_password",
  jwtTempAuth,
  controller.update_password,
  controller.createCustomerJWT
);

module.exports = router;
