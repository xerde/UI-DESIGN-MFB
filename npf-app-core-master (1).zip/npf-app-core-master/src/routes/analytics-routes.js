var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const controller = require("../controllers").AnalyticsController;


const AuthController = require("../controllers").AuthController;

const passport = require("../security/passport");

const jwtAdminCheck = passport.authenticate("jwtAdminCheck", {
  session: false,
});

router.get(
  "/export_customers",
  jwtAdminCheck,
  AuthController.role_authorization(["ADMIN"]),
  controller.export_customers
);


module.exports = router;
