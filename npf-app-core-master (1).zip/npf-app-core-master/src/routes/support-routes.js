var models = require("../models");
var express = require("express");
var router = express.Router();
var utils = require("../utils");
const multer = require("multer");
const multerConfig = multer({ dest: "uploads/" });
const controller = require("../controllers").SupportController;
var values = require("./values");
const AuthController = require("../controllers").AuthController;

const passport = require("../security/passport");

const jwtAdminCheck = passport.authenticate("jwtAdminCheck", {
  session: false,
});

router.get(
  "/view_customers",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.view_customers
);

router.get(
  "/view_customer",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.view_customer
);

router.get(
  "/view_users_core",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.view_users_core
);

router.get(
  "/view_customer_bank_accounts",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.view_customer_bank_accounts
);

router.get(
  "/view_customer_logs",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.view_customer_logs
);

router.get(
  "/view_customer_transactions",
  // jwtAdminCheck,
  // AuthController.role_authorization(["CSO"]),
  controller.view_customer_transactions
);

router.get(
  "/view_customer_activity",
  // jwtAdminCheck,
  // AuthController.role_authorization(["CSO"]),
  controller.view_customer_activity
);

router.get("/get_support_lines", controller.get_support_lines);

router.get(
  "/search_customers",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.search_customers
);

router.post(
  "/liveliness_check",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.liveliness_check
);

router.post(
  "/liveliness_uncheck",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.liveliness_uncheck
);

router.post(
  "/photo_check",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.photo_check
);

router.post(
  "/photo_uncheck",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.photo_uncheck
);

router.post(
  "/signature_check",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.signature_check
);

router.post(
  "/signature_uncheck",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.signature_uncheck
);

router.post(
  "/documents_check",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.documents_check
);

router.post(
  "/documents_uncheck",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.documents_uncheck
);

router.post(
  "/enforce_pnd",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.enforce_pnd
);

router.post(
  "/remove_pnd",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.remove_pnd
);

router.post(
  "/enable_customer",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.enable_customer
);

router.post(
  "/disable_customer",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.disable_customer
);

router.post(
  "/unlock_account",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.unlock_account
);

router.post(
  "/reset_password",
  // jwtAdminCheck,
  // AuthController.role_authorization(["CSO"]),
  controller.reset_password
);

router.post(
  "/reset_pin",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.reset_pin
);

router.post(
  "/reset_device",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.reset_device
);

router.post(
  "/complete_user_signup",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.complete_user_signup
);

router.post(
  "/update_customer_info",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  controller.update_customer_info
);

router.post(
  "/create_photo",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  multerConfig.single("photo"),
  controller.create_photo
);

router.post(
  "/create_video",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  multerConfig.single("video"),
  controller.create_video
);

router.post(
  "/create_signature",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  multerConfig.single("signature"),
  controller.create_signature
);

router.post(
  "/create_document",
  jwtAdminCheck,
  AuthController.role_authorization(["CSO"]),
  multerConfig.single("document"),
  controller.create_document
);

module.exports = router;
