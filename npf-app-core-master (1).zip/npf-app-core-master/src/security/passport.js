var passport = require("passport");

var JwtStrategy = require("passport-jwt").Strategy;
var ExtractJwt = require("passport-jwt").ExtractJwt;
var LocalStrategy = require("passport-local").Strategy;

const Sequelize = require("../models/index").Sequelize;

const CustomerUser = require("../models").CustomerUser;
const BankAccount = require("../models").BankAccount;
const CustomerInfo = require("../models").CustomerInfo;
const AdminUser = require("../models").AdminUser;
const AdminUserRole = require("../models").AdminUserRole;
const AdminRole = require("../models").AdminRole;
const LoginAttempt = require("../models").LoginAttempt;

var dayjs = require("dayjs");

var jwtTempCheck = new JwtStrategy(
  {
    jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme("Bearer"),
    secretOrKey: process.env.JWT_TEMP_SECRET,
  },
  function (payload, done) {
    return done(null, payload);
  }
);

var jwtCheck = new JwtStrategy(
  {
    jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme("Bearer"),
    secretOrKey: process.env.JWT_SECRET,
  },
  function (payload, done) {
    return done(null, payload);
  }
);

var jwtAdminCheck = new JwtStrategy(
  {
    jwtFromRequest: ExtractJwt.fromAuthHeaderWithScheme("Bearer"),
    secretOrKey: process.env.JWT_ADMIN_SECRET,
  },
  function (payload, done) {
    // console.log("payload", payload);
    return done(null, payload);
  }
);

var localLogin = new LocalStrategy(
  {
    usernameField: "phone",
    passReqToCallback: true,
  },
  async (req, username, password, done) => {
    console.log("username", username);
    try {
      let foundUser = null;

      if (username.length === 10) {
        let bankAccount = await BankAccount.findOne({
          where: { accountnumber: username },
          include: [
            { model: CustomerUser, include: [{ model: CustomerInfo }] },
          ],
        });
        if (bankAccount) foundUser = bankAccount.CustomerUser;
      } else {
        if (username.startsWith("0")) {
          username = username.replace("0", "234");
        }
        foundUser = await CustomerUser.findOne({
          where: { username: username },
          include: [{ model: CustomerInfo }],
        });
      }

      if (!foundUser) {
        return done(null, false, {
          error: "Login failed. Username or password is invalid.",
        });
      }

      const validPassword = foundUser.comparePassword(password);

      var ipAddress = (
        req.headers["x-forwarded-for"] ||
        req.connection.remoteAddress ||
        ""
      )
        .split(",")[0]
        .trim();

      if (validPassword) {
        if (
          foundUser.locked &&
          dayjs(foundUser.lockedon)
            .add(process.env.LOCKOUT_MINUTES, "m")
            .isAfter(dayjs())
        ) {
          return done(null, false, {
            error: `Account locked. Retry in ${process.env.LOCKOUT_MINUTES} minutes`,
          });
        }

        await LoginAttempt.create({
          customerId: foundUser.id,
          success: true,
          ipAddress: ipAddress,
        });

        if (req.body.device_id) {
          //mobile device
          if (foundUser.CustomerInfos[0].deviceid) {
            //user has existing device
            if (req.body.device_id !== foundUser.CustomerInfos[0].deviceid) {
              //device mismatch
              return done(null, false, {
                error: "User not allowed to login from multiple devices.",
              });
            }
          } else {
            //user doesn't have existing device
            await CustomerInfo.update(
              { deviceid: req.body.device_id },
              { where: { id: foundUser.CustomerInfos[0].id } }
            );

            //This blocks different users from using a particular device
            // let deviceOwner = await CustomerUser.findOne({
            //   where: { deviceid: foundUser.CustomerInfos[0].deviceid },
            //   attributes: ["id"],
            // });

            // if (deviceOwner && deviceOwner.id !== foundUser.id) {
            //   return done(null, false, {
            //     error: "This device is already assigned to a different user.",
            //   });
            // } else {
            //   foundUser.CustomerInfos[0].deviceid = req.body.device_id;
            //   await foundUser.save();
            // }
          }
        }

        foundUser.last_login_date = new Date();

        await foundUser.save();

        return done(null, foundUser);
      } else {
        //invalid password
        await LoginAttempt.create({
          customerId: foundUser.id,
          success: false,
          ipAddress: ipAddress,
        });

        let loginAttempts = await LoginAttempt.findAll({
          where: { customerId: foundUser.id.toString() },
          limit: 3,
          order: [["createdAt", "DESC"]],
        });

        let failedAttempts = 0;

        for (const attempt of loginAttempts) {
          if (!attempt.success) failedAttempts++;
        }

        if (failedAttempts >= 3) {
          await CustomerUser.update(
            { locked: true, lockedon: new Date() },
            { where: { id: foundUser.id } }
          );
          return done(null, false, {
            error: `Account locked due to excessive failed login attempts. Retry in ${process.env.LOCKOUT_MINUTES} minutes`,
          });
        } else {
          return done(null, false, {
            error: "Login failed. Please try again.",
          });
        }
      }
    } catch (error) {
      console.log("error", error);
      return done(error);
    }
  }
);

var adminLogin = new LocalStrategy(
  {
    usernameField: "email",
  },
  async (username, password, done) => {
    console.log("username", username);
    try {
      const foundUser = await AdminUser.findOne({
        where: { username: username },
        include: [{ model: AdminUserRole, include: [{ model: AdminRole }] }],
      });

      if (!foundUser) {
        return done(null, false, {
          error: "Login failed. Please try again.",
        });
      }

      const validPassword = foundUser.comparePassword(password);

      if (validPassword) {
        return done(null, foundUser);
      } else {
        return done(null, false, {
          error: "Login failed. Please try again.",
        });
      }
    } catch (error) {
      console.log("error", error);
      return done(error);
    }
  }
);

passport.use("jwtTempCheck", jwtTempCheck);

passport.use("jwtCheck", jwtCheck);
passport.use("localLogin", localLogin);

passport.use("jwtAdminCheck", jwtAdminCheck);
passport.use("adminLogin", adminLogin);

module.exports = passport;
