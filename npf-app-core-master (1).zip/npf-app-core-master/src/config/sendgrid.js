const sendGrid = require("@sendgrid/mail");
// sendGrid.setApiKey(process.env.SENDGRID_API_KEY);

sendGrid.setApiKey(process.env.SENDGRID_API_KEY);

module.exports = sendGrid;
