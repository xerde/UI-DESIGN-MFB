const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;
const Log = require("../models").Log;
const FundsTransferRequest = require("../models").FundsTransferRequest;

const Op = require("../models/index").Sequelize.Op;

const logger = require("../utils").logger;

const bank_codes = require("../constants/bank-codes");
var dayjs = require("dayjs");

const NIBSS_Service = require("../services/NIBSS_Service");
const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");
const CBA_Service = require("../services/CBA_Service");
const CustomerData_Service = require("../services/CustomerData_Service");
const Azure_Service = require("../services/Azure_Service");

module.exports = {
  /**
   * Routes different types of search for the model
   * @param {*} req
   * @param {*} res
   */

  async get_support_lines(req, res) {
    try {
      let response = [
        { name: "line 1", value: "+2348011111111" },
        { name: "line 2", value: "+2348022222222" },
        { name: "line 3", value: "+2348033333333" },
      ];

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customers(req, res) {
    try {
      let response = null;

      let channel = req.query.channel;
      let reg_complete = req.query.reg_complete === "true";

      if (Object.keys(req.query).length === 0) {
        //empty query
        response = await CustomerInfo.findAll();
      } else {
        response = await CustomerInfo.findAll({
          where: {
            ...(channel && { registration_channel: channel }),
            ...(req.query.reg_complete && { signup_incomplete: !reg_complete }),
          },
        });
      }

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async search_customers(req, res) {
    try {
      let response = await CustomerInfo.findAll({
        where: {
          [Op.or]: [
            {
              bvnhash: {
                [Op.iLike]: `%${req.query.searchPhrase}%`,
              },
            },
            {
              firstname: {
                [Op.iLike]: `%${req.query.searchPhrase}%`,
              },
            },
            {
              lastname: {
                [Op.iLike]: `%${req.query.searchPhrase}%`,
              },
            },
            {
              middlename: {
                [Op.iLike]: `%${req.query.searchPhrase}%`,
              },
            },
            {
              email: {
                [Op.iLike]: `%${req.query.searchPhrase}%`,
              },
            },
            {
              phone: {
                [Op.iLike]: `%${req.query.searchPhrase.substring(1)}%`, // remove the 0 if any, in front of string
              },
            },
          ],
        },
      });

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer(req, res) {
    try {
      let response = await CustomerInfo.findOne({
        where: { id: req.query.customer_id },
      });
      // let response = await CustomerUser.findAll();

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer_bank_accounts(req, res) {
    try {
      let response = await CustomerInfo.findOne({
        where: { id: req.query.customer_id },
        include: [
          {
            model: CustomerUser,
            include: [
              {
                model: BankAccount,
                attributes: ["accountnumber", "accountname", "type", "balance"],
              },
            ],
          },
        ],
      });
      // let response = await CustomerUser.findAll();

      if (response) {
        return res
          .status(200)
          .send({ error: false, result: response.CustomerUser.BankAccounts });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Customer not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer_logs(req, res) {
    try {
      let response = await Log.findAll({
        where: { customerId: req.query.customer_id },
      });
      // let response = await CustomerUser.findAll();

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer_activity(req, res) {
    try {
      let response = await Log.findAll({
        where: {
          [Op.and]: [
            {
              customerId: req.query.customer_id,
            },
            {
              endpoint: {
                [Op.iLike]: `/api/v1/funds-transfer/%`,
              },
            },
          ],
        },
      });
      // let response = await CustomerUser.findAll();

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer_transactions(req, res) {
    try {
      let logs = await BankAccount.findAll({
        raw: true,
        where: {
          [Op.and]: [
            {
              customerId: req.query.customer_id,
            },
            {
              [Op.or]: [
                {
                  endpoint: `/api/v1/funds-transfer/local_transfer`,
                },
                {
                  endpoint: `/api/v1/funds-transfer/inter_bank`,
                },
              ],
            },
          ],
        },
        include: [{ model: FundsTransferRequest }],
        order: [["createdAt", "DESC"]],
        limit: 20,
      });

      let structure = {
        date: "",
        ip_address: "",
        amount: "",
        source_account: "",
        destination_account: "",
        destination_bank: "",
        status: "",
        responseMessage: "",
      };

      let response = [];

      for (const log of logs) {
        let requestBody = JSON.parse(log.requestBody);
        let responseBody = JSON.parse(log.responseBody);

        console.log("log", log);
        // console.log('requestBody', requestBody)
        // console.log('responseBody', responseBody)

        if (log.endpoint === "/api/v1/funds-transfer/local_transfer") {
          structure.destination_bank = "NPF-MFB";
        } else {
          continue;
          let bank = bank_codes.find(
            (item) => item.code === requestBody.destination_institution_code
          );
          structure.destination_bank = bank.name;
        }

        structure.date = log.createdAt;
        structure.ip_address = log.ip;
        structure.amount = requestBody.amount;
        structure.source_account = requestBody.source_account;
        structure.destination_account = requestBody.destination_account;
        structure.status =
          log.responseCode === "200" && responseBody.error === false
            ? "SUCCESS"
            : "FAILED";
        structure.responseMessage = responseBody.narration;

        response.push(structure);
      }

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  //TODO: deprecated
  async view_customer_transactions_old(req, res) {
    try {
      let logs = await Log.findAll({
        raw: true,
        where: {
          [Op.and]: [
            {
              customerId: req.query.customer_id,
            },
            {
              [Op.or]: [
                {
                  endpoint: `/api/v1/funds-transfer/local_transfer`,
                },
                {
                  endpoint: `/api/v1/funds-transfer/inter_bank`,
                },
              ],
            },
          ],
        },
        order: [["createdAt", "DESC"]],
        limit: 20,
      });

      let structure = {
        date: "",
        ip_address: "",
        amount: "",
        source_account: "",
        destination_account: "",
        destination_bank: "",
        status: "",
        responseMessage: "",
      };

      let response = [];

      for (const log of logs) {
        let requestBody = JSON.parse(log.requestBody);
        let responseBody = JSON.parse(log.responseBody);

        console.log("log", log);
        // console.log('requestBody', requestBody)
        // console.log('responseBody', responseBody)

        if (log.endpoint === "/api/v1/funds-transfer/local_transfer") {
          structure.destination_bank = "NPF-MFB";
        } else {
          continue;
          let bank = bank_codes.find(
            (item) => item.code === requestBody.destination_institution_code
          );
          structure.destination_bank = bank.name;
        }

        structure.date = log.createdAt;
        structure.ip_address = log.ip;
        structure.amount = requestBody.amount;
        structure.source_account = requestBody.source_account;
        structure.destination_account = requestBody.destination_account;
        structure.status =
          log.responseCode === "200" && responseBody.error === false
            ? "SUCCESS"
            : "FAILED";
        structure.responseMessage = responseBody.narration;

        response.push(structure);
      }

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_users_core(req, res) {
    try {
      // let response = await CustomerInfo.findAll();
      let response = await CustomerUser.findAll();

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async enforce_pnd(req, res) {
    try {
      let response = await CustomerInfo.update(
        { PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async remove_pnd(req, res) {
    try {
      let response = await CustomerInfo.update(
        { PND: false },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async liveliness_check(req, res) {
    try {
      let customerId = req.body.customer_id;
      let response = await CustomerInfo.update(
        { livelinesschecked: "APPROVED" },
        { where: { id: customerId } }
      );

      if (response[0] === 1) {
        await CustomerData_Service.profile_completion(customerId);

        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async liveliness_uncheck(req, res) {
    try {
      // let response = await CustomerInfo.update(
      //   { livelinesschecked: "DISAPPROVED", profilecomplete: false, PND: true },
      //   { where: { id: req.body.customer_id } }
      // );

      let response = await CustomerInfo.update(
        { livelinesschecked: "DISAPPROVED", PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  // async documents_check(req, res) {
  //   try {
  //     let response = await CustomerInfo.update(
  //       { documentschecked: true },
  //       { where: { id: req.body.customer_id } }
  //     );

  //     if (response[0] === 1) {
  //       return res.status(200).send({ error: false, message: "Updated" });
  //     } else {
  //       return res.status(200).send({ error: true, message: "Update failed" });
  //     }
  //   } catch (error) {
  //     logger.error("error: " + error);
  //     return res
  //       .status(500)
  //       .send({ error: true, message: "Your action could not be completed." });
  //   }
  // },

  // async documents_uncheck(req, res) {
  //   try {
  //     let response = await CustomerInfo.update(
  //       { documentschecked: false, PND: true },
  //       { where: { id: req.body.customer_id } }
  //     );

  //     if (response[0] === 1) {
  //       return res.status(200).send({ error: false, message: "Updated" });
  //     } else {
  //       return res.status(200).send({ error: true, message: "Update failed" });
  //     }
  //   } catch (error) {
  //     logger.error("error: " + error);
  //     return res
  //       .status(500)
  //       .send({ error: true, message: "Your action could not be completed." });
  //   }
  // },

  async photo_check(req, res) {
    try {
      let customerId = req.body.customer_id;

      let response = await CustomerInfo.update(
        { photostatus: "APPROVED" },
        { where: { id: customerId } }
      );

      if (response[0] === 1) {
        await CustomerData_Service.profile_completion(customerId);

        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async photo_uncheck(req, res) {
    try {
      let response = await CustomerInfo.update(
        { photostatus: "DISAPPROVED", profilecomplete: "DISAPPROVED", PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async signature_check(req, res) {
    try {
      let customerId = req.body.customer_id;

      let response = await CustomerInfo.update(
        { signaturestatus: "APPROVED" },
        { where: { id: customerId } }
      );

      if (response[0] === 1) {
        await CustomerData_Service.profile_completion(customerId);
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async signature_uncheck(req, res) {
    try {
      let response = await CustomerInfo.update(
        { signaturestatus: "DISAPPROVED", profilecomplete: "DISAPPROVED", PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async documents_check(req, res) {
    try {
      let customerId = req.body.customer_id;

      let response = await CustomerInfo.update(
        { documentstatus: "APPROVED" },
        { where: { id: customerId } }
      );

      if (response[0] === 1) {
        await CustomerData_Service.profile_completion(customerId);
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async documents_uncheck(req, res) {
    try {
      let response = await CustomerInfo.update(
        { documentstatus: "DISAPPROVED", profilecomplete: "DISAPPROVED", PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async enable_customer(req, res) {
    try {
      let response = await CustomerInfo.update(
        {
          enabled: true,
        },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async disable_customer(req, res) {
    try {
      let response = await CustomerInfo.update(
        { enabled: false, PND: true },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        return res.status(200).send({ error: false, message: "Updated" });
      } else {
        return res.status(200).send({ error: true, message: "Update failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async unlock_account(req, res) {
    try {
      let customerInfo = await CustomerInfo.findOne({
        where: { id: req.body.customer_id },
        include: [{ model: CustomerUser }],
      });

      if (customerInfo) {
        let response = await CustomerUser.update(
          { locked: false },
          { where: { id: customerInfo.user } }
        );

        if (response[0] === 1) {
          return res
            .status(200)
            .send({ error: false, message: "Account unlocked" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Action failed" });
        }
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Customer not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async reset_pin(req, res) {
    try {
      let response = await CustomerInfo.update(
        { has_pin: false },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        let customerInfo = await CustomerInfo.findOne({
          where: { id: req.body.customer_id },
        });

        await Email_Service.pinReset(
          customerInfo.email,
          customerInfo.firstname,
          customerInfo.lastname
        );

        await SMS_Service.pinReset(
          customerInfo.phone,
          customerInfo.firstname,
          customerInfo.lastname
        );

        return res
          .status(200)
          .send({ error: false, message: "Customer Pin has been reset" });
      } else {
        return res.status(200).send({ error: true, message: "Action failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async reset_password(req, res) {
    try {
      let customerInfo = await CustomerInfo.findOne({
        where: { id: req.body.customer_id },
      });

      if (customerInfo) {
        let tempPassword = await CustomerData_Service.resetPassword(
          customerInfo.user
        );

        Email_Service.passwordReset(customerInfo, tempPassword);
        SMS_Service.passwordReset(customerInfo);
      }

      return res.status(200).send({
        error: false,
        message:
          "If account exists, a temporary password will be sent to the registered mailbox",
      });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async reset_device(req, res) {
    try {
      let response = await CustomerInfo.update(
        { deviceid: null },
        { where: { id: req.body.customer_id } }
      );

      if (response[0] === 1) {
        let customerInfo = await CustomerInfo.findOne({
          where: { id: req.body.customer_id },
        });

        await Email_Service.device_unlink(
          customerInfo.email,
          customerInfo.firstname,
          customerInfo.lastname
        );

        await SMS_Service.device_unlink(
          customerInfo.phone,
          customerInfo.firstname,
          customerInfo.lastname
        );

        return res
          .status(200)
          .send({ error: false, message: "Customer untied from device" });
      } else {
        return res.status(200).send({ error: true, message: "Action failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async complete_user_signup(req, res) {
    try {
      let feedback = await CustomerData_Service.create_inlaks_account(
        req.body.customer_id
      );

      console.log("creation feedback", feedback);

      if (feedback.success) {
        let data = feedback.data;

        // console.log('data.accountnumber', data.accountnumber)

        await Email_Service.accountUpdated(
          data.email,
          data.firstname,
          data.lastname,
          data.accountnumber
        );

        await SMS_Service.accountUpdated(
          data.phone,
          data.firstname,
          data.lastname,
          data.accountnumber
        );

        return res
          .status(200)
          .send({ error: false, message: "Signup completed" });
      } else {
        return res.status(200).send({ error: true, message: feedback.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async update_customer_info(req, res) {
    try {
      let customerInfoId = req.body.customer_id;
      let bankAccount = await BankAccount.findOne({
        where: { user: customerInfoId },
      });

      if (bankAccount) {
        console.log("bankAccount.accountname", bankAccount.accountname);

        let response = await CBA_Service.fetchCustomerName(
          bankAccount.accountnumber
        );

        console.log("response", response);

        if (response.status) {
          let updatedCustomerInfo = await CustomerData_Service.update_customer_info(
            response.data,
            customerInfoId
          );

          await Email_Service.infoUpdated(
            updatedCustomerInfo.email,
            updatedCustomerInfo.firstname,
            updatedCustomerInfo.lastname
          );

          await SMS_Service.infoUpdated(
            updatedCustomerInfo.phone,
            updatedCustomerInfo.firstname,
            updatedCustomerInfo.lastname
          );

          return res.status(200).send({
            error: false,
            message: "Customer Data Updated",
          });
        } else {
          return res
            .status(200)
            .send({ error: true, message: response.message });
        }
      } else {
        return res
          .status(200)
          .send({ error: true, message: "No bank account found for user" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_photo(req, res) {
    try {
      await Azure_Service.uploadCustomerPhoto(req.body.customer_id, req.file);

      await CustomerData_Service.profile_completion(req.body.customer_id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_video(req, res) {
    try {
      await Azure_Service.uploadCustomerVideo(req.body.customer_id, req.file);

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_signature(req, res) {
    try {
      await Azure_Service.uploadCustomerSignature(
        req.body.customer_id,
        req.file
      );

      await CustomerData_Service.profile_completion(req.body.customer_id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_document(req, res) {
    try {
      let payload = req.body;
      await Azure_Service.uploadCustomerDocument(
        req.body.customer_id,
        payload.document_type_id,
        payload.document_number,
        payload.document_issue_date,
        payload.document_expiry_date,
        req.file
      );

      await CustomerData_Service.profile_completion(req.body.customer_id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
