const AdminRole = require("../models").AdminRole;
const AdminUser = require("../models").AdminUser;
const AdminUserRole = require("../models").AdminUserRole;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;
const CustomerUser = require("../models").CustomerUser;
const Log = require("../models").Log;

const Op = require("../models/index").Sequelize.Op;
// const Sequelize = require("../models/index").Sequelize;
var Sequelize = require("sequelize");

const logger = require("../utils").logger;

var dayjs = require("dayjs");

const ExcelJS = require("exceljs");

module.exports = {
  async export_customers(req, res) {
    try {
      res.writeHead(200, {
        "Content-Disposition": 'attachment; filename="Customers.xlsx"',
        "Transfer-Encoding": "chunked",
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      });

      const workbook = new ExcelJS.stream.xlsx.WorkbookWriter({ stream: res });

      const worksheet = workbook.addWorksheet("Customers");

      let header = [];

      header.unshift(
        "firstname",
        "lastname",
        "middlename",
        "phone",
        "email",
        "date of birth",
        "gender",
        "Is Salary Officer",
        "force_number",
        "customerNumber",
        "last_login_date"
      );

      worksheet.addRow(header).commit();

      let customers = await CustomerInfo.findAll();

      for (const customer of customers) {
        let data = [];

        data.push(
          customer.firstname,
          customer.lastname,
          customer.middlename,
          customer.phone,
          customer.email,
          customer.dob,
          customer.gender,
          customer.salary_officer,
          customer.force_number,
          customer.customerNumber,
          customer.last_login_date
        );
        worksheet.addRow(data).commit();
      }

      worksheet.commit();
      workbook.commit();

      // return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
