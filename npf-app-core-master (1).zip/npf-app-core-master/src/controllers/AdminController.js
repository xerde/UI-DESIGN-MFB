const AdminRole = require("../models").AdminRole;
const AdminUser = require("../models").AdminUser;
const AdminUserRole = require("../models").AdminUserRole;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;
const CustomerUser = require("../models").CustomerUser;
const Log = require("../models").Log;

const Op = require("../models/index").Sequelize.Op;
// const Sequelize = require("../models/index").Sequelize;
// const { Sequelize } = require("../models");
var Sequelize = require("sequelize");

const logger = require("../utils").logger;

var dayjs = require("dayjs");

const NIBSS_Service = require("../services/NIBSS_Service");
const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");

var bcrypt = require("bcryptjs");
var salt = bcrypt.genSaltSync(10);

module.exports = {
  /**
   * Routes different types of search for the model
   * @param {*} req
   * @param {*} res
   */

  async delete_customer_by_phone(req, res) {
    try {
      if (process.env.ENV === "PRODUCTION")
        return res
          .status(403)
          .send({ error: true, message: "Not authorized on Production" });

      let customer = await CustomerInfo.findOne({
        where: { phone: req.params.phone },
      });

      if (!customer) {
        return res
          .status(200)
          .send({ error: true, message: "Record not found" });
      }

      await BankAccount.destroy({
        where: { user: customer.user },
      });

      await CustomerInfo.destroy({
        where: { id: customer.id },
      });

      let response = await CustomerUser.destroy({
        where: { id: customer.user },
      });

      return res.status(200).send({
        error: false,
        result: response,
        message: "Successfully deleted",
      });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_roles(req, res) {
    try {
      let response = await AdminRole.findAll();

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_admins(req, res) {
    try {
      let response = await AdminUser.findAll({
        // raw: true,
        attributes: ["username", "id", "firstname", "lastname"],
        include: [
          {
            model: AdminUserRole,
            attributes: ["name"],
          },
        ],
      });

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_admins_by_role(req, res) {
    try {
      let response = await AdminUser.findAll({
        attributes: ["username", "id", "firstname", "lastname"],
        include: [
          {
            model: AdminUserRole,
            where: { id: req.body.roleId },
            attributes: [],
            include: [
              {
                model: AdminRole,
                where: { id: req.body.roleId },
                attributes: [],
              },
            ],
          },
        ],
      });

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_role(req, res) {
    try {
      let existingRole = await AdminRole.findOne({
        where: { name: req.body.name },
      });

      if (existingRole) {
        return res
          .status(200)
          .send({ error: true, message: "Role already exists" });
      } else {
        let response = await AdminRole.create({
          name: req.body.name,
        });

        if (response) {
          return res.status(200).send({ error: false, message: "Created" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Creation failed" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_admin(req, res) {
    try {
      let payload = req.body;

      let hashedPw = payload.password;

      if (payload.password) {
        hashedPw = bcrypt.hashSync(payload.password, salt);
      }

      let existingUser = await AdminUser.findOne({
        where: { username: payload.email },
      });

      if (existingUser) {
        return res
          .status(200)
          .send({ error: true, message: "User already exists" });
      } else {
        let response = await AdminUser.create({
          username: payload.email,
          firstname: payload.firstname,
          lastname: payload.lastname,
          phone: payload.phone,
          password: hashedPw,
        });

        if (response) {
          return res.status(200).send({ error: false, message: "Created" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Creation failed" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async delete_admin(req, res) {
    try {
      await AdminUserRole.destroy({
        where: { user: req.body.adminUserId },
      });

      let response = await AdminUser.destroy({
        where: { id: req.body.adminUserId },
      });

      if (response) {
        return res.status(200).send({ error: false, message: "Created" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Creation failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async assign_role(req, res) {
    try {
      let existingMapping = await AdminUserRole.findOne({
        where: {
          [Op.and]: [{ role: req.body.roleId }, { user: req.body.adminUserId }],
        },
      });

      if (existingMapping) {
        return res
          .status(200)
          .send({ error: true, message: "Role already mapped to user" });
      } else {
        let response = await AdminUserRole.create({
          name: req.body.name,
          role: req.body.roleId,
          user: req.body.adminUserId,
        });

        if (response) {
          return res.status(200).send({ error: false, message: "Assigned" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Failed to assign" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async remove_role_mapping(req, res) {
    try {
      let response = await AdminUserRole.destroy({
        where: { id: req.body.adminUserRoleId },
      });

      if (response) {
        return res.status(200).send({ error: false, message: "Removed" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Failed to remove" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async remove_role_mapping_by_roleId(req, res) {
    try {
      let response = await AdminRole.findOne({
        where: { id: req.body.roleId },
      });

      if (response) {
        await AdminUserRole.destroy({
          where: {
            [Op.and]: [{ user: req.body.adminUserId }, { role: response.id }],
          },
        });

        return res.status(200).send({ error: false, message: "Removed" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Failed to remove" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_admin_activity(req, res) {
    try {
      let response = await Log.findAll({
        where: { adminId: req.query.admin_id },
      });
      // let response = await CustomerUser.findAll();

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_admin_customer_activity(req, res) {
    try {
      let response = await Log.findAll({
        where: {
          [Op.and]: [
            {
              subjectId: req.query.customer_id,
            },
            {
              adminId: req.query.admin_id,
            },
          ],
        },
      });

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_customer_target_activity(req, res) {
    try {
      let response = await Log.findAll({
        where: { subjectId: req.query.customer_id },
      });

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res.status(200).send({ error: true, message: "Logs not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
