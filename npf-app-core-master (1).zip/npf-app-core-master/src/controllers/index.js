const CustomerUserController = require("./CustomerUser");
const AdminUserController = require("./AdminUser");
const CustomerInfoController = require("./CustomerInfo");
const BankAccountController = require("./BankAccountController");
const OfficerInfoController = require("./OfficerInfo");
const BeneficiaryController = require("./Beneficiary");
const SupportMessageController = require("./SupportMessage");
const FundsTransferRequestController = require("./FundsTransferRequest");
const AdminRoleController = require("./AdminRole");
const AdminUserRoleController = require("./AdminUserRole");
const CustomerAuditTrailController = require("./CustomerAuditTrail");
const PasswordChangeHistoryController = require("./PasswordChangeHistory");
const SignUpController = require("./SignUpController");
const FundsTransferController = require("./FundsTransferController");
const AdminController = require("./AdminController");
const ScriptController = require("./ScriptController");
const AuthController = require("./AuthController");
const SupportController = require("./SupportController");
const BillerController = require("./BillerController");
const AnalyticsController = require("./AnalyticsController");

module.exports = {
  CustomerUserController,
  AdminUserController,
  CustomerInfoController,
  BankAccountController,
  OfficerInfoController,
  BeneficiaryController,
  SupportMessageController,
  FundsTransferRequestController,
  AdminRoleController,
  AdminUserRoleController,
  CustomerAuditTrailController,
  PasswordChangeHistoryController,
  SignUpController,
  FundsTransferController,
  AdminController,
  ScriptController,
  AuthController,
  SupportController,
  BillerController,
  AnalyticsController,
};
