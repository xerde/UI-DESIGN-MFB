const logger = require("../utils").logger;

const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const FundsTransferRequest = require("../models").FundsTransferRequest;
const Beneficiary = require("../models").Beneficiary;
const BankAccount = require("../models").BankAccount;

const Bank = require("../models").Bank;

const Bank_Account_Service = require("../services/Bank_Account_Service");
const CBA_Service = require("../services/CBA_Service");
const CustomerData_Service = require("../services/CustomerData_Service");

const Op = require("../models/index").Sequelize.Op;
const Sequelize = require("../models/index").Sequelize;

var dayjs = require("dayjs");
var numeral = require("numeral");
var converter = require("number-to-words");

const bank_codes = require("../constants/bank-codes");

const puppeteer = require("puppeteer");

module.exports = {
  async create_pin(req, res) {
    try {
      let payload = req.body;

      let customer = await CustomerInfo.findOne({
        where: { id: req.user.id },
        include: [{ model: CustomerUser }],
      });

      if (customer.has_pin) {
        return res
          .status(200)
          .send({ error: true, message: "Pin already exists" });
      } else {
        let isExistingPin = await CustomerData_Service.setPin(
          customer.CustomerUser,
          payload.pin
        );

        await CustomerInfo.update(
          { has_pin: true },
          { where: { id: customer.id } }
        );

        return res.status(200).send({ error: false, message: "Pin created" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async change_pin(req, res) {
    try {
      let payload = req.body;

      // console.log("payload", payload);

      let customer = await CustomerInfo.findOne({
        where: { id: req.user.id },
        include: [{ model: CustomerUser }],
      });

      if (customer.has_pin === null) {
        return res.status(200).send({
          error: true,
          message: "Invalid call: there is no existing pin",
        });
      } else {
        let matched = await CustomerData_Service.pinMatched(
          customer.id,
          payload.existing_pin.toString()
        );

        if (matched) {
          let isExistingPin = await CustomerData_Service.setPin(
            customer.CustomerUser,
            payload.new_pin
          );

          if (isExistingPin) {
            return res.status(200).send({
              error: true,
              message: "Use pin different from the existing one",
            });
          } else {
            return res
              .status(200)
              .send({ error: false, message: "Pin changed" });
          }
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Existing pin does not match" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async balance(req, res) {
    try {
      let account_number = req.query.account_number;

      console.log("account_number", account_number);

      let response = await CBA_Service.accountBalance(payload.account);

      if (response.status) {
        return res.status(200).send({
          error: false,
          result: response.data,
          message: "Successfully fetched",
        });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async all_accounts(req, res) {
    try {
      let customerNumber = req.user.customerNumber;

      if (!customerNumber) {
        //customerNumber is null during signup process

        let customerInfo = await CustomerInfo.findOne({
          where: { id: req.user.id },
        });

        customerNumber = customerInfo.customerNumber;
      }

      let response = await CBA_Service.allAccountBalances(customerNumber);

      if (response.status) {
        await Bank_Account_Service.syncBankAccounts(req.user, response.data);

        return res.status(200).send({
          error: false,
          result: response.data,
          message: "Successfully fetched",
        });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async recent_transactions(req, res) {
    try {
      console.log("req.query", req.query);

      let response = await CBA_Service.recentTransactions(
        req.query.account_number,
        req.user.companyCode,
        req.query.start_date,
        req.query.end_date
      );

      if (response.status) {
        return res.status(200).send({
          error: false,
          result: response.data,
          message: "Successfully fetched",
        });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_local_bank_beneficiary(req, res) {
    try {
      let existingBeneficiary = await Beneficiary.findOne({
        where: {
          [Op.and]: [
            { accountnumber: req.body.account_number },
            { user: req.user.coreId },
          ],
        },
      });

      if (existingBeneficiary) {
        return res
          .status(200)
          .send({ error: true, message: "Beneficiary already exists" });
      } else {
        let localBank = await Bank.findOne({
          where: { code: "070001" },
        });

        let response = await Beneficiary.create({
          user: req.user.coreId,
          accountnumber: req.body.account_number,
          accountname: req.body.account_name,
          bank: localBank.id,
        });

        if (response) {
          return res.status(200).send({ error: false, message: "Created" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Creation failed" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_inter_bank_beneficiary(req, res) {
    try {
      let existingBeneficiary = await Beneficiary.findOne({
        where: {
          [Op.and]: [
            { accountnumber: req.body.account_number },
            { user: req.user.coreId },
          ],
        },
      });

      if (existingBeneficiary) {
        return res
          .status(200)
          .send({ error: true, message: "Beneficiary already exists" });
      } else {
        let localBank = await Bank.findOne({
          where: { code: req.body.bank_code },
        });

        let response = await Beneficiary.create({
          user: req.user.coreId,
          accountnumber: req.body.account_number,
          accountname: req.body.account_name,
          bank: localBank.id,
        });

        if (response) {
          return res.status(200).send({ error: false, message: "Created" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Creation failed" });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_local_bank_beneficiaries(req, res) {
    try {
      let response = await Beneficiary.findAll({
        raw: true,
        where: { user: req.user.coreId },
        attributes: [
          "accountnumber",
          "accountname",
          [Sequelize.col('"Bank.code"'), "bankcode"],
          [Sequelize.col('"Bank.name"'), "bankname"],
        ],
        include: [
          {
            model: Bank,
            where: { code: "070001" },
            attributes: [],
          },
        ],
      });

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Beneficiaries not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_inter_bank_beneficiaries(req, res) {
    try {
      let response = await Beneficiary.findAll({
        raw: true,
        where: { user: req.user.coreId },
        attributes: [
          "accountnumber",
          "accountname",
          [Sequelize.col('"Bank.code"'), "bankcode"],
          [Sequelize.col('"Bank.name"'), "bankname"],
        ],
        include: [
          {
            model: Bank,
            where: { code: { [Op.not]: "070001" } },
            attributes: [],
          },
        ],
      });

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Beneficiaries not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_all_beneficiaries(req, res) {
    try {
      let response = await Beneficiary.findAll({
        raw: true,
        where: { user: req.user.coreId },
        attributes: [
          "accountnumber",
          "accountname",
          [Sequelize.col('"Bank.code"'), "bankcode"],
          [Sequelize.col('"Bank.name"'), "bankname"],
        ],
        include: [
          {
            model: Bank,
            attributes: [],
          },
        ],
      });

      if (response) {
        return res.status(200).send({ error: false, result: response });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Beneficiaries not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async receipt(req, res) {
    try {
      // console.log("req.query", req.query);

      let transferRequest = await FundsTransferRequest.findOne({
        // raw: true,
        where: { t24Reference: req.query.transaction_ref },
        include: [{ model: BankAccount }],
      });

      if (transferRequest) {
        // console.log("transferRequest", transferRequest);

        var $ = require("cheerio").load(
          require("fs").readFileSync("./src/template-html/receipt.html", "utf8")
        );

        $("#transaction_date").text(
          dayjs(transferRequest.updatedAt).format("YYYY-MM-DD")
        );

        $("#reference_number").text(transferRequest.t24Reference);

        if (transferRequest.BankAccount) {
          $("#sender").text(transferRequest.BankAccount.accountname);
        }

        $("#amount").text("₦" + numeral(transferRequest.amount).format("0,0"));

        $("#amount_in_words").text(
          converter
            .toWords(transferRequest.amount)
            .toLowerCase()
            .split(" ")
            .map((word) => word.charAt(0).toUpperCase() + word.substring(1))
            .join(" ") + " Naira Only"
        );

        $("#type").text(transferRequest.sender);

        $("#receiver").text(transferRequest.targetaccountname);

        $("#receiver_account_number").text(transferRequest.targetaccountnumber);

        if (transferRequest.targetbank === "NPF MFB") {
          $("#receiver_bank").text(transferRequest.targetbank);
        } else {
          let bank = bank_codes.find(
            (item) => item.code === transferRequest.targetbank
          );
          $("#receiver_bank").text(bank.name);
        }

        $("#narrative").text(transferRequest.remark);

        const browser = await puppeteer.launch({
          args: ["--no-sandbox", "--disable-setuid-sandbox"],
          headless: true,
        });

        // const browser = await puppeteer.launch({
        //   headless: true,
        //   executablePath: '/usr/bin/chromium-browser'
        // });

        // const browser = await puppeteer.launch({
        //   headless: true,
        //   args: ["--no-sandbox", "--disable-setuid-sandbox"],
        // });

        const page = await browser.newPage();
        await page.setContent($.html());

        const buffer = await page.pdf({
          path: "Receipt for Transfer.pdf",
          format: "A4",
          printBackground: true,
          margin: {
            left: "0px",
            top: "0px",
            right: "10px",
            bottom: "0px",
          },
        });

        await browser.close();

        res.setHeader("Content-Type", "application/pdf");
        res.setHeader("Content-Length", buffer.byteLength);
        res.setHeader("Content-Description", "File Transfer");
        res.setHeader("Content-Transfer-Encoding", "binary");

        res.send(buffer);
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Receipt not available" });
      }
    } catch (error) {
      logger.error("error: " + error);

      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
