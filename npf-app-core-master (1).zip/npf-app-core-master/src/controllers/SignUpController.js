const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;

const logger = require("../utils").logger;

var dayjs = require("dayjs");

const NIBSS_Service = require("../services/NIBSS_Service");
const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");
const CBA_Service = require("../services/CBA_Service");
const CustomerData_Service = require("../services/CustomerData_Service");
const Azure_Service = require("../services/Azure_Service");

module.exports = {
  /**
   * Routes different types of search for the model
   * @param {*} req
   * @param {*} res
   */

  async fetch_by_BVN(req, res, next) {
    try {
      let payload = req.body;

      console.log("payload", payload);

      let existingCustomer = await CustomerInfo.findOne({
        where: { bvnhash: payload.bvn.toString() },
      });

      console.log("existingCustomer", existingCustomer && true);

      if (existingCustomer) {
        // console.log("111");

        if (existingCustomer.signup_incomplete) {
          if (
            dayjs(existingCustomer.dob).isSame(
              dayjs(payload.date_of_birth),
              "day"
            )
          ) {
            // console.log("22222");
            SMS_Service.sendOTP(existingCustomer.phone);

            return res
              .status(200)
              .send({ error: false, message: "Token sent" });
          } else {
            // console.log("3333");
            return res
              .status(200)
              .send({ error: true, message: "Incorrect data" });
          }
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Customer previously registered" });
        }
      } else {
        let response = await NIBSS_Service.getBVN(payload.bvn);

        // console.log("response", response);

        if (response.status) {
          if (
            dayjs(response.data.date_of_birth).isSame(
              dayjs(payload.date_of_birth)
            )
          ) {
            let customerInfo = await CustomerData_Service.createCustomer(
              response.data,
              "bvn"
            );

            SMS_Service.sendOTP(customerInfo.phone);

            return res
              .status(200)
              .send({ error: false, message: "Token sent" });
          } else {
            return res
              .status(200)
              .send({ error: true, message: "Invalid Data" });
          }
        } else {
          return res
            .status(200)
            .send({ error: true, message: response.message });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async fetch_by_bank_account(req, res, next) {
    try {
      let payload = req.body;

      console.log("payload", payload);

      let existingAccount = await BankAccount.findOne({
        where: { accountnumber: payload.account },
        include: [{ model: CustomerUser, include: [{ model: CustomerInfo }] }],
      });

      console.log("existingAccount", existingAccount && true);

      if (existingAccount) {
        if (existingAccount.CustomerUser.CustomerInfos[0].signup_incomplete) {
          SMS_Service.sendOTP(existingAccount.CustomerUser.username);

          return res
            .status(200)
            .send({ error: false, message: "Account found, token sent" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Customer previously registered" });
        }
      } else {
        let response = await CBA_Service.getCoreAccountDetails(payload.account);

        console.log("response", response);

        if (response.status) {
          let customer = await CustomerData_Service.createCustomer(
            { ...response.data, date_of_birth: payload.date_of_birth },
            "bank"
          );

          await BankAccount.create({
            accountnumber: payload.account,
            accountname: response.data.accountName,
            address: "",
            type: "",
            balance: response.data.balance,
            CompanyCode: response.data.companyCode,
            user: customer.user, //TODO
          });

          SMS_Service.sendOTP(customer.phone);

          return res.status(200).send({
            error: false,
            message: "Token sent",
            result: { bvn: customer.bvnhash },
          });
        } else {
          return res
            .status(200)
            .send({ error: true, message: response.message });
        }
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async fetch_by_phone(req, res, next) {
    try {
      let payload = req.body;

      console.log("payload", payload);

      let existingCustomer = await CustomerInfo.findOne({
        where: { phone: payload.phone },
      });

      if (existingCustomer) {
        if (existingCustomer.signup_incomplete) {
          SMS_Service.sendOTP(existingCustomer.phone);

          return res.status(200).send({ error: false, message: "Token sent" });
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Customer previously registered" });
        }
      } else {
        let customerInfo = await CustomerData_Service.createCustomer(
          {
            phone: payload.phone,
            firstname: "",
            lastname: "",
            date_of_birth: payload.date_of_birth,
          },
          "phone"
        );

        SMS_Service.sendOTP(customerInfo.phone);

        return res.status(200).send({ error: false, message: "Token sent" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async verify_phone_by_bvn(req, res, next) {
    try {
      let payload = req.body;

      // console.log('payload', payload)
      // console.log('req.user', req.user)

      let customer = await CustomerInfo.findOne({
        where: { bvnhash: payload.bvn },
        include: [{ model: CustomerUser }],
      });

      if (
        customer &&
        // payload.code === "123456" ||
        customer.CustomerUser.otp === payload.code
      ) {
        let tokenExpired = await CustomerData_Service.isTokenExpired(
          customer.CustomerUser.temptokencreatedon
        );

        if (tokenExpired) {
          return res
            .status(403)
            .send({ error: true, message: "Token Expired" });
        }

        await CustomerInfo.update(
          { isotpverified: true },
          { where: { id: customer.id } }
        );

        res.locals.customer = customer;

        return next();
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Verification failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async verify_phone_by_account(req, res, next) {
    try {
      let payload = req.body;

      // console.log('req.user', req.user)

      let account = await BankAccount.findOne({
        where: { accountnumber: payload.account },
        include: [{ model: CustomerUser, include: [{ model: CustomerInfo }] }],
      });

      if (account && account.CustomerUser.otp === payload.code) {
        let tokenExpired = await CustomerData_Service.isTokenExpired(
          account.CustomerUser.temptokencreatedon
        ); 

        if (tokenExpired) {
          return res
            .status(403)
            .send({ error: true, message: "Token Expired" });
        }

        await CustomerInfo.update(
          { isotpverified: true },
          { where: { id: account.CustomerUser.CustomerInfos[0].id } }
        );

        res.locals.customer = account.CustomerUser.CustomerInfos[0];

        return next();
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Verification failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async verify_phone(req, res, next) {
    try {
      let payload = req.body;

      // console.log('payload', payload)

      let customer = await CustomerInfo.findOne({
        where: { phone: payload.phone },
        include: [{ model: CustomerUser }],
      });

      if (customer && customer.CustomerUser.otp === payload.code) {
        let tokenExpired = await CustomerData_Service.isTokenExpired(
          customer.CustomerUser.temptokencreatedon
        );

        if (tokenExpired) {
          return res
            .status(403)
            .send({ error: true, message: "Token Expired" });
        }

        await CustomerInfo.update(
          { isotpverified: true },
          { where: { id: customer.id } }
        );

        res.locals.customer = customer;

        return next();
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Verification failed" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async update_account(req, res) {
    try {
      // console.log("req.body", req.body);
      // console.log('req.user', req.user)

      let payload = req.body;

      let inputs = {
        firstname: req.user.firstname || payload.firstname,
        middlename: req.user.middlename || payload.middlename,
        lastname: req.user.lastname || payload.lastname,
        email: req.user.email || payload.email,
        date_of_birth: req.user.date_of_birth
          ? dayjs(req.user.date_of_birth).format("YYYY-MM-DD")
          : payload.date_of_birth,
        password: payload.password,
        gender: payload.gender.toUpperCase(),
        address: payload.address,
        sector_id: payload.sector_id,
        salary_officer: payload.salary_officer,
        force_number: payload.force_number,
        ippis_number: payload.ippis_number,
      };

      let customer = await CustomerInfo.findOne({
        where: { id: req.user.id },
      });

      if (customer.signup_incomplete) {
        await CustomerData_Service.updatePassword(
          customer.user,
          payload.password
        );

        await CustomerInfo.update(inputs, { where: { id: req.user.id } });

        return res.status(200).send({ error: false, message: "Data updated" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Customer previously registered" });
      }
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_photo(req, res) {
    try {
      await Azure_Service.uploadCustomerPhoto(req.user.id, req.file);

      await CustomerData_Service.profile_completion(req.user.id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_video(req, res) {
    try {
      await Azure_Service.uploadCustomerVideo(req.user.id, req.file);

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_signature(req, res) {
    try {
      await Azure_Service.uploadCustomerSignature(req.user.id, req.file);

      await CustomerData_Service.profile_completion(req.user.id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async create_document(req, res) {
    try {
      let payload = req.body;
      await Azure_Service.uploadCustomerDocument(
        req.user.id,
        payload.document_type_id,
        payload.document_number,
        payload.document_issue_date,
        payload.document_expiry_date,
        req.file
      );

      await CustomerData_Service.profile_completion(req.user.id)

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async complete_signup(req, res) {
    try {
      let feedback = await CustomerData_Service.create_inlaks_account(
        req.user.id
      );

      console.log("create_inlaks_account", feedback);

      if (feedback.success) {
        let data = feedback.data;

        // console.log('data.accountnumber', data.accountnumber)

        await Email_Service.accountUpdated(
          data.email,
          data.firstname,
          data.lastname,
          data.accountnumber
        );

        await SMS_Service.accountUpdated(
          data.phone,
          data.firstname,
          data.lastname,
          data.accountnumber
        );

        return res
          .status(200)
          .send({ error: false, message: "Signup completed" });
      } else {
        return res.status(200).send({ error: true, message: feedback.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async get_support_lines(req, res) {
    try {
      let response = {
        "line 1": "+2348011111111",
        "line 2": "+2348022222222",
        "line 3": "+2348033333333",
      };

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async get_doc_types(req, res) {
    try {
      let doc_types = [
        { id: 1, name: "Driver's License" },
        { id: 2, name: "International Passport" },
        { id: 3, name: "National Id Card" },
        { id: 4, name: "Voter's Id" },
      ];

      return res.status(200).send({ error: false, result: doc_types });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async get_sectors(req, res) {
    try {
      let sectors = [
        { id: 1, name: "Police" },
        { id: 2, name: "Paramilitary" },
        { id: 3, name: "Others" },
      ];

      return res.status(200).send({ error: false, result: sectors });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async check_email_exists(req, res) {
    try {
      let response = await CustomerInfo.findOne({
        where: { email: req.params.email },
      });

      if (response) {
        return res.status(200).send({ error: false, message: "Email exists" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Email does not exist" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async check_phone_exists(req, res) {
    try {
      let response = await CustomerInfo.findOne({
        where: { phone: req.params.phone },
      });

      if (response) {
        return res
          .status(200)
          .send({ error: false, message: "Phone number exists" });
      } else {
        return res
          .status(200)
          .send({ error: true, message: "Phone number does not exist" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
