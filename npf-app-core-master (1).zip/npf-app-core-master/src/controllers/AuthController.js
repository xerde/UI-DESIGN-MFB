const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;

const logger = require("../utils").logger;

let jwt = require("jsonwebtoken");

var dayjs = require("dayjs");

const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");

const CustomerData_Service = require("../services/CustomerData_Service");

const generateTempToken = (user) => {
  return jwt.sign(user, process.env.JWT_TEMP_SECRET, {
    expiresIn: 1800, // in seconds - 30 minutes
  });
};

const generateToken = (user) => {
  return jwt.sign(user, process.env.JWT_SECRET, {
    expiresIn: 900, // in seconds - 30 minutes
  });
};

const generateAdminToken = (user) => {
  return jwt.sign(user, process.env.JWT_ADMIN_SECRET, {
    expiresIn: 3600, // in seconds - 1 hours
  });
};

module.exports = {
  async createTempCustomerJWT(req, res) {
    try {
      let user = req.user;

      // console.log('res.locals', res.locals)

      res.status(200).json({
        temp_token: generateTempToken({
          id: res.locals.customer.id,
          firstname: res.locals.customer.firstname,
          lastname: res.locals.customer.lastname,
          middlename: res.locals.customer.middlename,
          phone: res.locals.customer.phone,
          date_of_birth: res.locals.customer.dob,
          registration_channel: res.locals.customer.registration_channel,
          roles: ["CUSTOMER"],
        }),
        message: "OTP confirmed",
        data: {
          firstname: res.locals.customer.firstname,
          lastname: res.locals.customer.lastname,
          middlename: res.locals.customer.middlename,
          phone: res.locals.customer.phone,
          date_of_birth: res.locals.customer.dob,
          registration_channel: res.locals.customer.registration_channel,
        },
      });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async createCustomerJWT(req, res) {
    try {
      let user = req.user;

      await Email_Service.login(
        user.CustomerInfos[0].email,
        user.CustomerInfos[0].firstname,
        user.CustomerInfos[0].lastname
      );

      if (user.requirespasswordchange) {
        let tokenExpired = await CustomerData_Service.isTokenExpired(
          user.temptokencreatedon
        );

        if (tokenExpired) {
          return res
            .status(403)
            .send({ error: true, message: "Password Expired" });
        }

        res.status(200).json({
          temp_token: generateTempToken({
            id: user.CustomerInfos[0].id,
            phone: user.CustomerInfos[0].phone,
            customerNumber: user.CustomerInfos[0].customerNumber,
            companyCode: user.CustomerInfos[0].companyCode,
            roles: ["CUSTOMER"],
          }),
          message: "Password change required",
          password_change_required: true,
        });
      } else {
        res.status(200).json({
          token: generateToken({
            id: user.CustomerInfos[0].id,
            coreId: user.id,
            customerNumber: user.CustomerInfos[0].customerNumber,
            companyCode: user.CustomerInfos[0].companyCode,
            email: user.CustomerInfos[0].email,
            firstname: user.CustomerInfos[0].firstname,
            lastname: user.CustomerInfos[0].lastname,
            phone: user.CustomerInfos[0].phone,
            roles: ["CUSTOMER"],
            // bvn: user.CustomerInfos[0].bvnhash,
            // has_pin: user.CustomerInfos[0].has_pin,
            // isotpverified: user.CustomerInfos[0].isotpverified,
            // photo_location: user.CustomerInfos[0].photo_location,
          }),
          message: "Login successful",
          password_change_required: false,
        });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async createAdminJWT(req, res) {
    try {
      let user = req.user;

      // await Email_Service.login(
      //   user.email,
      //   user.firstname,
      //   user.lastname
      // );

      let roles = [];

      if (user.AdminUserRoles) {
        roles = user.AdminUserRoles.map((item) => item.AdminRole.name);
      }

      if (user.requirespasswordchange) {
        res.status(200).json({
          temp_token: generateTempToken({
            id: user.id,
            phone: user.phone,
            firstname: user.firstname,
            lastname: user.lastname,
            roles: roles,
          }),
          message: "Password change required",
          password_change_required: true,
        });
      } else {
        res.status(200).json({
          token: generateAdminToken({
            id: user.id,
            email: user.email,
            firstname: user.firstname,
            lastname: user.lastname,
            roles: roles,
          }),
          message: "Login successful",
          password_change_required: false,
        });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async fetchUserInfo(req, res) {
    try {
      let user = await CustomerInfo.findOne({
        where: { id: req.user.id },
      });

      let userData = {
        id: user.id,
        email: user.email,
        firstname: user.firstname,
        lastname: user.lastname,
        phone: user.phone,
        bvn: user.bvnhash,
        has_pin: user.has_pin,
        isotpverified: user.isotpverified,
        photo_location: user.photo_location,
        customerNumber: user.customerNumber,
        PND: user.PND,
        isnewbankcustomer: user.isnewbankcustomer,
        signup_incomplete: user.signup_incomplete,
        enabled: user.enabled,
        livelinesschecked: user.livelinesschecked,
        documentschecked: user.documentschecked,
        document_location: user.document_location,
        photo_location: user.photo_location,
        video_location: user.video_location,
        photostatus: user.photostatus,
        documentstatus: user.documentstatus,
        signaturestatus: user.signaturestatus,
        profilecomplete: user.profilecomplete,
        last_login_date: user.last_login_date
      };

      return res.status(200).send({ authenticated: true, data: userData });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  role_authorization(approvedRoles) {
    return function (req, res, next) {
      try {
        for (const userRole of req.user.roles) {
          for (const approvedRole of approvedRoles) {
            if (userRole === approvedRole) {
              return next();
            }
          }
        }

        return res.status(403).send({ error: true, message: "Unauthorized" });
      } catch (error) {
        console.log("error", error);
        return res.status(403).send({ error: true, message: "Unauthorized" });
      }
    };
  },

  // async (req, res) {
  //   try {
  //     for (const userRole of req.user.roles) {
  //       for (const approvedRole of approvedRoles) {
  //         if (userRole === approvedRole) {
  //           return next();
  //         }
  //       }
  //     }

  //     return res.status(403).send({ error: true, message: "Access forbidden" });
  //   } catch (error) {
  //     console.log("error", error);
  //     return res.status(403).send({ error: true, message: "Access forbidden" });
  //   }
  // },

  async reset_password(req, res) {
    try {
      let payload = req.body;

      let customerInfo = await CustomerInfo.findOne({
        where: { phone: payload.phone },
      });

      if (customerInfo && payload.pin) {
        let matched = await CustomerData_Service.pinMatched(
          customerInfo.id,
          payload.pin.toString()
        );

        if (matched) {
          let tempPassword = await CustomerData_Service.resetPassword(
            customerInfo.user
          );

          Email_Service.passwordReset(customerInfo, tempPassword);

          SMS_Service.passwordReset(customerInfo);
        } else {
          return res
            .status(200)
            .send({ error: true, message: "Pin match failure" });
        }
      }

      return res.status(200).send({
        error: false,
        message:
          "If account exists, a temporary password will be sent to your registered mailbox",
      });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async update_password(req, res) {
    try {

      let customerInfo = await CustomerInfo.findOne({
        where: { id: req.user.id },
      });

      if (customerInfo) {

        await CustomerData_Service.updatePassword(
          customerInfo.user,
          req.body.password
        );

        return res
          .status(200)
          .send({ error: false, message: "Password updated" });

      } else {
        
        return res
          .status(200)
          .send({ error: true, message: "Account not found" });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
