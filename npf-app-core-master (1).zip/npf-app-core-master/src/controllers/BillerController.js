const CustomerUser = require("../models").CustomerUser;

const logger = require("../utils").logger;

const BillerCategory = require("../models").BillerCategory;
const Biller_Service = require("../services/Biller_Service");
const CBA_Service = require("../services/CBA_Service");
const CustomerData_Service = require("../services/CustomerData_Service");

module.exports = {
  async create_category(req, res) {
    try {
      await BillerCategory.create({
        name: req.body.name,
        description: req.body.description,
      });

      return res
        .status(200)
        .send({ error: false, message: "Action successful" });
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async biller_categories(req, res) {
    try {
      let response = await Biller_Service.getBillerCategories();

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_all_billers(req, res) {
    try {
      let response = await Biller_Service.getAllBillers();

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_services(req, res) {
    try {
      let response = await Biller_Service.getServices(req.query.biller_id);

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_custom_fields(req, res) {
    try {
      let response = await Biller_Service.getCustomFields(req.query.service_id);

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  //TODO: to deprecate
  async required_fields(req, res) {
    try {
      let response = await Biller_Service.getRequiredFields(
        req.query.service_id
      );

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async parse_services(req, res) {
    try {
      let response = await Biller_Service.parse_services(
        req.body.biller_id,
        req.body.biller_name,
        req.body.biller_category_id
      );

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async airtime_options(req, res) {
    try {
      let response = await Biller_Service.getAirtimeOptions();

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async data_billers(req, res) {
    try {
      let response = await Biller_Service.getBillersByCategoryName("Data");

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async view_billers(req, res) {
    try {
      let response = await Biller_Service.getBillersByCategoryId(
        req.query.biller_category_id
      );

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async service_options(req, res) {
    try {
      let response = await Biller_Service.getServiceOptions(
        req.query.biller_id
      );

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async generate_rrr(req, res, next) {
    try {
      // let accountBalance = await CBA_Service.accountBalance(req.body.source_account);

      // if (accountBalance < req.body.amount) {
      //   return res.status(200).send({
      //     error: true,
      //     message: "Insufficient balance to complete transaction",
      //   });
      // }

      let customFields = [];

      if (req.body.field_id && req.body.field_value) {
        customFields.push({
          id: req.body.field_id,
          values: [
            {
              value: req.body.field_value,
            },
          ],
        });
      }

      let { data, message } = await Biller_Service.generate_rrr(
        req.body.service_id,
        req.body.amount,
        req.body.phone,
        req.user.firstname + " " + req.user.lastname,
        req.user.email,
        "NGN",
        customFields
        // req.body.customFields
      );

      console.log("data", data);

      if (data && data.rrr) {
        res.locals.billerPayload = {
          source_account: req.body.source_account,
          rrr: data.rrr,
          pin: req.body.pin,
          amount: data.amountDue,
          narration: req.body.narration,
          destination_account: "0020021911", //TODO: collections acct
        };

        return next();

        // return res.status(200).send({ error: false, result: data });
      } else {
        return res.status(200).send({ error: true, message: message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async fetch_billing_data(req, res) {
    try {
      let customFieldsResponse = await Biller_Service.getCustomFields(
        req.body.service_id
      );

      let customFields = [
        {
          id: req.body.field_id,
          values: [
            {
              value: req.body.field_value,
            },
          ],
        },
      ];

      let lookupFieldsResponse = await Biller_Service.lookup_field(
        req.body.service_id,
        req.body.amount,
        req.body.phone,
        req.user.firstname + " " + req.user.lastname,
        req.user.email,
        "NGN",
        customFields
      );

      // console.log("customFieldsResponse", customFieldsResponse);
      // console.log("lookupFieldsResponse", lookupFieldsResponse);

      let response = [];

      for (const entry of lookupFieldsResponse.data.customFields) {
        let foundItem = customFieldsResponse.data.find(
          (item) => item.id === entry.id
        );

        response.push({ [foundItem.columnName]: entry.values[0].value });
      }

      return res.status(200).send({ error: false, result: response });
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async lookup_field(req, res, next) {
    try {
      let customFields = [
        {
          id: req.body.field_id,
          values: [
            {
              value: req.body.field_value,
            },
          ],
        },
      ];

      let response = await Biller_Service.lookup_field(
        req.body.service_id,
        req.body.amount,
        req.body.phone,
        req.user.firstname + " " + req.user.lastname,
        req.user.email,
        "NGN",
        customFields
      );

      // console.log("data", JSON.stringify(data));

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async process_transaction(req, res, next) {
    try {
      let response = await Biller_Service.process_transaction(
        res.locals.billerPayload.rrr
      );

      // let response = await Biller_Service.process_transaction(req.body.rrr);

      console.log("response", response);

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async transaction_status(req, res) {
    try {
      let response = await Biller_Service.transaction_status(req.query.rrr);

      console.log("response", response);

      if (response.status) {
        return res.status(200).send({ error: false, result: response.data });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async payment_notification(req, res) {
    try {
      console.log("req.body", req.body);

      return res.status(200).send({ error: false });
    } catch (error) {
      logger.error(error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
