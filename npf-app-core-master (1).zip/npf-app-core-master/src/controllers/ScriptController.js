const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;
const Op = require("../models/index").Sequelize.Op;

const logger = require("../utils").logger;

const moment = require("moment");
var dayjs = require("dayjs");

const NIBSS_Service = require("../services/NIBSS_Service");
const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");
const CBA_Service = require("../services/CBA_Service");
const CustomerData_Service = require("../services/CustomerData_Service");
const Azure_Service = require("../services/Azure_Service");

const FundsTransferRequest = require("../models").FundsTransferRequest;

const Bank = require("../models").Bank;

module.exports = {
  async update2(req, res) {
    try {
      let id = req.query.id;

      console.log("id", id);

      let requests = await FundsTransferRequest.findAll();

      // for (const request of requests) {
      //   FundsTransferRequest.update(
      //     { total: parseFloat(request.amount) },
      //     { where: { id: request.id } }
      //   );
      // }

      // for (const request of requests) {
      //   FundsTransferRequest.update(
      //     { amount: request.total },
      //     { where: { id: request.id } }
      //   );
      // }

      return res.status(200).send({ error: false, message: "done" });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async upload_photo(req, res) {
    try {
      await Azure_Service.uploadCustomerPhoto("3", req.file);

      return res
        .status(200)
        .send({ error: false, message: "Upload successful" });
    } catch (error) {
      console.log("error", error);
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async local_transfer_alert(req, res) {
    try {
      SMS_Service.transactionAlert(
        "2348037416455",
        "Debit",
        15,
        9348394,
        "App test"
      );

      return res.status(200).send({ error: false });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async update2(req, res) {
    try {
      let id = req.query.id;

      console.log("id", id);

      let items = await CustomerInfo.findAll();

      for (const item of items) {
        if (item.documentschecked === true) {
          await CustomerInfo.update(
            { documentstatus: "APPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.document_location === null) {
          await CustomerInfo.update(
            { documentstatus: "PENDING" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.document_location !== null) {
          await CustomerInfo.update(
            { documentstatus: "APPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.photo_location === null) {
          await CustomerInfo.update(
            { photostatus: "PENDING" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.photo_location !== null) {
          await CustomerInfo.update(
            { photostatus: "APPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.signature_location === null) {
          await CustomerInfo.update(
            { signaturestatus: "PENDING" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.signature_location !== null) {
          await CustomerInfo.update(
            { signaturestatus: "APPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        await CustomerData_Service.profile_completion(item.id);
      }

      return res.status(200).send({ error: false, message: "done" });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async update(req, res) {
    try {
      let id = req.query.id;

      console.log("id", id);

      let items = await CustomerInfo.findAll();

      for (const item of items) {
        if (item.profilecomplete === "true") {
          await CustomerInfo.update(
            { profilecomplete: "APPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.profilecomplete === "false") {
          await CustomerInfo.update(
            { profilecomplete: "DISAPPROVED" },
            {
              where: { id: item.id },
            }
          );
        }

        if (item.profilecomplete === null) {
          await CustomerInfo.update(
            { profilecomplete: "PENDING" },
            {
              where: { id: item.id },
            }
          );
        }

        // await CustomerData_Service.profile_completion(item.id);
      }

      return res.status(200).send({ error: false, message: "done" });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async batchCreateBanks(req, res) {
    try {
      const bank_codes = require("../constants/bank-codes");

      for (const bank of bank_codes) {
        await Bank.create({
          code: bank.code,
          name: bank.name,
        });
      }

      return res.status(200).send({ error: false, message: "done" });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
