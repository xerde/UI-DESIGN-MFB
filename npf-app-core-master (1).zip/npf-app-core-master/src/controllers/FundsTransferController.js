const logger = require("../utils").logger;

const NIBSS_Service = require("../services/NIBSS_Service");
const SMS_Service = require("../services/SMS_Service");
const Email_Service = require("../services/Email_Service");
const CBA_Service = require("../services/CBA_Service");
const Util_Service = require("../services/Util_Service");

var dayjs = require("dayjs");
const CustomerData_Service = require("../services/CustomerData_Service");

const Bank_Account_Service = require("../services/Bank_Account_Service");
const FundsTransferRequest = require("../models").FundsTransferRequest;
const BankAccount = require("../models").BankAccount;
const Bank = require("../models").Bank;

const { v4: uuidv4 } = require("uuid");

const Op = require("../models/index").Sequelize.Op;

module.exports = {
  async inter_bank_query(req, res) {
    try {
      let payload = req.body;

      // console.log("payload", payload);

      let bankAccount = await BankAccount.findOne({
        where: {
          [Op.and]: [
            { accountnumber: payload.source_account },
            { user: req.user.coreId },
          ],
        },
      });

      if (!bankAccount) {
        return res.status(403).send({ error: true, message: "Unauthorized" });
      }

      let response = await CBA_Service.interbankNameEnquiry(
        payload.source_account,
        payload.destination_institution_code,
        payload.destination_account
      );

      console.log("response", response);

      if (response.status) {
        let transfer = await FundsTransferRequest.create({
          status: "INITIATED",
          transfer_type: "inter_bank",
          sourceaccount: bankAccount.id,
          targetaccountnumber: response.data.receiverAccountNo,
          targetaccountname: response.data.receiverName,
          targetbank: response.data.destinationInstitutionCode,
          nameEnquiryRef: response.data.nameEnquiryRef,
          receiverBVN: response.data.receiverBVN,
          receiverAccountNo: response.data.receiverAccountNo,
          responseObject: JSON.stringify(response.data),
        });

        return res.status(200).send({
          error: false,
          result: {
            transaction_ref: transfer.nameEnquiryRef,
            receiver_name: transfer.targetaccountname,
          },
        });
      } else {
        return res.status(200).send({ error: true, message: response.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async inter_bank(req, res) {
    try {
      let payload = req.body;

      // console.log("payload", payload);

      let matched = await CustomerData_Service.pinMatched(
        req.user.id,
        payload.pin
      );

      if (!matched) {
        return res
          .status(200)
          .send({ error: true, message: "Pin match failure" });
      }

      let limitFeedback = await Bank_Account_Service.checkForDailyTransactionLimit(
        req.user.coreId,
        payload.amount
      );

      console.log("limitFeedback", limitFeedback);

      if (limitFeedback.limitExceeded) {
        return res.status(200).send({
          error: true,
          message: `Transaction of ₦${payload.amount} will exceed your daily limit of ₦${limitFeedback.limit}`,
        });
      }

      let transferRequest = await FundsTransferRequest.findOne({
        where: { nameEnquiryRef: payload.transaction_ref },
        include: [{ model: BankAccount }],
      });

      if (transferRequest) {
        let reference = dayjs().format("[USSD]YYMMDDHHmmss4SSS");

        //save the amount in transfer object
        transferRequest.amount = payload.amount;
        transferRequest.remark = payload.narration;
        await transferRequest.save();

        let transferObject = JSON.parse(transferRequest.responseObject);

        let feedback = await CBA_Service.interbankTransfer({
          ...transferObject,
          TransactionAmount: payload.amount,
          Narration: encodeURI(payload.narration),
          ReferenceNo: reference,
        });

        console.log("feedback", feedback);

        if (feedback.status) {
          transferRequest.t24Reference = feedback.data.t24Reference;
          transferRequest.messageReference = feedback.data.messageReference;
          transferRequest.status = "COMPLETED";

          await transferRequest.save();

          let accountBalance = await CBA_Service.accountBalance(
            transferRequest.BankAccount.accountnumber
          );

          await Email_Service.transactionAlert(
            req.user.email,
            req.user.firstname,
            req.user.lastname,
            "DEBIT",
            payload.amount,
            Util_Service.maskAccount(transferObject.senderAccountNo),
            payload.narration,
            transferRequest.targetaccountname,
            transferRequest.targetaccountnumber,
            accountBalance.data.balance
          );

          await SMS_Service.transactionAlert(
            req.user.phone,
            "DEBIT",
            payload.amount,
            Util_Service.maskAccount(transferObject.senderAccountNo),
            payload.narration,
            accountBalance.data.balance
          );

          return res.status(200).send({
            error: false,
            result: feedback.data,
            message: "Transfer request successfully sent",
          });
        } else {
          return res
            .status(200)
            .send({ error: true, message: feedback.message });
        }
      } else {
        return res.status(200).send({
          error: true,
          message: "Transfer reference not found, restart transfer",
        });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async local_transfer_query(req, res) {
    try {
      let payload = req.body;

      // console.log("payload", payload);

      let feedback = await CBA_Service.getCoreAccountDetails(
        payload.destination_account
      );

      console.log("feedback", feedback);

      if (feedback.status) {
        // await FundsTransferRequest.create({
        //   status: "INITIATED",
        //   transfer_type: "local_transfer",
        //   targetaccountnumber: payload.destination_account,
        //   targetaccountname: feedback.data.accountName,
        //   targetbank: "NPF MFB",
        //   nameEnquiryRef: uuidv4(),
        // });

        return res.status(200).send({
          error: false,
          result: {
            receiver_name: feedback.data.accountName,
          },
        });
      } else {
        return res.status(200).send({ error: true, message: feedback.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async local_transfer(req, res, next) {
    try {
      let billerPayload = res.locals.billerPayload;

      let payload = null;
      let transaction_ref = null;

      if (billerPayload) {
        payload = billerPayload;
        transaction_ref = payload.rrr;
      } else {
        payload = req.body;
        transaction_ref = uuidv4();
      }

      // console.log("payload", payload);

      let matched = await CustomerData_Service.pinMatched(
        req.user.id,
        payload.pin
      );

      if (!matched) {
        return res
          .status(200)
          .send({ error: true, message: "Pin match failure" });
      }

      let bankAccount = await BankAccount.findOne({
        where: {
          [Op.and]: [
            { accountnumber: payload.source_account },
            { user: req.user.coreId },
          ],
        },
      });

      if (!bankAccount) {
        return res.status(403).send({ error: true, message: "Unauthorized" });
      }

      let limitFeedback = await Bank_Account_Service.checkForDailyTransactionLimit(
        req.user.coreId,
        payload.amount
      );

      console.log("limitFeedback", limitFeedback);

      if (limitFeedback.limitExceeded) {
        return res.status(200).send({
          error: true,
          message: `Transaction of ₦${payload.amount} will exceed your daily limit of ₦${limitFeedback.limit}`,
        });
      }

      ////////////////////
      let destLookup = await CBA_Service.getCoreAccountDetails(
        payload.destination_account
      );

      if (destLookup.status) {
        await FundsTransferRequest.create({
          sourceaccount: bankAccount.id,
          status: "INITIATED",
          transfer_type: "local_transfer",
          amount: payload.amount,
          remark: payload.narration,
          source_account: payload.source_account,
          targetaccountnumber: payload.destination_account,
          targetaccountname: destLookup.data.accountName,
          targetbank: "NPF MFB",
          nameEnquiryRef: transaction_ref,
          responseObject: "", //not nullable
        });
      } else {
        return res
          .status(200)
          .send({ error: true, message: destLookup.message });
      }
      /////////////////////

      let reference = dayjs().format("[USSD]YYMMDDHHmmss4SSS");

      let feedback = await CBA_Service.localTranfer({
        DebitAccountNumber: payload.source_account,
        CreditAccountNumber: payload.destination_account,
        Amount: payload.amount,
        Narration: encodeURI(payload.narration),
        ReferenceNo: reference,
        CompanyCode: "NG0020001",
      });

      console.log("feedback", feedback);

      if (feedback.status) {
        let transferRequest = await FundsTransferRequest.findOne({
          where: { nameEnquiryRef: transaction_ref },
          include: [{ model: BankAccount }],
        });

        if (transferRequest) {
          transferRequest.status = "COMPLETED";
          transferRequest.t24Reference = feedback.data.t24Reference;
          transferRequest.messageReference = feedback.data.messageReference;
          transferRequest.responseObject = JSON.stringify(feedback.data);

          await transferRequest.save();
        }

        let accountBalance = await CBA_Service.accountBalance(
          transferRequest.BankAccount.accountnumber
        );

        await Email_Service.transactionAlert(
          req.user.email,
          req.user.firstname,
          req.user.lastname,
          "DEBIT",
          payload.amount,
          Util_Service.maskAccount(payload.source_account),
          payload.narration,
          transferRequest.targetaccountname,
          transferRequest.targetaccountnumber,
          accountBalance.data.balance
        );

        await SMS_Service.transactionAlert(
          req.user.phone,
          "DEBIT",
          payload.amount,
          Util_Service.maskAccount(payload.source_account),
          payload.narration,
          accountBalance.data.balance
        );

        if (billerPayload) {
          return next();
        } else {
          return res.status(200).send({
            error: false,
            result: feedback.data,
            message: "Transfer request successfully sent",
          });
        }
      } else {
        return res.status(200).send({ error: true, message: feedback.message });
      }
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },

  async get_banks(req, res) {
    try {
      let banks = await Bank.findAll({
        attributes: ["name", "code"],
      });
      return res.status(200).send({ error: false, result: banks });
    } catch (error) {
      logger.error("error: " + error);
      return res
        .status(500)
        .send({ error: true, message: "Your action could not be completed." });
    }
  },
};
