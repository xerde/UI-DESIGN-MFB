"use strict";

module.exports = function (sequelize, DataTypes) {
  var Beneficiary = sequelize.define(
    "Beneficiary",
    {
      accountnumber: { type: DataTypes.STRING, allowNull: false },
      accountname: { type: DataTypes.STRING, allowNull: false },
      // bankcode: { type: DataTypes.STRING, allowNull: true },
      // upgratargetbankdetosalary: { type: DataTypes.STRING, allowNull: true },
    },
    {
      timestamps: true,
      tableName: "Beneficiaries",
    }
  );
  Beneficiary.associate = function (models) {
    Beneficiary.belongsTo(models.CustomerUser, {
      foreignKey: "user",
    });
    Beneficiary.belongsTo(models.Bank, {
      foreignKey: "bank",
    });
    Beneficiary.hasMany(models.FundsTransferRequest, {
      foreignKey: "beneficiary",
    });
  };
  return Beneficiary;
};
