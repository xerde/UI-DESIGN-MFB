"use strict";

module.exports = function (sequelize, DataTypes) {
  var LoginAttempt = sequelize.define(
    "LoginAttempt",
    {
      customerId: { type: DataTypes.STRING },
      success: { type: DataTypes.BOOLEAN },
      ipAddress: { type: DataTypes.STRING },
    },
    {
      timestamps: true,
      tableName: "LoginAttempt",
    }
  );

  return LoginAttempt;
};
