"use strict";

module.exports = function (sequelize, DataTypes) {
  var PasswordChangeHistory = sequelize.define(
    "PasswordChangeHistory",
    {
      markedforpasswordchangeon: { type: DataTypes.DATE, allowNull: false },
    },
    {
      timestamps: true,
      tableName: "PasswordChangeHistories",
    }
  );
  PasswordChangeHistory.associate = function (models) {
    PasswordChangeHistory.belongsTo(models.CustomerUser, {
      foreignKey: "user",
    });
    PasswordChangeHistory.belongsTo(models.AdminUser, {
      foreignKey: "markedby",
    });
  };
  return PasswordChangeHistory;
};
