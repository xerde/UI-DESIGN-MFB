"use strict";

module.exports = function(sequelize, DataTypes) {
    var SupportMessage = sequelize.define("SupportMessage",
        {
            subject: { type: DataTypes.STRING, allowNull: false },
            message: { type: DataTypes.STRING, allowNull: false },
            ticketid: { type: DataTypes.STRING, allowNull: false },
            ticketstatus: { type: DataTypes.STRING, allowNull: false },
            tickettype: { type: DataTypes.STRING, allowNull: false },
        },
        {
            timestamps: true,
            tableName: 'SupportMessages'
        }
    );
    SupportMessage.associate = function(models) { 
        SupportMessage.belongsTo(
            models.CustomerUser,
            {
                foreignKey: 'user'
            }
        );
        SupportMessage.belongsTo(
            models.AdminUser,
            {
                foreignKey: 'resolvedby'
            }
        );
    };
    return SupportMessage;
};

