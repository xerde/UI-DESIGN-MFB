"use strict";

module.exports = function (sequelize, DataTypes) {
  var FundsTransferRequest = sequelize.define(
    "FundsTransferRequest",
    {
      status: { type: DataTypes.STRING },
      targetaccountnumber: { type: DataTypes.STRING, allowNull: false },
      targetaccountname: { type: DataTypes.STRING, allowNull: true },
      targetbank: { type: DataTypes.STRING, allowNull: true },

      // amount: { type: DataTypes.STRING, allowNull: true },
      
      amount: { type: DataTypes.DECIMAL(10,2), allowNull: true },

      // total: { type: DataTypes.DECIMAL(10,2), allowNull: true },

      remark: { type: DataTypes.STRING, allowNull: true },

      nameEnquiryRef: { type: DataTypes.STRING, allowNull: true },
      receiverBVN: { type: DataTypes.STRING, allowNull: true },
      receiverAccountNo: { type: DataTypes.STRING, allowNull: true },
      t24Reference: { type: DataTypes.STRING, allowNull: true },
      messageReference: { type: DataTypes.STRING, allowNull: true },
      transfer_type: { type: DataTypes.STRING, allowNull: true },

      responseObject: { type: DataTypes.STRING(4000), allowNull: false },
    },
    {
      timestamps: true,
      tableName: "FundsTransferRequests",
    }
  );
  FundsTransferRequest.associate = function (models) {
    FundsTransferRequest.belongsTo(models.BankAccount, {
      foreignKey: "sourceaccount",
    });
    FundsTransferRequest.belongsTo(models.Beneficiary, {
      foreignKey: "beneficiary",
    });
  };
  return FundsTransferRequest;
};
