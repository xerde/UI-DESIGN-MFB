"use strict";

var fs = require("fs");
var path = require("path");
var Sequelize = require("sequelize");
var basename = path.basename(module.filename);
var db = {};

var sequelize = new Sequelize(
  process.env.SQL_DB,
  process.env.SQL_USER,
  process.env.SQL_PASSWORD,
  {
    host: process.env.SQL_HOST,
    port: process.env.SQL_PORT,
    //dialect: process.env.SQL_DIALECT
    dialect: 'postgres',
    operatorsAliases: false,
    logging: false,
    ...(process.env.ENV !== "DEVELOPMENT" && {
      dialectOptions: {
        ssl: {
          cert: fs.readFileSync(
            __dirname + "/../config/BaltimoreCyberTrustRoot.crt.pem"
          ),
        },
      },
    }),
  }
);

fs.readdirSync(__dirname)
  .filter(function (file) {
    return (
      file.indexOf(".") !== 0 && file !== basename && file.slice(-3) === ".js"
    );
  })
  .forEach(function (file) {
    var model = sequelize["import"](path.join(__dirname, file));
    db[model.name] = model;
  });

Object.keys(db).forEach(function (modelName) {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
