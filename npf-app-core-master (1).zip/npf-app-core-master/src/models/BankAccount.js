"use strict";

module.exports = function (sequelize, DataTypes) {
  var BankAccount = sequelize.define(
    "BankAccount",
    {
      accountnumber: { type: DataTypes.STRING, allowNull: true },
      accountname: { type: DataTypes.STRING, allowNull: true },
      address: { type: DataTypes.STRING, allowNull: true },
      type: { type: DataTypes.STRING, allowNull: true },
      balance: { type: DataTypes.DECIMAL(10, 2), allowNull: true },
      bookBalance: { type: DataTypes.DECIMAL(10, 2), allowNull: true },
      companyCode: { type: DataTypes.STRING, allowNull: true },
    },
    {
      timestamps: true,
      tableName: "BankAccounts",
    }
  );
  BankAccount.associate = function (models) {
    BankAccount.belongsTo(models.CustomerUser, {
      foreignKey: "user",
    });
    BankAccount.hasMany(models.FundsTransferRequest, {
      foreignKey: "sourceaccount",
    });
  };
  return BankAccount;
};
