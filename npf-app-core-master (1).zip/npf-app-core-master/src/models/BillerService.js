"use strict";

module.exports = function (sequelize, DataTypes) {
  var BillerService = sequelize.define(
    "BillerService",
    {
      serviceId: { type: DataTypes.STRING },
      description: { type: DataTypes.STRING },
      amount: { type: DataTypes.DECIMAL(10,2)},
    },
    {
      timestamps: true,
      tableName: "BillerService",
    }
  );

  BillerService.associate = function (models) {
    BillerService.belongsTo(models.Biller, {
      foreignKey: "billerId",
    });
  };

  return BillerService;
};
