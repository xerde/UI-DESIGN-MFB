"use strict";

module.exports = function (sequelize, DataTypes) {
  var Biller = sequelize.define(
    "Biller",
    {
      billerName: { type: DataTypes.STRING },
      billerId: { type: DataTypes.STRING },
    },
    {
      timestamps: true,
      tableName: "Biller",
    }
  );

  Biller.associate = function (models) {
    Biller.hasMany(models.BillerService, {
      foreignKey: "billerId",
    });
  };

  Biller.associate = function (models) {
    Biller.belongsTo(models.BillerCategory, {
      foreignKey: "billerCategoryId",
    });
  };

  return Biller;
};
