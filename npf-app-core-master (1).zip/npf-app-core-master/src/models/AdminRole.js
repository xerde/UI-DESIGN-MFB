"use strict";

module.exports = function (sequelize, DataTypes) {
  var AdminRole = sequelize.define(
    "AdminRole",
    {
      name: { type: DataTypes.STRING, allowNull: false },
    },
    {
      timestamps: true,
      tableName: "AdminRoles",
    }
  );
  AdminRole.associate = function (models) {
    AdminRole.hasMany(models.AdminUserRole, {
      foreignKey: "role",
    });
  };
  return AdminRole;
};
