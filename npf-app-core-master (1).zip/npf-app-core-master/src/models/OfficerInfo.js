"use strict";

module.exports = function(sequelize, DataTypes) {
    var OfficerInfo = sequelize.define("OfficerInfo",
        {
            officernumber: { type: DataTypes.STRING, allowNull: false },
            officertype: { type: DataTypes.STRING, allowNull: false },
            upgradetosalary: { type: DataTypes.BOOLEAN, allowNull: true },
        },
        {
            timestamps: true,
            tableName: 'OfficerInfos'
        }
    );
    OfficerInfo.associate = function(models) { 
        OfficerInfo.belongsTo(
            models.CustomerInfo,
            {
                foreignKey: 'customerInfoId'
            }
        );
    };
    return OfficerInfo;
};

