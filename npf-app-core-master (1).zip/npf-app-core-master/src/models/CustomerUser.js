"use strict";

let bcrypt = require("bcryptjs");
// let salt = bcrypt.genSaltSync(10);

module.exports = function (sequelize, DataTypes) {
  var CustomerUser = sequelize.define(
    "CustomerUser",
    {
      username: { type: DataTypes.STRING, allowNull: false },
      password: { type: DataTypes.STRING, allowNull: true },
      passwordlastchangedon: { type: DataTypes.DATE, allowNull: true },
      transactionpin: { type: DataTypes.STRING, allowNull: true },
      transactionpinchangedon: { type: DataTypes.DATE, allowNull: true },
      requirespasswordchange: { type: DataTypes.BOOLEAN, allowNull: true },
      otp: { type: DataTypes.STRING, allowNull: true },
      locked: { type: DataTypes.BOOLEAN, allowNull: true },
      lockedon: { type: DataTypes.DATE, allowNull: true },
      temptokencreatedon: { type: DataTypes.DATE, allowNull: true },
    },
    {
      timestamps: true,
      tableName: "CustomerUsers",
    }
  );
  CustomerUser.associate = function (models) {
    CustomerUser.hasMany(models.CustomerInfo, {
      foreignKey: "user",
    });
    CustomerUser.hasMany(models.BankAccount, {
      foreignKey: "user",
    });
    CustomerUser.hasMany(models.SupportMessage, {
      foreignKey: "user",
    });
    CustomerUser.hasMany(models.Beneficiary, {
      foreignKey: "user",
    });
    CustomerUser.hasMany(models.PasswordChangeHistory, {
      foreignKey: "user",
    });
  };

  CustomerUser.prototype.comparePassword = function (passwordAttempt) {
    try {
      const isMatch = bcrypt.compareSync(passwordAttempt, this.password);
  
      return isMatch;
    } catch (error) {
      console.log("error", error);
    }
  };

  //   CustomerUser.beforeCreate((user, options) => {
  //     var hashedPw = bcrypt.hashSync(user.tempPassword, salt);
  //     user.password = hashedPw;
  //   });

  //   CustomerUser.prototype.comparePassword = function (passwordAttempt) {
  //     try {
  //       const isMatch = bcrypt.compareSync(passwordAttempt, this.password);

  //       return isMatch;
  //     } catch (error) {
  //       console.log("error", error);
  //     }
  //   };

  return CustomerUser;
};
