"use strict";

module.exports = function(sequelize, DataTypes) {
    var CustomerAuditTrail = sequelize.define("CustomerAuditTrail",
        {
            actor: { type: DataTypes.STRING, allowNull: false },
            actionperformed: { type: DataTypes.STRING, allowNull: false },
            remoteaddress: { type: DataTypes.STRING, allowNull: false },
            requestmethod: { type: DataTypes.STRING, allowNull: false },
            actiontype: { type: DataTypes.STRING, allowNull: false },
            actionref: { type: DataTypes.STRING, allowNull: false },
        },
        {
            timestamps: true,
            tableName: 'CustomerAuditTrails'
        }
    );
    CustomerAuditTrail.associate = function(models) { 
    };
    return CustomerAuditTrail;
};

