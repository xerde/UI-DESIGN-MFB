"use strict";

module.exports = function (sequelize, DataTypes) {
  var Log = sequelize.define(
    "Log",
    {
      customerId: { type: DataTypes.STRING },
      adminId: { type: DataTypes.STRING },
      subjectId: { type: DataTypes.STRING },
      ip: { type: DataTypes.STRING },
      endpoint: { type: DataTypes.STRING },
      requestMethod: { type: DataTypes.STRING },
      requestBody: { type: DataTypes.STRING(4000) },
      requestQuery: { type: DataTypes.STRING(4000) },
      requestParams: { type: DataTypes.STRING(4000) },
      requestHeaders: { type: DataTypes.STRING(4000) },
      responseCode: { type: DataTypes.STRING },
      responseHeaders: { type: DataTypes.STRING(4000) },
      responseBody: { type: DataTypes.STRING(4000) },
    },
    {
      timestamps: true,
      tableName: "Log",
    }
  );

  return Log;
};
