"use strict";

module.exports = function(sequelize, DataTypes) {
    var AdminUserRole = sequelize.define("AdminUserRole",
        {
            name: { type: DataTypes.STRING, allowNull: false },
        },
        {
            timestamps: true,
            tableName: 'AdminUserRoles'
        }
    );
    AdminUserRole.associate = function(models) { 
        AdminUserRole.belongsTo(
            models.AdminRole,
            {
                foreignKey: 'role'
            }
        );
        AdminUserRole.belongsTo(
            models.AdminUser,
            {
                foreignKey: 'user'
            }
        );
    };
    return AdminUserRole;
};

