"use strict";

module.exports = function (sequelize, DataTypes) {
  var BillerCategory = sequelize.define(
    "BillerCategory",
    {
      name: { type: DataTypes.STRING },
      description: { type: DataTypes.STRING },
    },
    {
      timestamps: true,
      tableName: "BillerCategory",
    }
  );

  BillerCategory.associate = function (models) {
    BillerCategory.hasMany(models.Biller, {
      foreignKey: "billerCategoryId",
    });
  };

  return BillerCategory;
};
