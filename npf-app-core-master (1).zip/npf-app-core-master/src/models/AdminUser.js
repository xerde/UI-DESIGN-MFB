"use strict";

let bcrypt = require("bcryptjs");

module.exports = function (sequelize, DataTypes) {
  var AdminUser = sequelize.define(
    "AdminUser",
    {
      username: { type: DataTypes.STRING, allowNull: false },
      password: { type: DataTypes.STRING, allowNull: false },
      firstname: { type: DataTypes.STRING, allowNull: true },
      lastname: { type: DataTypes.STRING, allowNull: true },
      phone: { type: DataTypes.STRING, allowNull: true },
    },
    {
      timestamps: true,
      tableName: "AdminUsers",
    }
  );
  AdminUser.associate = function (models) {
    AdminUser.hasMany(models.SupportMessage, {
      foreignKey: "resolvedby",
    });
    AdminUser.hasMany(models.PasswordChangeHistory, {
      foreignKey: "markedby",
    });
    AdminUser.hasMany(models.AdminUserRole, {
      foreignKey: "user",
    });
  };

  AdminUser.prototype.comparePassword = function (passwordAttempt) {
    try {
      const isMatch = bcrypt.compareSync(passwordAttempt, this.password);

      return isMatch;
    } catch (error) {
      console.log("error", error);
    }
  };

  return AdminUser;
};
