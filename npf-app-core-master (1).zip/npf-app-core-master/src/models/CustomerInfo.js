"use strict";

module.exports = function (sequelize, DataTypes) {
  var CustomerInfo = sequelize.define(
    "CustomerInfo",
    {
      bvnhash: { type: DataTypes.STRING, allowNull: true },
      firstname: { type: DataTypes.STRING, allowNull: false },
      lastname: { type: DataTypes.STRING, allowNull: false },
      middlename: { type: DataTypes.STRING, allowNull: true },
      phone: { type: DataTypes.STRING, allowNull: false },
      simswapstatus: { type: DataTypes.STRING, allowNull: true },
      otpstatus: { type: DataTypes.STRING, allowNull: true },
      email: { type: DataTypes.STRING, allowNull: true },
      dob: { type: DataTypes.DATE, allowNull: false },
      gender: { type: DataTypes.STRING, allowNull: true },
      pob: { type: DataTypes.STRING, allowNull: true },
      bucket: { type: DataTypes.STRING, allowNull: true },
      photo_location: { type: DataTypes.STRING, allowNull: true },
      photo_key: { type: DataTypes.STRING, allowNull: true },
      photo_number: { type: DataTypes.STRING, allowNull: true },
      video_location: { type: DataTypes.STRING, allowNull: true },
      video_key: { type: DataTypes.STRING, allowNull: true },
      signature_location: { type: DataTypes.STRING, allowNull: true },
      signature_key: { type: DataTypes.STRING, allowNull: true },

      document_location: { type: DataTypes.STRING, allowNull: true },
      document_key: { type: DataTypes.STRING, allowNull: true },
      document_number: { type: DataTypes.STRING, allowNull: true },
      document_type_id: { type: DataTypes.INTEGER, allowNull: true },
      document_issue_date: { type: DataTypes.DATE, allowNull: true },
      document_expiry_date: { type: DataTypes.DATE, allowNull: true },

      isnewbankcustomer: { type: DataTypes.BOOLEAN, allowNull: true },
      isotpverified: { type: DataTypes.BOOLEAN, allowNull: true },


      signup_incomplete: { type: DataTypes.BOOLEAN, allowNull: true },

      livelinesschecked: { type: DataTypes.STRING, allowNull: true },
      // documentschecked: { type: DataTypes.BOOLEAN, allowNull: true }, // Deprecated

      
      photostatus: { type: DataTypes.STRING, allowNull: true },
      documentstatus: { type: DataTypes.STRING, allowNull: true },
      signaturestatus: { type: DataTypes.STRING, allowNull: true },
      profilecomplete: { type: DataTypes.STRING, allowNull: true },


      PND: { type: DataTypes.BOOLEAN, allowNull: true },
      enabled: { type: DataTypes.BOOLEAN, allowNull: true },
      account_status: { type: DataTypes.STRING, allowNull: true },
      salary_officer: { type: DataTypes.BOOLEAN, allowNull: true },
      force_number: { type: DataTypes.STRING, allowNull: true },
      ippis_number: { type: DataTypes.STRING, allowNull: true },
      address: { type: DataTypes.STRING(4000), allowNull: true },
      has_pin: { type: DataTypes.BOOLEAN, allowNull: true },
      customerNumber: { type: DataTypes.STRING, allowNull: true },
      companyCode: { type: DataTypes.STRING, allowNull: true },
      registration_channel: { type: DataTypes.STRING, allowNull: true },
      deviceid: { type: DataTypes.STRING, allowNull: true },      
      last_login_date: { type: DataTypes.DATE, allowNull: true },
    },
    {
      timestamps: true,
      tableName: "CustomerInfos",
    }
  );
  CustomerInfo.associate = function (models) {
    CustomerInfo.belongsTo(models.CustomerUser, {
      foreignKey: "user", allowNull: false
    });
    CustomerInfo.hasMany(models.OfficerInfo, {
      foreignKey: "customer",
    });
  };
  return CustomerInfo;
};
