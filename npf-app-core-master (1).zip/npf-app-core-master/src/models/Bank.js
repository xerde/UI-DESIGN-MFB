"use strict";

module.exports = function (sequelize, DataTypes) {
  var Bank = sequelize.define(
    "Bank",
    {
      code: { type: DataTypes.STRING },
      name: { type: DataTypes.STRING },
    },
    {
      timestamps: true,
      tableName: "Bank",
    }
  );

  return Bank;
};
