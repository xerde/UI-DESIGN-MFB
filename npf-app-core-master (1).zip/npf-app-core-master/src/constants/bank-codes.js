module.exports = [
  {
    code: "000001",
    name: "Sterling Bank",
  },
  {
    code: "000002",
    name: "Keystone Bank",
  },
  {
    code: "000003",
    name: "First City Monument Bank",
  },
  {
    code: "000004",
    name: "United Bank for Africa",
  },
  {
    code: "000005",
    name: "Diamond Bank",
  },
  {
    code: "000006",
    name: "JAIZ Bank",
  },
  {
    code: "000007",
    name: "Fidelity Bank",
  },
  {
    code: "000008",
    name: "Skye Bank",
  },
  {
    code: "000009",
    name: "Citi Bank",
  },
  {
    code: "000010",
    name: "Ecobank Bank",
  },
  {
    code: "000011",
    name: "Unity Bank",
  },
  {
    code: "000012",
    name: "StanbicIBTC Bank",
  },
  {
    code: "000013",
    name: "GTBank Plc",
  },
  {
    code: "000014",
    name: "Access Bank",
  },
  {
    code: "000015",
    name: "ZENITH BANK PLC",
  },
  {
    code: "000016",
    name: "First Bank of Nigeria",
  },
  {
    code: "000017",
    name: "Wema Bank",
  },
  {
    code: "000018",
    name: "Union Bank",
  },
  {
    code: "000019",
    name: "Enterprise Bank",
  },
  {
    code: "000020",
    name: "Heritage",
  },
  {
    code: "000021",
    name: "StandardChartered",
  },
  {
    code: "000022",
    name: "SUNTRUST BANK",
  },
  {
    code: "000023",
    name: "Providus Bank ",
  },
  {
    code: "000024",
    name: "Rand Merchant Bank",
  },
  {
    code: "000025",
    name: "TITAN TRUST BANK",
  },
  {
    code: "000026",
    name: "Taj Bank",
  },
  {
    code: "000027",
    name: "Globus Bank",
  },
  {
    code: "060001",
    name: "Coronation",
  },
  {
    code: "060002",
    name: "FBN merchant Bank",
  },
  {
    code: "060003",
    name: "NOVA MB",
  },
  {
    code: "070001",
    name: "NPF MicroFinance Bank",
  },
  {
    code: "070002",
    name: "Fortis Microfinance Bank",
  },
  {
    code: "070006",
    name: "Covenant MFB",
  },
  {
    code: "070007",
    name: "Omoluabi Mortgage Bank Plc",
  },
  {
    code: "070008",
    name: "Page MFBank",
  },
  {
    code: "070009",
    name: "GATEWAY MORTGAGE BANK",
  },
  {
    code: "070010",
    name: "ABBEY MORTGAGE BANK",
  },
  {
    code: "070011",
    name: "Refuge Mortgage Bank",
  },
  {
    code: "070012",
    name: "LBIC Mortgage Bank",
  },
  {
    code: "070013",
    name: "PLATINUM MORTGAGE BANK",
  },
  {
    code: "070014",
    name: "First Generation Mortgage Bank",
  },
  {
    code: "070015",
    name: "Brent Mortgage Bank",
  },
  {
    code: "070016",
    name: "Infinity trust  Mortgage Bank",
  },
  {
    code: "070017",
    name: "Haggai Mortgage Bank",
  },
  {
    code: "070019",
    name: "MayFresh Mortgage Bank",
  },
  {
    code: "090001",
    name: "ASOSavings",
  },
  {
    code: "090003",
    name: "JubileeLife",
  },
  {
    code: "090004",
    name: "Parralex",
  },
  {
    code: "090005",
    name: "Trustbond",
  },
  {
    code: "090006",
    name: "SafeTrust",
  },
  {
    code: "090097",
    name: "Ekondo MFB",
  },
  {
    code: "090107",
    name: "FBN Morgages Limited",
  },
  {
    code: "090108",
    name: "New Prudential Bank",
  },
  {
    code: "090110",
    name: "VFD MFB",
  },
  {
    code: "090111",
    name: "FinaTrust Microfinance Bank",
  },
  {
    code: "090112",
    name: "Seed Capital Microfinance Bank",
  },
  {
    code: "090114",
    name: "EMPIRE MFB",
  },
  {
    code: "090115",
    name: "TCF",
  },
  {
    code: "090116",
    name: "AMML MFB",
  },
  {
    code: "090117",
    name: "Boctrust Microfinance Bank",
  },
  {
    code: "090118",
    name: "IBILE Microfinance Bank",
  },
  {
    code: "090119",
    name: "OHAFIA MFB",
  },
  {
    code: "090120",
    name: "WETLAND MFB",
  },
  {
    code: "090121",
    name: "HASAL MFB",
  },
  {
    code: "090122",
    name: "GOWANS MFB",
  },
  {
    code: "090123",
    name: "Verite Microfinance Bank",
  },
  {
    code: "090124",
    name: "XSLNCE Microfinance Bank",
  },
  {
    code: "090125",
    name: "REGENT MFB",
  },
  {
    code: "090126",
    name: "FidFund MFB",
  },
  {
    code: "090127",
    name: "BC Kash MFB",
  },
  {
    code: "090128",
    name: "Ndiorah MFB",
  },
  {
    code: "090129",
    name: "MONEYTRUST MFB",
  },
  {
    code: "090130",
    name: "CONSUMER  MFB",
  },
  {
    code: "090131",
    name: "ALLWORKERS MFB",
  },
  {
    code: "090132",
    name: "RICHWAY MFB",
  },
  {
    code: "090133",
    name: "AL-BARKAH MFB",
  },
  {
    code: "090134",
    name: "ACCION MFB",
  },
  {
    code: "090135",
    name: "Personal Trust Microfinance Bank",
  },
  {
    code: "090136",
    name: "Microcred Microfinance Bank",
  },
  {
    code: "090137",
    name: "Pecan Trust Microfinance Bank",
  },
  {
    code: "090138",
    name: "Royal Exchange Microfinance Bank",
  },
  {
    code: "090139",
    name: "Visa Microfinance Bank",
  },
  {
    code: "090140",
    name: "Sagamu Microfinance Bank",
  },
  {
    code: "090141",
    name: "Chikum Microfinance Bank",
  },
  {
    code: "090142",
    name: "Yes MFB",
  },
  {
    code: "090143",
    name: "APEKS Microfinance Bank",
  },
  {
    code: "090144",
    name: "CIT Microfinance Bank",
  },
  {
    code: "090145",
    name: "Full range MFB",
  },
  {
    code: "090146",
    name: "Trident Microfinance Bank",
  },
  {
    code: "090147",
    name: "Hackman Microfinance Bank",
  },
  {
    code: "090148",
    name: "Bowen MFB",
  },
  {
    code: "090149",
    name: "IRL Microfinance Bank",
  },
  {
    code: "090150",
    name: "Virtue MFB",
  },
  {
    code: "090151",
    name: "Mutual Trust Microfinance Bank",
  },
  {
    code: "090152",
    name: "Nargata MFB",
  },
  {
    code: "090153",
    name: "FFS Microfinance Bank",
  },
  {
    code: "090154",
    name: "CEMCS MFB",
  },
  {
    code: "090155",
    name: "Lafayette Microfinance Bank",
  },
  {
    code: "090156",
    name: "e-BARCs MFB",
  },
  {
    code: "090157",
    name: "Infinity MFB",
  },
  {
    code: "090158",
    name: "FUTO MFB",
  },
  {
    code: "090159",
    name: "Credit Afrique MFB",
  },
  {
    code: "090160",
    name: "Addosser MFBB",
  },
  {
    code: "090161",
    name: "Okpoga MFB",
  },
  {
    code: "090162",
    name: "Stanford MFB",
  },
  {
    code: "090163",
    name: "First Multiple MFB",
  },
  {
    code: "090164",
    name: "First Royal Microfinance Bank",
  },
  {
    code: "090165",
    name: "Petra Microfinance Bank",
  },
  {
    code: "090166",
    name: "Eso-E Microfinance Bank",
  },
  {
    code: "090167",
    name: "Daylight Microfinance Bank",
  },
  {
    code: "090168",
    name: "Gashua Microfinance Bank",
  },
  {
    code: "090169",
    name: "Alphakapital MFB",
  },
  {
    code: "090170",
    name: "Rahama MFB",
  },
  {
    code: "090171",
    name: "Mainstreet MFB",
  },
  {
    code: "090172",
    name: "Astrapolis MFB",
  },
  {
    code: "090173",
    name: "Reliance MFB",
  },
  {
    code: "090174",
    name: "Malachy MFB",
  },
  {
    code: "090175",
    name: "HighStreet MFB",
  },
  {
    code: "090176",
    name: "Bosak MFB",
  },
  {
    code: "090177",
    name: "Lapo MFB",
  },
  {
    code: "090178",
    name: "GreenBank MFB",
  },
  {
    code: "090179",
    name: "FAST MFB",
  },
  {
    code: "090180",
    name: "Amju MFB",
  },
  {
    code: "090188",
    name: "Baines Credit MFB",
  },
  {
    code: "090189",
    name: "Esan MFB",
  },
  {
    code: "090190",
    name: "Mutual Benefits MFB",
  },
  {
    code: "090191",
    name: "KCMB MFB",
  },
  {
    code: "090193",
    name: "Unical MFB",
  },
  {
    code: "090194",
    name: "NIRSAL National microfinance bank",
  },
  {
    code: "090195",
    name: "Grooming Microfinance bank",
  },
  {
    code: "090196",
    name: "Pennywise Microfinance bank",
  },
  {
    code: "090197",
    name: "ABU Microfinance bank",
  },
  {
    code: "090198",
    name: "Renmoney microfinance bank",
  },
  {
    code: "090205",
    name: "Newdawn Microfinance bank",
  },
  {
    code: "090211",
    name: "Itex Integrated Services Limited",
  },
  {
    code: "090258",
    name: "Imo Microfinance bank",
  },
  {
    code: "090259",
    name: "Alekun Microfinance bank",
  },
  {
    code: "090260",
    name: "Above Only Microfinance bank",
  },
  {
    code: "090261",
    name: "QuickFund Microfinance bank",
  },
  {
    code: "090262",
    name: "Stellas Microfinance bank",
  },
  {
    code: "090263",
    name: "Navy Microfinance bank",
  },
  {
    code: "090264",
    name: "Auchi Microfinance bank",
  },
  {
    code: "090265",
    name: "Lovonus Microfinance bank",
  },
  {
    code: "090266",
    name: "Uniben Microfinance bank",
  },
  {
    code: "090267",
    name: "KudiMoney Microfinance bank",
  },
  {
    code: "090268",
    name: "Adeyemi College Staff Microfinance bank",
  },
  {
    code: "090269",
    name: "Greenville Microfinance bank",
  },
  {
    code: "090270",
    name: "AB Microfinance bank",
  },
  {
    code: "090271",
    name: "Lavender Microfinance bank",
  },
  {
    code: "090272",
    name: "Olabisi Onabanjo university Microfinance bank",
  },
  {
    code: "090273",
    name: "Emeralds MFB",
  },
  {
    code: "090274",
    name: "Prestige Microfinance bank",
  },
  {
    code: "090275",
    name: "Meridian MFB",
  },
  {
    code: "090277",
    name: "Alhayat MFB",
  },
  {
    code: "090278",
    name: "Glory MFB ",
  },
  {
    code: "090279",
    name: "Ikire MFB",
  },
  {
    code: "090280",
    name: "Megapraise Microfinance Bank",
  },
  {
    code: "090281",
    name: "Finex MFB",
  },
  {
    code: "090282",
    name: "Arise MFB",
  },
  {
    code: "090283",
    name: "Nnew women MFB",
  },
  {
    code: "090285",
    name: "First Option MFB",
  },
  {
    code: "090286",
    name: "Safe Haven MFB",
  },
  {
    code: "090289",
    name: "Pillar MFB",
  },
  {
    code: "090290",
    name: "FCT MFB",
  },
  {
    code: "090291",
    name: "Hala MFB",
  },
  {
    code: "090293",
    name: "BRETHREN MICROFINANCE BANK",
  },
  {
    code: "090294",
    name: "Eagle Flight MFB",
  },
  {
    code: "090295",
    name: "Omiye MFB",
  },
  {
    code: "090296",
    name: "Polyuwanna MFB",
  },
  {
    code: "090297",
    name: "Alert MFB",
  },
  {
    code: "090298",
    name: "FederalPoly NasarawaMFB",
  },
  {
    code: "090299",
    name: "Kontagora MFB",
  },
  {
    code: "090303",
    name: "Purplemoney MFB",
  },
  {
    code: "090304",
    name: "Evangel MFB",
  },
  {
    code: "090305",
    name: "Sulsap MFB",
  },
  {
    code: "090308",
    name: "Brightway MFB",
  },
  {
    code: "090310",
    name: "Edfin MFB",
  },
  {
    code: "090315",
    name: "U AND C MFB",
  },
  {
    code: "090316",
    name: "Bayero MICROFINANCE BANK",
  },
  {
    code: "090317",
    name: "Patrick Gold",
  },
  {
    code: "090318",
    name: "FEDERAL UNIVERSITY DUTSE  MICROFINANCE BANK",
  },
  {
    code: "090320",
    name: "Kadpoly MICROFINANCE BANK",
  },
  {
    code: "090321",
    name: "Mayfair  MFB",
  },
  {
    code: "090323",
    name: "Mainland MICROFINANCE BANK",
  },
  {
    code: "090324",
    name: "IKENNE MFB",
  },
  {
    code: "090325",
    name: "SPARKLE MICROFINANCE BANK",
  },
  {
    code: "090326",
    name: "Balogun Gambari MFB",
  },
  {
    code: "090327",
    name: "Trust MFB",
  },
  {
    code: "090332",
    name: "Evergreen MICROFINANCE BANK",
  },
  {
    code: "100001",
    name: "FET",
  },
  {
    code: "100002",
    name: "Paga",
  },
  {
    code: "100003",
    name: "Parkway-ReadyCash",
  },
  {
    code: "100004",
    name: "Paycom",
  },
  {
    code: "100005",
    name: "Cellulant",
  },
  {
    code: "100006",
    name: "eTranzact",
  },
  {
    code: "100007",
    name: "StanbicMobileMoney",
  },
  {
    code: "100008",
    name: "Ecobank Xpress Account",
  },
  {
    code: "100009",
    name: "GTMobile",
  },
  {
    code: "100010",
    name: "TeasyMobile",
  },
  {
    code: "100011",
    name: "Mkudi",
  },
  {
    code: "100012",
    name: "VTNetworks",
  },
  {
    code: "100013",
    name: "AccessMobile",
  },
  {
    code: "100014",
    name: "FBNMobile",
  },
  {
    code: "100015",
    name: "Kegow",
  },
  {
    code: "100016",
    name: "FortisMobile",
  },
  {
    code: "100017",
    name: "Hedonmark",
  },
  {
    code: "100018",
    name: "ZenithMobile",
  },
  {
    code: "100019",
    name: "Fidelity Mobile",
  },
  {
    code: "100020",
    name: "MoneyBox",
  },
  {
    code: "100021",
    name: "Eartholeum",
  },
  {
    code: "100022",
    name: "Sterling Mobile",
  },
  {
    code: "100023",
    name: "TagPay",
  },
  {
    code: "100024",
    name: "Imperial Homes Mortgage Bank",
  },
  {
    code: "100025",
    name: "KongaPay",
  },
  {
    code: "100026",
    name: "ONE FINANCE",
  },
  {
    code: "100027",
    name: "Intellifin",
  },
  {
    code: "100028",
    name: "AG MORTGAGE BANK PLC",
  },
  {
    code: "100029",
    name: "Innovectives Kesh",
  },
  {
    code: "100031",
    name: "FCMB MOBILE",
  },
  {
    code: "100032",
    name: "Contec Global",
  },
  {
    code: "100033",
    name: "PalmPay",
  },
  {
    code: "100052",
    name: "Access Yello &amp; Beta",
  },
  {
    code: "110001",
    name: "PayAttitude Online",
  },
  {
    code: "110002",
    name: "Flutterwave Technology solutions Limited",
  },
  {
    code: "110003",
    name: "Interswitch Limited",
  },
  {
    code: "110004",
    name: "First Apple Limited",
  },
  {
    code: "110005",
    name: "3line Card management Limited",
  },
  {
    code: "110006",
    name: "Paystack Payments Limited",
  },
  {
    code: "110007",
    name: "Team APT",
  },
  {
    code: "110008",
    name: "Kadick Integration Limited",
  },
  {
    code: "400001",
    name: "FSDH",
  },
  {
    code: "999999",
    name: "NIP Virtual Bank",
  },
];
