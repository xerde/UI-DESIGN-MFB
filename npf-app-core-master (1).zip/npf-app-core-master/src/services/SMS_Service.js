const CustomerInfo = require("../models").CustomerInfo;
const CustomerUser = require("../models").CustomerUser;

const { Op } = require("sequelize");

var axios = require("axios");

module.exports = {
  accountUpdated: async (phone, firstname, lastname, accountnumber) => {
    console.log("accountUpdated sms to ", phone);
    try {

      if(accountnumber){
        axios.get(
          `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYou are welcome to the online platform of the NPF Microfinance Bank\nYour account number is: ${accountnumber}`
        );
      }
      else{
        axios.get(
          `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYou are welcome to the online platform of the NPF Microfinance Bank\n`
        );
      }
      
    } catch (error) {
      console.log("error", error);
    }
  },

  sendOTP: async (phone) => {
    console.log("otp sms to ", phone);
    try {
      let otp = Math.floor(100000 + Math.random() * 900000);

      let response = await CustomerUser.update(
        { otp: otp, temptokencreatedon: new Date() },
        {
          where: { username: phone },
        }
      );

      await CustomerInfo.update(
        { isotpverified: false },
        {
          where: { phone: phone },
        }
      );

      if (response[0] !== 1) throw new Error("Token not sent");

      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Your otp is: ${otp}\nToken will expire in ${process.env.TOKEN_EXPIRY_MINUTES} minutes`
      );
    } catch (error) {
      console.log("error", error);

      // axios.get(
      //   `https://www.bulksmsnigeria.com/api/v1/sms/create?api_token=SvHNXqYtkQVNbRB1GkeUVREabgCkoW6P5BrUTdkReghfWcm7e8GpdGlMVRW5&from=${"NPF-MFB"}&to=${phone}&body=Your code%20is:%20${otp}&dnd=4`
      // );
    }
  },

  transactionAlert: async (phone, type, amount, source_account, narration, balance) => {
    console.log("tx alert sms to ", phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Acct: ${source_account}\nAmt: ${amount} DR\nDesc: ${narration}\nAvail Bal: NGN${balance}`
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  profileConfirmed: async (phone, firstname, lastname) => {
    console.log("livelinessConfirmed sms to ", phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYour profile has been confirmed\nNPF-MFB`
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  pinReset: async (phone, firstname, lastname) => {
    console.log("pinReset sms to ", phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYour pin has been reset.\nNPF-MFB`
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  passwordReset: async (customer) => {
    console.log("passwordReset sms to ", customer.phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${customer.phone}&Text=Hello ${customer.firstname} ${customer.lastname}\nA password reset attempt has been made on your account.\nNPF-MFB`
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  device_unlink: async (phone, firstname, lastname) => {
    console.log("device_unlink sms to ", phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYour device has been unlinked from your profile.\nNPF-MFB`
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  infoUpdated: async (phone, firstname, lastname) => {
    console.log("infoUpdated sms to ", phone);
    try {
      axios.get(
        `${process.env.SMS_URL}/?User=${process.env.SMS_USER}&Password=${process.env.SMS_PASSWORD}&Sender=${process.env.SMS_SENDER}&PhoneNumber=${phone}&Text=Hello ${firstname} ${lastname}\nYour data has been updated.\nNPF-MFB`
      );
    } catch (error) {
      console.log("error", error);
    }
  },
};
