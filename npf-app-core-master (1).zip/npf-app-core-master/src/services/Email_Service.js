const sendGrid = require("../config/sendgrid");
var numeral = require("numeral");
var dayjs = require("dayjs");

module.exports = {
  cbaError: async (endpoint, error) => {
    try {
      console.log("cbaError email:");
      // const msg = {
      //   to: ["uguddoh@gmail.com"], //kalu@adbasador.com
      //   from: process.env.SENDER_EMAIL,
      //   subject: `INLAKS Error[${process.env.ENV}]: ${endpoint}`,
      //   html: `${error}
      //   <br><br>
      //   ${error.stack}`,
      // };

      // await sendGrid.sendMultiple(msg);
    } catch (error) {
      console.log("error", error);
    }
  },

  accountUpdated: async (email, firstname, lastname, accountnumber) => {
    try {
      console.log("accountUpdated email to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Welcome`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        You are welcome to the online platform of the NPF Microfinance Bank.
        <br>

        ${accountnumber ? `Your account number is: ${accountnumber}` : ""}
        
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },

  infoUpdated: async (email, firstname, lastname) => {
    try {
      console.log("infoUpdated email to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Information Updated`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        Your data has been updated.

        
        <br><br>
        Thank you for choosing NPF Microfinance Bank
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },

  passwordReset: async (customer, tempPassword) => {
    try {
      console.log("reset mail to: ", customer.email);
      const msg = {
        to: `${customer.email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Login Assistance`,
        // text: `hello there`
        html: `Hello ${customer.firstname} ${customer.lastname}
      <br><br>
      Your password has been reset. Use the temporary password below to login - after which you will be prompted to create a new password.

      <br>
      Temporary password expires after ${process.env.TOKEN_EXPIRY_MINUTES} minutes
      <br><br>
      Temporary password: ${tempPassword}

      <br><br>
        Thank you for choosing NPF Microfinance Bank
      `,
      };
      let response = await sendGrid.send(msg);
    } catch (error) {
      console.log("error", error);
    }
  },

  transactionAlert: async (
    email,
    firstname,
    lastname,
    type,
    amount,
    source_account,
    narration,
    targetaccountname,
    targetaccountnumber,
    balance
  ) => {
    try {
      console.log("transfer mail to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB Transaction Alert [${type}: ${numeral(amount).format(
          "0,0"
        )}]`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        We wish to inform you that a Debit transaction occurred on your account with us.
  
        <br>
   
        The details of this transaction are shown below:
  
        <br><br>
        <br>Transaction Date: ${dayjs().format("YYYY-MM-DD")}
        <br>Account Number: ${source_account}
        <br>Type: ${type}
        <br>Amount: ${amount}
        <br>Narration: ${narration}
        <br>Receiver: ${targetaccountname}
        <br>Receiver Number: ${targetaccountnumber}
        <br>Balance: ${balance}
  
        <br><br>
        Thank you for choosing NPF Microfinance Bank
        `,
      };
      let response = await sendGrid.send(msg);
    } catch (error) {
      console.log("error", error);
    }
  },

  login: async (email, firstname, lastname) => {
    try {
      console.log("login mail to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Login Confirmation`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>

        Please be informed that your MFB Online profile was accessed at ${new Date()}.

        <br><br>

        If you did not log on to your MFB profile at the time detailed above, please call our contact center.

        <br><br>

        Thank you for banking with us.
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },

  profileConfirmed: async (email, firstname, lastname) => {
    try {
      console.log("livelinessConfirmed mail to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Liveliness Confirmed`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        Your profile has been confirmed
        
        <br><br>
        Thank you for choosing NPF Microfinance Bank
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },

  pinReset: async (email, firstname, lastname) => {
    try {
      console.log("pinReset mail to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Pin Reset`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        Your pin has been reset.
        
        <br><br>
        Thank you for choosing NPF Microfinance Bank
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },

  device_unlink: async (email, firstname, lastname) => {
    try {
      console.log("device_unlink mail to: ", email);
      const msg = {
        to: `${email}`,
        from: process.env.SENDER_EMAIL,
        subject: `NPF MFB - Pin Reset`,
        // text: `hello there`
        html: `Hello ${firstname} ${lastname}
        <br><br>
        Your device has been unlinked from your profile.
        
        <br><br>
        Thank you for choosing NPF Microfinance Bank
        `,
      };
      let response = await sendGrid.send(msg);

      // console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  },
};
