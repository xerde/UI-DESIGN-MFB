const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;

const CBA_Service = require("./CBA_Service");
const Util_Service = require("./Util_Service");

const Op = require("../models/index").Sequelize.Op;

var dayjs = require("dayjs");

const shortid = require("shortid");
var bcrypt = require("bcryptjs");
const Email_Service = require("./Email_Service");
const SMS_Service = require("./SMS_Service");
var salt = bcrypt.genSaltSync(10);

module.exports = {
  resetPassword: async (customerUserId) => {
    let tempPassword = shortid.generate();
    // console.log('tempPassword', tempPassword)

    let hashedPw = bcrypt.hashSync(tempPassword, salt);

    await CustomerUser.update(
      {
        password: hashedPw,
        requirespasswordchange: true,
        temptokencreatedon: new Date(),
      },
      { where: { id: customerUserId } }
    );

    return tempPassword;
  },

  updatePassword: async (id, password) => {
    let hashedPw = bcrypt.hashSync(password, salt);

    await CustomerUser.update(
      { password: hashedPw, requirespasswordchange: false },
      { where: { id: id } }
    );
  },

  setPin: async (customerUser, pin) => {
    let isExistingPin = null;

    if (customerUser.transactionpin !== null) {
      isExistingPin = bcrypt.compareSync(pin, customerUser.transactionpin);
    }

    if (!isExistingPin) {
      let hashedPin = bcrypt.hashSync(pin, salt);

      await CustomerUser.update(
        { transactionpin: hashedPin, transactionpinchangedon: new Date() },
        { where: { id: customerUser.id } }
      );
    }

    return isExistingPin;
  },

  pinMatched: async (customerInfoId, pin) => {
    let customerInfo = await CustomerInfo.findOne({
      where: {
        [Op.and]: [{ id: customerInfoId }, { has_pin: true }],
      },
      include: [{ model: CustomerUser }],
    });

    if (
      customerInfo &&
      bcrypt.compareSync(pin, customerInfo.CustomerUser.transactionpin)
    ) {
      return true;
    } else {
      return false;
    }
  },

  isTokenExpired: async (creationDate) => {
    let tokenExpiry = dayjs(creationDate).add(
      process.env.TOKEN_EXPIRY_MINUTES,
      "m"
    );

    if (dayjs().isAfter(tokenExpiry)) {
      return true;
    } else {
      return false;
    }
  },

  createCustomer: async (payload, channel) => {
    // console.log('payload', payload)

    let hashedPw = payload.password;

    if (payload.password) {
      hashedPw = bcrypt.hashSync(payload.password, salt);
    }

    try {
      let customer_user = {
        username: payload.phone,
        password: hashedPw,
      };

      //ensure username doesn't already exist
      let existingCustomer = await CustomerUser.findOne({
        where: { username: payload.phone },
      });

      if (existingCustomer) {
        throw new Error(
          `Customer with username:${payload.phone} already exists`
        );
      } else {
        let createdUser = await CustomerUser.create(customer_user);

        // console.log('createdUser', createdUser)

        let customer_info = {
          bvnhash: payload.bvn,
          firstname: payload.firstname,
          lastname: payload.lastname,
          middlename: payload.middlename,
          phone: payload.phone,
          email: payload.email,
          dob: payload.date_of_birth || new Date(),
          user: createdUser.id,
          customerNumber: payload.customerNumber,
          companyCode: payload.companyCode,
          registration_channel: channel,
          isnewbankcustomer: channel === "bank" ? false : true,
          isotpverified: false,
          PND: channel === "bank" ? true : false,
          signup_incomplete: true,
          has_pin: false,
          enabled: true,
          livelinesschecked: "PENDING",
          photostatus: "PENDING",
          documentstatus: "PENDING",
          signaturestatus: "PENDING",
          profilecomplete: "PENDING"
        };

        let createdInfo = await CustomerInfo.create(customer_info);

        return createdInfo;
      }
    } catch (error) {
      console.log("error", error);
      throw error;
    }
  },

  createRole: async (payload) => {
    let role = await AdminRole.findOne({
      where: { name: payload.name },
    });

    if (!role) {
      role = await AdminRole.create({
        name: payload.name,
      });
    }

    return role;
  },

  createAdmin: async (payload) => {
    let user = await AdminUser.findOne({
      where: { username: payload.email },
    });

    if (user) {
      let roleMapping = await AdminUserRole.findOne({
        where: {
          [Op.and]: [
            {
              role: payload.roleId,
            },
            {
              user: payload.userId,
            },
          ],
        },
      });
    } else {
      let hashedPw = bcrypt.hashSync(payload.password, salt);

      user = await AdminUser.create({
        username: payload.email,
        password: hashedPw,
      });

      roleMapping = await AdminUserRole.create({
        role: payload.roleId,
        user: payload.userId,
      });
    }

    return role;
  },

  update_customer_info: async (data, customerInfoId) => {
    let customerInfo = await CustomerInfo.findOne({
      where: { id: customerInfoId },
    });
    customerInfo.firstname = data.firstname;
    customerInfo.lastname = data.lastname;
    customerInfo.middlename = data.middlename;

    await customerInfo.save();

    return customerInfo;
  },

  create_inlaks_account: async (customerInfoId) => {
    console.log("creating inlaks account ", customerInfoId);
    try {
      let customerInfo = await CustomerInfo.findOne({
        where: {
          [Op.and]: [{ id: customerInfoId }, { signup_incomplete: true }],
        },
      });

      if (!customerInfo) {
        return {
          success: false,
          message: "Customer previously registered successfully",
        };
      }

      console.log("customerNumber", customerInfo.customerNumber);
      console.log("photo_location", customerInfo.photo_location);
      console.log("signature_location", customerInfo.signature_location);

      if (customerInfo.customerNumber) {
        //bank channel - no need to create new account
        return {
          success: true,
          data: {
            email: customerInfo.email,
            firstname: customerInfo.firstname,
            lastname: customerInfo.lastname,
            accountnumber: null,
            phone: customerInfo.phone,
          },
          message: "Account created",
        };
      } else {
        let phoneLookupFeedback = await CBA_Service.phoneLookup(
          customerInfo.phone
        );

        console.log("phoneLookup feedback", phoneLookupFeedback);

        if (phoneLookupFeedback.status) {
          //customer exists on cba

          let customerNumber = null;

          //create all bank accounts
          // for (const account of phoneLookupFeedback.data.accounts) {
          //   customerNumber = account.customerNumber;

          //   console.log("account.accountNo", account.accountNo);

          //   await BankAccount.create({
          //     accountnumber: account.accountNo,
          //     accountname: account.accountName,
          //     address: "",
          //     type: account.accountType,
          //     balance: account.bookBalance,
          //     CompanyCode: null,
          //     user: customerInfo.user,
          //   });
          // }

          //update customer info with customerNumber, set custominfo PND to true and is old customer

          await CustomerInfo.update(
            {
              PND: true,
              customerNumber: customerNumber,
              signup_incomplete: false,
              isnewbankcustomer: false,
            },
            { where: { id: customerInfo.id } }
          );

          //return payload for notification
          return {
            success: true,
            data: {
              email: customerInfo.email,
              firstname: customerInfo.firstname,
              lastname: customerInfo.lastname,
              accountnumber: null,
              phone: customerInfo.phone,
            },
            message: "Account created",
          };
        } else {
          //brand new customer; not on cba
          if (customerInfo.photo_location && customerInfo.signature_location) {
            let imageBase64 = await Util_Service.urlToBase64(
              customerInfo.photo_location
            );

            let signatureBase64 = await Util_Service.urlToBase64(
              customerInfo.signature_location
            );

            let data = {
              FirstName: customerInfo.firstname,
              MiddleName: customerInfo.middlename || "",
              LastName: customerInfo.lastname,
              Gender: customerInfo.gender,
              DateOfBirth: dayjs(customerInfo.dob).format("YYYY-MM-DD"),
              EmailAddress: customerInfo.email,
              MobileNumber: customerInfo.phone,
              Address: customerInfo.address || "",
              Image: imageBase64,
              Signature: signatureBase64,
            };

            let feedback = await CBA_Service.createUserAccount(data);

            console.log("createUserAccount feedback", feedback);

            if (feedback.status) {
              await CustomerInfo.update(
                {
                  customerNumber: feedback.data.customerNumber,
                  signup_incomplete: false,
                },
                { where: { id: customerInfo.id } }
              );

              // await BankAccount.create({
              //   accountname: `${data.FirstName} ${data.LastName}`,
              //   accountnumber: feedback.data.accountNumber,
              //   user: customerInfo.user,
              // });

              return {
                success: true,
                data: {
                  email: customerInfo.email,
                  firstname: customerInfo.firstname,
                  lastname: customerInfo.lastname,
                  accountnumber: feedback.data.accountNumber,
                  phone: customerInfo.phone,
                },
                message: "Account created",
              };
            } else {
              return { success: false, message: feedback.message };
            }
          } else {
            return { success: false, message: "Data incomplete" };
          }
        }
      }
    } catch (error) {
      console.log("error", error.message);
      // console.log("error", error);
    }
  },

  profile_completion: async (customerInfoId) => {
    let response = await CustomerInfo.update(
      { profilecomplete: "APPROVED" },
      {
        where: {
          [Op.and]: [
            // {
            //   livelinesschecked: "APPROVED",
            // },
            {
              photostatus: "APPROVED",
            },
            {
              documentstatus: "APPROVED",
            },
            {
              signaturestatus: "APPROVED",
            },
            {
              id: customerInfoId,
            },
          ],
        },
      }
    );

    if (response[0] === 1) {
      //success
      let customerInfo = await CustomerInfo.findOne({
        where: { id: customerInfoId },
      });

      console.log(
        "SUCCESS: Completed profile for user " + customerInfoId
      );

      await Email_Service.profileConfirmed(
        customerInfo.email,
        customerInfo.firstname,
        customerInfo.lastname
      );

      await SMS_Service.profileConfirmed(
        customerInfo.phone,
        customerInfo.firstname,
        customerInfo.lastname
      );
    } else {
      //failed
      console.log(
        "ERROR: Unable to complete profile for user " + customerInfoId
      );
    }
  },
};
