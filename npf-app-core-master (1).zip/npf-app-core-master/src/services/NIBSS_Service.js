
var axios = require("axios");

module.exports = {
  getBVN: async (bvn) => {
    if (bvn === 12345678911) {
      return {
        status: true,
        data: {
          bvn: "12345678911",
          firstname: "John",
          middlename: "Ranger",
          lastname: "Snow",
          date_of_birth: "1981-01-01",
          registration_date: "1981-01-01",
          phone: "2348037416455",
          gender: "MALE",
        },
      };
    }

    try {
      const config = {
        headers: {
          Authorization: `Bearer ${process.env.PAYSTACK_KEY}`,
        },
      };

      const response = await axios.get(
        `${process.env.PAYSTACK_URL}/bank/resolve_bvn/${bvn}`,
        config
      );

      if (response.status) {
        let data = response.data.data;

        // console.log("data", data);

        let updatedData = {
          bvn: data.bvn,
          firstname: data.first_name,
          lastname: data.last_name,
          date_of_birth: data.formatted_dob,
          phone: data.mobile.startsWith("0")
            ? data.mobile.replace("0", "234")
            : data.mobile,
        };

        return { status: true, data: updatedData };
      } else {
        return { status: false, message: "BVN not found" };
      }
    } catch (error) {
      console.log('error', error.message)
      // console.log("status", error.response.status);
      // console.log("data", error.response.data);
      return error.response.data;
    }
  },

};
