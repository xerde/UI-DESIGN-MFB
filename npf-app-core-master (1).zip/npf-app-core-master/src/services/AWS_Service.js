const AWS = require("aws-sdk");
AWS.config.loadFromPath("./aws-config.json");
const s3 = new AWS.S3({ apiVersion: "2006-03-01" });

const fs = require("fs");
const axios = require("axios");

const CustomerInfo = require("../models").CustomerInfo;

const NPF_MFB_FOLDER = process.env.AWS_BUCKET;

module.exports = {
  uploadCustomerPhoto: async (customer_id, file) => {
    const imageFolderPath = `${NPF_MFB_FOLDER}/${customer_id}/photo`;

    let params = {
      ACL: "public-read",
      Bucket: imageFolderPath,
      Key: file.originalname,
      Body: fs.createReadStream(file.path),
      StorageClass: "INTELLIGENT_TIERING",
    };

    s3.upload(params, async (err, data) => {
      if (err) throw err;

      await CustomerInfo.update(
        {
          photo_location: data.Location,
          photo_key: data.Key,
          bucket: data.Bucket,
        },
        { where: { id: customer_id } }
      );
    });
  },

  uploadCustomerVideo: async (customer_id, file) => {
    const imageFolderPath = `${NPF_MFB_FOLDER}/${customer_id}/video`;

    let params = {
      ACL: "public-read",
      Bucket: imageFolderPath,
      Key: file.originalname,
      Body: fs.createReadStream(file.path),
      StorageClass: "INTELLIGENT_TIERING",
    };

    s3.upload(params, async (err, data) => {
      if (err) throw err;

      await CustomerInfo.update(
        {
          video_location: data.Location,
          video_key: data.Key,
          bucket: data.Bucket,
        },
        { where: { id: customer_id } }
      );
    });
  },

  uploadCustomerSignature: async (customer_id, file) => {
    const imageFolderPath = `${NPF_MFB_FOLDER}/${customer_id}/signature`;

    let params = {
      ACL: "public-read",
      Bucket: imageFolderPath,
      Key: file.originalname,
      Body: fs.createReadStream(file.path),
      StorageClass: "INTELLIGENT_TIERING",
    };

    s3.upload(params, async (err, data) => {
      if (err) throw err;

      await CustomerInfo.update(
        {
          signature_location: data.Location,
          signature_key: data.Key,
          bucket: data.Bucket,
        },
        { where: { id: customer_id } }
      );
    });
  },

  uploadCustomerDocument: async (
    customer_id,
    document_type_id,
    document_number,
    document_issue_date,
    document_expiry_date,
    file
  ) => {
    const imageFolderPath = `${NPF_MFB_FOLDER}/${customer_id}/document`;

    let params = {
      ACL: "public-read",
      Bucket: imageFolderPath,
      Key: file.originalname,
      Body: fs.createReadStream(file.path),
      StorageClass: "INTELLIGENT_TIERING",
    };

    s3.upload(params, async (err, data) => {
      if (err) throw err;

      await CustomerInfo.update(
        {
          document_location: data.Location,
          document_key: data.Key,
          document_number: document_number,
          document_type_id: document_type_id,
          document_issue_date: document_issue_date,
          document_expiry_date: document_expiry_date,
          bucket: data.Bucket,
        },
        { where: { id: customer_id } }
      );
    });
  },

  // urlToBase64: async (url) => {
  //   try {
  //     let image = await axios.get(url, { responseType: "arraybuffer" });
  //     let returnedB64 = Buffer.from(image.data).toString("base64");

  //     // console.log("returnedB64", `data:image/png;base64,${returnedB64}`);

  //     return `data:image/png;base64,${returnedB64}`;
  //   } catch (error) {
  //     console.log("error", error);
  //   }
  // },
};
