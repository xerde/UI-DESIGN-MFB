const CustomerUser = require("../models").CustomerUser;
const CustomerInfo = require("../models").CustomerInfo;
const BankAccount = require("../models").BankAccount;
const FundsTransferRequest = require("../models").FundsTransferRequest;

const CBA_Service = require("./CBA_Service");
const Util_Service = require("./Util_Service");

const Op = require("../models/index").Sequelize.Op;

var dayjs = require("dayjs");
const Big = require("big.js");
const { Sequelize } = require("../models");

module.exports = {
  checkForDailyTransactionLimit: async (customerUserId, amount) => {
    let bankAccounts = await BankAccount.findAll({
      where: { user: customerUserId },
    });

    let accountIds = bankAccounts.map((item) => item.id);

    const TODAY_START = new Date().setHours(0, 0, 0, 0);
    const NOW = new Date();

    let results = await FundsTransferRequest.findAll({
      raw: true,
      attributes: [[Sequelize.fn("sum", Sequelize.col("amount")), "sumToday"]],
      where: {
        [Op.and]: [
          {
            status: "COMPLETED",
          },
          {
            sourceaccount: {
              [Op.in]: accountIds,
            },
          },
          {
            createdAt: {
              [Op.gt]: TODAY_START,
              [Op.lt]: NOW,
            },
          },
        ],
      },
    });

    console.log("results", results);

    let sumToday = results[0].sumToday || 0;

    let projectedTransfer = Big(sumToday).plus(Big(amount));

    let dailyTransferLimit = Big(process.env.DAILY_TRANSFER_LIMIT);

    return {
      limitExceeded: projectedTransfer.gt(dailyTransferLimit) ? true : false,
      sumToday: sumToday,
      projectedTransfer: projectedTransfer.toString(),
      limit: dailyTransferLimit.toString(),
    };
  },

  //Not yet used, but should be used by FundsTransferController
  checkIfAccountOwner: async (account, customerUserId) => {
    let bankAccount = await BankAccount.findOne({
      where: {
        [Op.and]: [{ accountnumber: account }, { user: customerUserId }],
      },
    });

    if (bankAccount) {
      return true;
    } else {
      return false;
    }
  }, 

  syncBankAccounts: async (user, inlaksAccounts) => {
    let accounts = await BankAccount.findAll({
      where: { user: user.coreId },
    });

    let unsyncedAccounts = [];

    for (const inlaksAccount of inlaksAccounts) {
      let match = false;

      for (const account of accounts) {
        if (inlaksAccount.accountNo === account.accountnumber) {
          match = true;
          break;
        }
      }

      if (!match) {
        unsyncedAccounts.push(inlaksAccount);
      }
    }

    for (const unsyncedAccount of unsyncedAccounts) {
      await BankAccount.create({
        accountnumber: unsyncedAccount.accountNo,
        accountname: unsyncedAccount.accountName,
        address: "",
        type: unsyncedAccount.accountType,
        balance: unsyncedAccount.availableBalance,
        bookBalance: unsyncedAccount.bookBalance,
        user: user.coreId
      });
    }

    
  },
};
