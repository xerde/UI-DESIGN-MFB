
const axios = require("axios");

module.exports = {
  maskAccount: (account) => {
    try {
      return "******" + account.slice(6);
    } catch (error) {
      console.log("error", error);
    }
  },

  urlToBase64: async (url) => {
    try {
      let image = await axios.get(url, { responseType: "arraybuffer" });
      let returnedB64 = Buffer.from(image.data).toString("base64");

      // console.log("returnedB64", `data:image/png;base64,${returnedB64}`);

      return `data:image/png;base64,${returnedB64}`;
    } catch (error) {
      console.log("error", error);
    }
  },
};
