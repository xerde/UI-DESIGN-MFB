const CustomerInfo = require("../models").CustomerInfo;

const { BlobServiceClient } = require("@azure/storage-blob");

const AZURE_STORAGE_CONNECTION_STRING =
  process.env.AZURE_STORAGE_CONNECTION_STRING;

const blobServiceClient = BlobServiceClient.fromConnectionString(
  AZURE_STORAGE_CONNECTION_STRING
);

const containerName = process.env.AZURE_CONTAINER;

module.exports = {
  uploadCustomerPhoto: async (customer_id, file) => {
    try {
      const containerClient = blobServiceClient.getContainerClient(
        containerName
      );

      let key = `${customer_id}/photo/${file.originalname}`;

      const blockBlobClient = containerClient.getBlockBlobClient(key);

      const uploadBlobResponse = await blockBlobClient.uploadFile(file.path, {
        tier: "Cool",
      });

      await CustomerInfo.update(
        {
          photo_location: blockBlobClient.url,
          photo_key: key,
          bucket: containerName,
          photostatus: "PENDING"
        },
        { where: { id: customer_id } }
      );
      
    } catch (error) {
      console.log("error", error);
    }
  },

  uploadCustomerVideo: async (customer_id, file) => {
    try {
      const containerClient = blobServiceClient.getContainerClient(
        containerName
      );

      let key = `${customer_id}/video/${file.originalname}`;

      const blockBlobClient = containerClient.getBlockBlobClient(key);

      const uploadBlobResponse = await blockBlobClient.uploadFile(file.path, {
        tier: "Cool",
      });

      await CustomerInfo.update(
        {
          video_location: blockBlobClient.url,
          video_key: key,
          bucket: containerName,          
          livelinesschecked: "PENDING"
        },
        { where: { id: customer_id } }
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  uploadCustomerSignature: async (customer_id, file) => {
    try {
      const containerClient = blobServiceClient.getContainerClient(
        containerName
      );

      let key = `${customer_id}/signature/${file.originalname}`;

      const blockBlobClient = containerClient.getBlockBlobClient(key);

      const uploadBlobResponse = await blockBlobClient.uploadFile(file.path, {
        tier: "Cool",
      });

      await CustomerInfo.update(
        {
          signature_location: blockBlobClient.url,
          signature_key: key,
          bucket: containerName,
          signaturestatus: "PENDING"
        },
        { where: { id: customer_id } }
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  uploadCustomerDocument: async (
    customer_id,
    document_type_id,
    document_number,
    document_issue_date,
    document_expiry_date,
    file
  ) => {
    try {
      const containerClient = blobServiceClient.getContainerClient(
        containerName
      );

      let key = `${customer_id}/document/${file.originalname}`;

      const blockBlobClient = containerClient.getBlockBlobClient(key);

      const uploadBlobResponse = await blockBlobClient.uploadFile(file.path, {
        tier: "Cool",
      });

      await CustomerInfo.update(
        {
          document_location: blockBlobClient.url,
          document_key: key,
          document_number: document_number,
          document_type_id: document_type_id,
          document_issue_date: document_issue_date,
          document_expiry_date: document_expiry_date,
          bucket: containerName,
          documentstatus: "PENDING"
        },
        { where: { id: customer_id } }
      );
    } catch (error) {
      console.log("error", error);
    }
  },

  deleteBlob: async (customer_id, file) => {
    const containerClient = blobServiceClient.getContainerClient(containerName);

    let r = await containerClient.deleteBlob("key");

    console.log("r", r);
    return;
  },
};
