var axios = require("axios");
var dayjs = require("dayjs");

const BillerService = require("../models").BillerService;
const Biller = require("../models").Biller;
const BillerCategory = require("../models").BillerCategory;

const excluded_services = require("../constants/excluded_services");

const Op = require("../models/index").Sequelize.Op;
const Sequelize = require("../models/index").Sequelize;

module.exports = {
  getBillerCategories: async () => {
    try {
      let options = await BillerCategory.findAll({
        where: { name: { [Op.not]: "Data" } },
        attributes: ["id", "name"],
      });

      return { status: true, data: options };
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getAllBillers: async () => {
    try {
      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.get(
        `${process.env.REMITA_URL}/bgatesvc/billing/billers`,
        config
      );

      // console.log("response", data);

      if (data.responseCode === "00") {
        return { status: true, data: data.responseData };
      } else {
        return { status: false, message: "No Billers Found" };
      }
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getServices: async (billerId) => {
    try {
      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.get(
        `${process.env.REMITA_URL}/bgatesvc/billing/${billerId}/servicetypes`,
        config
      );

      // console.log("response", data);

      if (data.responseCode === "00") {
        return { status: true, data: data.responseData };
      } else {
        return { status: false, message: data.responseMsg };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  

  getRequiredFields: async (serviceId) => {
    try {
      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.get(
        `${process.env.REMITA_URL}/bgatesvc/billing/servicetypes/${serviceId}`,
        config
      );

      console.log("response", data);

      if (data.responseCode === "00") {
        let reqField = data.responseData.find(
          (item) => item.dataLoadRuleId !== 0 && item.required === true
        );

        return {
          status: true,
          data: { id: reqField.id, name: reqField.columnName },
        };
      } else {
        return { status: false, message: data.responseMsg };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getAirtimeOptions: async () => {
    try {
      let airtimeOptions = [
        {
          service_id: "1273219412",
          label: "MTN Nigeria",
          description: "MTN Recharge",
        },

        {
          service_id: "1273247283",
          label: "Airtel",
          description: "Airtel Recharge",
        },

        {
          service_id: "1273219257",
          label: "Glo Nigeria",
          description: "Glo Recharge",
        },

        {
          service_id: "1273219173",
          label: "9 Mobile",
          description: "9 Mobile Recharge",
        },
      ];

      return { status: true, data: airtimeOptions };
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getBillersByCategoryId: async (catgoryId) => {
    try {
      let options = await Biller.findAll({
        where: { billerCategoryId: catgoryId },
        attributes: [
          ["billerId", "biller_id"],
          ["billerName", "biller_name"],
        ],
      });

      return { status: true, data: options };
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getBillersByCategoryName: async (categoryName) => {
    try {
      let options = await Biller.findAll({
        include: [
          {
            model: BillerCategory,
            where: { name: categoryName },
            attributes: [],
          },
        ],

        attributes: [
          ["billerId", "biller_id"],
          ["billerName", "biller_name"],
        ],
      });

      return { status: true, data: options };
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getServiceOptions: async (billerId) => {
    try {
      let options = await BillerService.findAll({
        include: [
          { model: Biller, where: { billerId: billerId }, attributes: [] },
        ],
        attributes: [["serviceId", "service_id"], "description", "amount"],
        order: [["amount", "ASC"]],
      });

      return { status: true, data: options };
    } catch (error) {
      console.log("error", error.message);
      return error.response.data;
    }
  },

  parse_services: async (billerId, billerName, billerCategoryId) => {
    try {
      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.get(
        `${process.env.REMITA_URL}/bgatesvc/billing/${billerId}/servicetypes`,
        config
      );

      let foundBiller = await Biller.findOne({
        where: { billerId: billerId },
      });

      if (foundBiller) return { status: false, message: "Already exists" };

      let biller = await Biller.create({
        billerId: billerId,
        billerName: billerName,
        billerCategoryId: billerCategoryId,
      });

      for (const service of data.responseData[0]) {
        const { data } = await axios.get(
          `${process.env.REMITA_URL}/bgatesvc/billing/servicetypes/${service.id}`,
          config
        );

        let foundService = excluded_services.find(
          (item) => item === service.id
        );

        if (foundService) continue;

        await BillerService.create({
          serviceId: service.id,
          description: service.name.substring(service.name.indexOf("-") + 1),
          amount: data.fixedAmount,
          billerId: biller.id,
        });

        // console.log("service", service);
        // console.log("data", data);
      }

      if (data.responseCode === "00") {
        return { status: true, data: data };
      } else {
        return { status: false, message: "No Services Found" };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  getCustomFields: async (serviceId) => {
    try {
      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.get(
        `${process.env.REMITA_URL}/bgatesvc/billing/servicetypes/${serviceId}`,
        config
      );

      console.log("response", data);

      if (data.responseCode === "00") {
        return { status: true, data: data.responseData };
      } else {
        return { status: false, message: data.responseMsg };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  lookup_field: async (
    serviceId,
    amount,
    payerPhone,
    payerName,
    payerEmail,
    currency,
    customFields
  ) => {
    try {
      let payload = {
        // customFields: [
        //   {
        //     id: 3310531523, //meter id
        //     values: [
        //       {
        //         value: "0101150472823", // my meter no
        //         // quntity: 0,
        //         // amount: 0,
        //       },
        //     ],
        //   },
        // ],
        customFields: customFields,
        billId: serviceId,
        amount: amount,
        payerPhone: payerPhone,
        // currency: currency,
        payerName: payerName,
        payerEmail: payerEmail,
      };

      console.log("payload", payload);

      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.post(
        `${process.env.REMITA_URL}/bgatesvc/billing/validate`,
        payload,
        config
      );

      console.log("response", data);

      if (data.responseCode === "00") {
        return {
          status: true,
          data: data.responseData[0],
          message: data.responseMsg,
        };
      } else {
        return { status: false, message: data.responseMsg };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  generate_rrr: async (
    serviceId,
    amount,
    payerPhone,
    payerName,
    payerEmail,
    currency,
    customFields
  ) => {
    try {
      let payload = {
        customFields: customFields,
        billId: serviceId,
        amount: amount,
        payerPhone: payerPhone,
        currency: currency,
        payerName: payerName,
        payerEmail: payerEmail,
      };

      console.log("payload", payload);

      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.post(
        `${process.env.REMITA_URL}/bgatesvc/billing/generate`,
        payload,
        config
      );

      console.log("response >>> ", data);

      if (data.responseCode === "00") {
        return {
          status: true,
          data: data.responseData[0],
          message: data.responseMsg,
        };
      } else {
        return { status: false, message: data.responseMsg };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  process_transaction: async (rrr) => {
    try {
      let payload = {
        ProcessingInfo: [
          {
            name: "AGENTCODE",
            value: "SPECSQAD",
          },
        ],
      };

      let requestId = dayjs().toISOString();

      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.post(
        `${process.env.REMITA_URL}/echannelsvc/echannel/agents/collection/${process.env.REMITA_AUTH_TOKEN}/${rrr}/00/SUCCESS/${requestId}/notification`,
        payload,
        config
      );

      //parse string because of jsonp format of response
      let response = JSON.parse(data.split("(")[1].split(")")[0]);

      console.log("response", response);

      if (response.responseCode === "00") {
        return { status: true, data: response.transactionMessage };
      } else {
        return { status: false, message: response.responseMessage };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },

  transaction_status: async (rrr) => {
    try {
      let payload = {};

      let requestId = dayjs().toISOString();

      const config = {
        headers: {
          publicKey: `${process.env.REMITA_PUBLIC_KEY}`,
          transactionId: `${dayjs().toISOString()}`,
        },
      };

      const { data } = await axios.post(
        `${process.env.REMITA_URL}/echannelsvc/echannel/agents/collection/${process.env.REMITA_AUTH_TOKEN}/${rrr}/${requestId}/lookup`,
        payload,
        config
      );

      //parse string because of jsonp format of response
      let response = JSON.parse(data.split("(")[1].split(")")[0]);

      console.log("response", response);

      if (response.responseCode === "SUCCESS") {
        return { status: true, data: response.txn };
      } else {
        return { status: false, message: "Not Found" };
      }
    } catch (error) {
      throw error;
      console.log("error", error.message);
      return error.response.data;
    }
  },
};
