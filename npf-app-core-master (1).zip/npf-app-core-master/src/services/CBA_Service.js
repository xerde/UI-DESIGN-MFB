var axios = require("axios");

const Email_Service = require("./Email_Service");

const SERVER_URL = process.env.INLAKS_URL;

const config = {
  headers: {
    authID: process.env.INLAKS_AUTH_ID,
    apikey: process.env.INLAKS_API_KEY,
    appID: process.env.INLAKS_APP_ID,
  },
};

module.exports = {
  getCoreAccountDetails: async (account) => {
    try {
      // let structure = {
      //   accountName: "HASSAN MUHAMMAD BABAYO",
      //   balance: 46236.39,
      //   phoneNumber: "2347089323938",
      //   companyCode: "NG0020014",
      //   responseCode: "00",
      //    bvn: "12345678912",
      //   responseDescription: "SUCCESS",
      //   transactionDate: "2020-11-05 14:33:00",
      // };

      let { data } = await axios.get(
        `${SERVER_URL}/NameEnquiry?AccountNumber=${account}`,
        config
      );

      console.log("data", data);

      let feedback = {};

      if (data.responseCode === "00") {
        let names = data.accountName.split(" ");

        let tempPhone = null;

        switch (account) {
          case "0020618513":
            tempPhone = "2348162921785"; //remi
            break;

          case "0020618520":
            tempPhone = "2348103350884"; //cj
            break;

          case "0020618518":
            tempPhone = "2348034947446"; //bruno
            break;

          case "0020618516":
            tempPhone = "2348055966005"; //tahir
            break;

          case "0020618515":
            // tempPhone = "2348025901515"; //tester - Frank
            tempPhone = "2347049576440"; //tester - Frank
            break;

          case "0020618525":
            tempPhone = "2348175226136"; //Kalu
            break;

          case "0020618523":
            tempPhone = "2347011011237"; //UAT 1
            break;

          case "0020618524":
            tempPhone = "2348023598840"; //UAT 2
            break;

          case "0020618526":
            tempPhone = "2347032527402"; //UAT 3
            break;

          case "0020618527":
            tempPhone = "2348091827726"; //UAT 4
            break;

          default:
            tempPhone = "2347089323938";
            break;
        }

        let phone = null;

        if (process.env.ENV === "PRODUCTION") {
          if (data.phoneNumber.startsWith("0")) {
            phone = data.phoneNumber.replace("0", "234");
          } else if (data.phoneNumber.startsWith("+")) {
            phone = data.phoneNumber.substring(1);
          } else {
            phone = data.phoneNumber;
          }
        } else {
          phone = tempPhone;
        }

        feedback = {
          status: true,
          data: {
            bvn: data.bvn,
            firstname: names[0],
            middlename: names.length < 3 ? "" : names[1],
            lastname: names.length < 3 ? names[1] : names[2],
            date_of_birth: new Date(),
            registration_date: null,
            phone: phone,
            gender: null,
            balance: data.balance,
            companyCode: data.companyCode,
            bvn: data.bvn,
            accountName: data.accountName,
            customerNumber: data.customerNumber,
          },
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/NameEnquiry", error);
      throw error;
    }
  },

  accountBalance: async (account) => {
    try {
      let { data } = await axios.get(
        `${SERVER_URL}/BalanceEnquiry?AccountNumber=${account}`,
        config
      );

      console.log("data", data);

      let feedback = {};

      if (data.responseCode === "00") {
        // let structure = {
        //   accountName: "HASSO STEPHEN",
        //   phoneNumber: "+2348035873235",
        //   balance: 3850951.33,
        //   responseCode: "00",
        //   transactionDate: null,
        //   responseDescription: "SUCCESS",
        // };

        feedback = {
          status: true,
          data: {
            balance: data.balance,
          },
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/BalanceEnquiry", error);
      throw error;
    }
  },

  allAccountBalances: async (customerNumber) => {
    try {
      let { data } = await axios.get(
        `${SERVER_URL}/customer/accounts?CustomerNumber=${customerNumber}`,
        config
      );

      console.log("data", data);

      let feedback = {};

      if (data.responseCode === "00") {
        // let structure = {
        //   accounts: [
        //     {
        //       accountNo: "0020087159",
        //       accountName: "QUADRI ZAINAB TEMITOPE",
        //       accountType: "SAVINGS",
        //       currency: "NGN",
        //       availableBalance: 1013.76,
        //       bookBalance: 1013.76,
        //       responseCode: null,
        //       transactionDate: null,
        //       responseDescription: null,
        //     },
        //     {
        //       accountNo: "0020618513",
        //       accountName: "AKOGUN OLASOJI",
        //       accountType: "SAVINGS",
        //       currency: "NGN",
        //       availableBalance: 0.0,
        //       bookBalance: 0.0,
        //       responseCode: null,
        //       transactionDate: null,
        //       responseDescription: null,
        //     },
        //     {
        //       accountNo: "0020618514",
        //       accountName: "AKOGUN OLASOJI",
        //       accountType: "SAVINGS",
        //       currency: "NGN",
        //       availableBalance: 0.0,
        //       bookBalance: 0.0,
        //       responseCode: null,
        //       transactionDate: null,
        //       responseDescription: null,
        //     },
        //   ],
        //   responseCode: "00",
        //   transactionDate: "2020-11-10 17:30:34",
        //   responseDescription: "SUCCESS",
        // };

        feedback = {
          status: true,
          data: data.accounts,
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/customer/accounts", error);
      throw error;
    }
  },

  recentTransactions: async (
    accountNumber,
    companyCode,
    startDate,
    endDate
  ) => {
    try {
      let { data } = await axios.get(
        `${SERVER_URL}/account/transactions?accountNo=${accountNumber}&startDate=${startDate}&CompanyCode=NG0020001&endDate=${endDate}`,
        config
      );

      // let structure = {
      //   transactions: [
      //     {
      //       type: "Credit",
      //       date: "2019-02-01",
      //       transactionReference: "FT20358978487590",
      //       description: "Credit Interest",
      //       amount: 1630.44,
      //       narration: "",
      //     },
      //     {
      //       type: "Debit",
      //       date: "2019-02-01",
      //       transactionReference: "FT20358978487590",
      //       description: "Tax Amount Due",
      //       amount: 163.04,
      //       narration: "",
      //     },
      //   ],
      //   responseCode: "00",
      //   responseDescription: "SUCCESS",
      //   transactionDate: "2020-11-12 09:22:28",
      // };

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: data.transactions.reverse(), //LIFO order
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/account/transactions", error);
      throw error;
    }
  },

  createUserAccount: async (payload) => {
    try {
      let info = payload;

      delete info.Image;
      delete info.Signature;

      console.log("payload new acct >> ", info);

      let { data } = await axios.post(
        `${SERVER_URL}/NewAccount`,
        payload,
        config
      );

      console.log("/NewAccount resp >> ", data);

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: {
            accountNumber: data.accountNumber,
            customerNumber: data.customerNumber,
          },
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription + " " + data.responseMessage,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/NewAccount", error);
      throw error;
    }
  },

  interbankNameEnquiry: async (
    senderAccountNumber,
    destinationInstitutionCode,
    receiverAccountNumber
  ) => {
    try {
      let payload = {
        senderAccountNumber: senderAccountNumber,
        destinationInstitutionCode: destinationInstitutionCode,
        receiverAccountNumber: receiverAccountNumber,
      };

      let { data } = await axios.post(
        `${SERVER_URL}/InterbankNameEnquiry`,
        payload,
        config
      );

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: data,
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/InterbankNameEnquiry", error);
      throw error;
    }
  },

  interbankTransfer: async (input) => {
    try {
      console.log("input", input);

      let payload = {
        SenderAccountNo: input.senderAccountNo,
        SenderPhoneNumber: input.senderPhoneNumber,
        SenderName: input.senderName,
        SenderBVN: input.senderBVN,
        NameEnquiryRef: input.nameEnquiryRef,
        ReceiverBVN: input.receiverBVN,
        ReceiverName: input.receiverName,
        ReceiverAccountNo: input.receiverAccountNo,
        DestinationInstitutionCode: input.destinationInstitutionCode,
        ReceiverKYCLevel: input.receiverKYCLevel,
        TransactionAmount: input.TransactionAmount,
        Narration: input.Narration,
        ReferenceNo: input.ReferenceNo,
      };

      console.log("payload", payload);

      let { data } = await axios.post(
        `${SERVER_URL}/InterbankTransfer`,
        payload,
        config
      );

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: data,
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/InterbankTransfer", error);
      throw error;
    }
  },

  localTranfer: async (payload) => {
    try {
      console.log("payload", payload);

      let { data } = await axios.post(
        `${SERVER_URL}/LocalTransfer`,
        payload,
        config
      );

      console.log("data", data);

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: data,
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/LocalTransfer", error);
      throw error;
    }
  },

  phoneLookup: async (phone) => {
    try {
      if (phone.startsWith("234")) {
        phone = phone.replace("234", "0");
      }

      let { data } = await axios.get(
        `${SERVER_URL}/NameEnquiryByPhoneNumber?PhoneNumber=${phone}`,
        config
      );

      console.log("NameEnquiryByPhoneNumber", data);

      let feedback = {};

      if (data.responseCode === "00") {
        feedback = {
          status: true,
          data: {
            accounts: data.accounts,
          },
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/NameEnquiryByPhoneNumber", error);
      throw error;
    }
  },

  fetchCustomerName: async (account) => {
    try {
      let { data } = await axios.get(
        `${SERVER_URL}/NameEnquiry?AccountNumber=${account}`,
        config
      );

      console.log("data", data);

      let feedback = {};

      if (data.responseCode === "00") {
        let names = data.accountName.split(" ");

        feedback = {
          status: true,
          data: {
            firstname: names[0],
            middlename: names.length < 3 ? "" : names[1],
            lastname: names.length < 3 ? names[1] : names[2],
          },
        };
      } else {
        feedback = {
          status: false,
          message: data.responseDescription,
        };
      }

      return feedback;
    } catch (error) {
      console.log("error", error);
      await Email_Service.cbaError("/NameEnquiry", error);
      throw error;
    }
  },
};
